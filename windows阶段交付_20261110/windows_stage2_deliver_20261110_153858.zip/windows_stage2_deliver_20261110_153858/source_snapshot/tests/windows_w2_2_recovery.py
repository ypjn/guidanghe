"""W2-2：中断恢复 4 种状态夹具（真实 Storage API 版）

四种夹具：
  F1  planned — create_action 后 update_batch_status(execute)，文件不动
  F2  both_exist — execute_plan 正常移动后，手动把源文件拷回
  F3  neither_exists — 直接 SQL 插 batch + action，磁盘双空
  F4  新进程恢复入口（execute_plan + 独立进程 undo，之前已过）

恢复都走 executor.undo_latest_batch / recover_batch，
不人工调 Storage 私有方法。
"""
from __future__ import annotations
import json, os, shutil, sys, time, subprocess, re, hashlib, sqlite3

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)
BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_recover_v2")

RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:3]: print(f"         {line}")

def run_child(body: str, label: str, timeout=90) -> subprocess.CompletedProcess:
    tdir = os.path.join(BASE, "children")
    os.makedirs(tdir, exist_ok=True)
    tmp = os.path.join(tdir, f"child_{label}.py")
    full = f"""
import sys, os
sys.path.insert(0, r"{SRC}")
{body}
"""
    with open(tmp, "w", encoding="utf-8") as f: f.write(full)
    py = os.path.join(os.path.dirname(os.path.dirname(SRC)), ".venv", "Scripts", "python.exe")
    return subprocess.run(
        [py, tmp], capture_output=True, text=True, timeout=timeout,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )

def mk(root, rel, content="x"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p) or root, exist_ok=True)
    with open(p, "wb") as f: f.write(content.encode("utf-8"))

def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()

if os.path.exists(BASE): shutil.rmtree(BASE)


# ============ 夹具 1：planned（已登记 + executing，文件不动） ============
print("=== 夹具 1：动作已登记但文件未移动 ===")
run1 = os.path.join(BASE, "runs", "f1_planned", "root")
mk(run1, "大二上/数据结构/讲义.pdf", "c1")

body1_setup = f"""
import os, sys, hashlib
RUN1 = r"{run1}"
from storage import Storage, BATCH_EXECUTING
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory

sr = scan_directory(RUN1, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])

st = Storage(RUN1)
batch_id = st.create_batch(plan, summary="中断夹具-已登记未移动")
idx = 0
for item in plan.items:
    if not item.selected: continue
    src_p = os.path.join(RUN1, item.file.rel_path)
    h = hashlib.sha256(open(src_p, "rb").read()).hexdigest()
    st.create_action(batch_id, item, idx, h)
    idx += 1
# 标记为 executing（正常执行中会做的一步）
st.update_batch_status(batch_id, BATCH_EXECUTING)
st.close()

# 验证：源文件还在，目标 0 文件
src_p = os.path.join(RUN1, "大二上/数据结构/讲义.pdf")
org = os.path.join(RUN1, "_已整理")
cnt = 0
if os.path.exists(org):
    for dp, dn, fn in os.walk(org): cnt += len(fn)
print(f"F1_BATCH={{batch_id}}  ACTIONS={{idx}}")
print(f"F1_SRC_EXISTS={{os.path.exists(src_p)}}")
print(f"F1_ORG_FILES={{cnt}}")
print(f"F1_SETUP_OK=1")
"""
p1s = run_child(body1_setup, "f1s")
out1s = p1s.stdout + "\n" + p1s.stderr
print(f" setup exit={p1s.returncode}")
for line in p1s.stdout.splitlines(): print("   ", line)
if p1s.returncode != 0:
    print("   [STDERR]", p1s.stderr[-400:])

src_exists = "F1_SRC_EXISTS=True" in out1s
org_cnt = 0
m = re.search(r'F1_ORG_FILES=(\d+)', out1s)
if m: org_cnt = int(m.group(1))
rec("F1_1", "夹具 1：源文件在原位", "PASS" if src_exists else "FAIL", f"src_exists={src_exists}")
rec("F1_2", f"夹具 1：归档目录 0 文件", "PASS" if org_cnt == 0 else "FAIL", f"cnt={org_cnt}")

# 新进程做恢复：调用 recover_batch + undo_latest_batch
body1b = f"""
import sys, os
RUN1 = r"{run1}"
from storage import Storage
from executor import recover_batch, undo_latest_batch, undo_is_available

st = Storage(RUN1)
rr = recover_batch(st)
print(f"F1B_RECOVERED_MOVED={{rr.recovered_moved}}  STILL_PLANNED={{rr.still_planned}}  PAUSED={{rr.paused}}")
print(f"F1B_BATCH_STATUS={{rr.batch_status_after}}")
print(f"F1B_UNDO_AVAILABLE={{undo_is_available(st)}}")
ur = undo_latest_batch(st)
print(f"F1B_RESTORED={{ur.restored}}  conflict={{ur.conflict}}  errors={{ur.errors}}")
src_after = os.path.exists(os.path.join(RUN1, "大二上/数据结构/讲义.pdf"))
org = os.path.join(RUN1, "_已整理")
cnt = sum(1 for dp, dn, fn in os.walk(org) for f in fn) if os.path.exists(org) else 0
print(f"F1B_SRC_AFTER={{src_after}}  ORG={{cnt}}")
st.close()
"""
p1b = run_child(body1b, "f1b")
print(f" recover exit={p1b.returncode}")
for line in p1b.stdout.splitlines(): print("   ", line)
if p1b.returncode != 0: print("   [STDERR]", p1b.stderr[-400:])

ok = p1b.returncode == 0 and "F1B_SRC_AFTER=True" in p1b.stdout and "F1B_RESTORED=0" in p1b.stdout
rec("F1_3", "夹具 1 恢复：planned 状态文件保留归档清空",
    "PASS" if ok else "FAIL", p1b.stdout.splitlines()[-4:] if p1b.stdout else "")


# ============ 夹具 2：both_exist — execute_plan 后手动拷回源 ============
print("\n=== 夹具 2：源与目标同时存在 ===")
run2 = os.path.join(BASE, "runs", "f2_both", "root")
mk(run2, "讲义.pdf", "original")

body2 = f"""
import os, sys, shutil, hashlib
RUN2 = r"{run2}"
from storage import Storage
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory
from executor import execute_plan

sr = scan_directory(RUN2, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
# 强制讲义.pdf 选中
for item in plan.items: item.selected = True

st = Storage(RUN2)
result = execute_plan(plan, st)
print(f"F2_BATCH={{result.batch_id}}  moved={{result.moved}}  failed={{result.failed}}")

# 手动把源文件拷回（制造源+目标共存）
tgt_rel = plan.items[0].target_rel_path
tgt_p = os.path.join(RUN2, tgt_rel.replace("/", os.sep))
src_back = os.path.join(RUN2, "讲义.pdf")
shutil.copy2(tgt_p, src_back)
print(f"F2_TGT={{tgt_p}}")
print(f"F2_BOTH_EXIST={{os.path.exists(src_back) and os.path.exists(tgt_p)}}")
print(f"F2_SRC_SHA={{hashlib.sha256(open(src_back,'rb').read()).hexdigest()[:12]}}")
print(f"F2_TGT_SHA={{hashlib.sha256(open(tgt_p,'rb').read()).hexdigest()[:12]}}")
st.close()
"""
p2 = run_child(body2, "f2")
print(f" setup exit={p2.returncode}")
for line in p2.stdout.splitlines(): print("   ", line)
if p2.returncode != 0: print("   [STDERR]", p2.stderr[-400:])

rec("F2_1", "夹具 2 建立：execute_plan 后拷回源 → 源+目标共存",
    "PASS" if p2.returncode == 0 and "F2_BOTH_EXIST=True" in p2.stdout else "FAIL",
    f"exit={p2.returncode} both={'F2_BOTH_EXIST=True' in p2.stdout}")

body2b = f"""
import sys, os
RUN2 = r"{run2}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available

st = Storage(RUN2)
ur = undo_latest_batch(st)
print(f"F2B_RESTORED={{ur.restored}}  conflict={{ur.conflict}}  errors={{ur.errors}}")
print(f"F2B_ERRORS_LIST={{ur.errors_list}}")
src_p = os.path.join(RUN2, "讲义.pdf")
# 查实际 target_rel（SQLite）
cur = st.conn.execute("SELECT target_rel FROM actions ORDER BY action_index LIMIT 1")
tgt_rel = cur.fetchone()[0]
tgt_p = os.path.join(RUN2, tgt_rel.replace('/', os.sep))
print(f"F2B_SRC_EXISTS={{os.path.exists(src_p)}}")
print(f"F2B_TGT_EXISTS={{os.path.exists(tgt_p)}}")
st.close()
"""
p2b = run_child(body2b, "f2b")
print(f" recover exit={p2b.returncode}")
for line in p2b.stdout.splitlines(): print("   ", line)
if p2b.returncode != 0: print("   [STDERR]", p2b.stderr[-400:])

ok2 = "F2B_SRC_EXISTS=True" in p2b.stdout and p2b.returncode == 0
rec("F2_2", "夹具 2 恢复后源文件仍存在（不应被覆盖）",
    "PASS" if ok2 else "FAIL", p2b.stdout.splitlines()[-5:] if p2b.stdout else "")


# ============ 夹具 3：neither_exists — 直接 SQL 构造 ============
print("\n=== 夹具 3：源和目标都不存在（仅 DB 残留 moved） ===")
run3 = os.path.join(BASE, "runs", "f3_none", "root")
os.makedirs(os.path.join(run3, ".organizer"), exist_ok=True)

SCHEMA = '''
CREATE TABLE IF NOT EXISTS batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT, root TEXT NOT NULL, mode TEXT NOT NULL,
    status TEXT NOT NULL, created_at TEXT NOT NULL, finished_at TEXT DEFAULT '',
    rules_json TEXT DEFAULT '', summary TEXT DEFAULT '', config_json TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL,
    action_index INTEGER NOT NULL, source_rel TEXT NOT NULL, target_rel TEXT NOT NULL,
    source_size INTEGER NOT NULL, source_sha256 TEXT NOT NULL,
    status TEXT NOT NULL, error TEXT DEFAULT '',
    executed_at TEXT DEFAULT '', undone_at TEXT DEFAULT '',
    auto_target_rel TEXT DEFAULT '', auto_rule_applied TEXT DEFAULT '',
    override_note TEXT DEFAULT '', rule_key TEXT DEFAULT '', rule_applied TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS created_dirs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL, rel_path TEXT NOT NULL
);
'''
body3 = f"""
import os, sys, sqlite3
from datetime import datetime
RUN3 = r"{run3}"
db_path = os.path.join(RUN3, ".organizer", "history.db")
SCHEMA = {SCHEMA!r}
conn = sqlite3.connect(db_path)
conn.execute("PRAGMA foreign_keys = ON")
conn.executescript(SCHEMA)
now = datetime.now().isoformat(timespec="seconds")
cur = conn.execute(
    "INSERT INTO batches(root, mode, status, created_at, rules_json, summary) "
    "VALUES(?, ?, ?, ?, '', ?)",
    (RUN3, "by_direction_semester", "done", now, "中断夹具-双不存在"),
)
bid = cur.lastrowid
conn.execute(
    "INSERT INTO actions(batch_id, action_index, source_rel, target_rel, source_size, "
    "source_sha256, status, executed_at) VALUES(?, 0, ?, ?, ?, ?, ?, ?)",
    (bid, "讲义.pdf", "_已整理/待定/讲义.pdf", 10, "deadbeef1234" * 4, "moved", now),
)
conn.commit()
conn.close()

src_p = os.path.join(RUN3, "讲义.pdf")
tgt_p = os.path.join(RUN3, "_已整理", "待定", "讲义.pdf")
print(f"F3_DB_BATCH={{bid}}")
print(f"F3_BOTH_MISSING={{not os.path.exists(src_p) and not os.path.exists(tgt_p)}}")
print(f"F3_SRC_EXISTS={{os.path.exists(src_p)}}")
print(f"F3_TGT_EXISTS={{os.path.exists(tgt_p)}}")
"""
p3 = run_child(body3, "f3")
print(f" setup exit={p3.returncode}")
for line in p3.stdout.splitlines(): print("   ", line)
if p3.returncode != 0: print("   [STDERR]", p3.stderr[-400:])

rec("F3_1", "夹具 3 建立：DB 有 moved action 但磁盘双空",
    "PASS" if p3.returncode == 0 and "F3_BOTH_MISSING=True" in p3.stdout else "FAIL",
    f"exit={p3.returncode} both_missing={'F3_BOTH_MISSING=True' in p3.stdout}")

body3b = f"""
import sys, os
RUN3 = r"{run3}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available, recover_batch

st = Storage(RUN3)
rr = recover_batch(st)
print(f"F3B_RECOVERED_MOVED={{rr.recovered_moved}}  STILL_PLANNED={{rr.still_planned}}  PAUSED={{rr.paused}}")
print(f"F3B_BATCH_STATUS={{rr.batch_status_after}}")
print(f"F3B_UNDO_AVAILABLE={{undo_is_available(st)}}")
ur = undo_latest_batch(st)
print(f"F3B_RESTORED={{ur.restored}}  conflict={{ur.conflict}}  errors={{ur.errors}}")
print(f"F3B_ERRORS_LIST={{ur.errors_list}}")
src_p = os.path.join(RUN3, "讲义.pdf")
print(f"F3B_SRC_EXISTS={{os.path.exists(src_p)}}")
st.close()
"""
p3b = run_child(body3b, "f3b")
print(f" recover exit={p3b.returncode}")
for line in p3b.stdout.splitlines(): print("   ", line)
if p3b.returncode != 0: print("   [STDERR]", p3b.stderr[-400:])

ok3 = p3b.returncode == 0
rec("F3_2", "夹具 3 恢复/撤销不报异常，明确报告状态",
    "PASS" if ok3 else "FAIL",
    f"exit={p3b.returncode} out={{p3b.stdout[-300:] if p3b.stdout else ''}}")


# ============ 夹具 4：新进程完整恢复入口（之前已过，再跑一次） ============
print("\n=== 夹具 4：新进程恢复入口有效（复跑） ===")
run4 = os.path.join(BASE, "runs", "f4_recover", "root")
mk(run4, "大二上/数据结构/作业/hw.docx", "hw")
mk(run4, "大二上/数据结构/讲义.pdf", "pdf")

body4a = f"""
import sys, os
RUN4 = r"{run4}"
from storage import Storage
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory
from executor import execute_plan

sr = scan_directory(RUN4, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
st = Storage(RUN4)
result = execute_plan(plan, st)
st.close()
print(f"F4A_BATCH={{result.batch_id}}  moved={{result.moved}}  failed={{result.failed}}")
"""
p4a = run_child(body4a, "f4a")
print(f" setup exit={p4a.returncode}")
for line in p4a.stdout.splitlines(): print("   ", line)

body4b = f"""
import sys, os
RUN4 = r"{run4}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available

st = Storage(RUN4)
print(f"F4B_UNDO_AVAILABLE={{undo_is_available(st)}}")
ur = undo_latest_batch(st)
print(f"F4B_RESTORED={{ur.restored}}  conflict={{ur.conflict}}  errors={{ur.errors}}")
org = os.path.join(RUN4, "_已整理")
cnt = sum(1 for dp, dn, fn in os.walk(org) for f in fn) if os.path.exists(org) else 0
print(f"F4B_ORG_AFTER={{cnt}}")
src1 = os.path.exists(os.path.join(RUN4, "大二上/数据结构/讲义.pdf"))
src2 = os.path.exists(os.path.join(RUN4, "大二上/数据结构/作业/hw.docx"))
print(f"F4B_SRC_OK={{src1 and src2}}")
st.close()
"""
p4b = run_child(body4b, "f4b")
print(f" undo exit={p4b.returncode}")
for line in p4b.stdout.splitlines(): print("   ", line)

ok4 = ("F4B_RESTORED=2" in p4b.stdout and "F4B_ORG_AFTER=0" in p4b.stdout
       and "F4B_SRC_OK=True" in p4b.stdout and p4b.returncode == 0)
rec("F4_1", "夹具 4：新进程 execute → 独立进程 undo 完整可用",
    "PASS" if ok4 else "FAIL", p4b.stdout.splitlines()[-5:])


# ============ 汇总 ============
print(f"\n=== W2-2 汇总 ===")
passed = sum(1 for r in RESULTS if r["status"] == "PASS")
failed = sum(1 for r in RESULTS if r["status"] == "FAIL")
blocked = sum(1 for r in RESULTS if r["status"] == "BLOCK")
print(f"{len(RESULTS)} 项：PASS={passed} FAIL={failed} BLOCK={blocked}")
sys.exit(0 if failed == 0 and blocked == 0 else 1)
