
import json, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
from storage import Storage
import executor as ex
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7"
st = Storage(root)
u = ex.undo_latest_batch(st)
print(json.dumps({"restored": u.restored, "conflict": u.conflict,
                  "errors": u.errors,
                  "src_exists": __import__("os").path.isfile(r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7\大二上\数据结构\讲义.pdf"),
                  "tgt_files": [n for n in __import__("os").listdir(r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7")
                                if n.startswith(".abx-copy-")]},
                 ensure_ascii=False))
st.close()
