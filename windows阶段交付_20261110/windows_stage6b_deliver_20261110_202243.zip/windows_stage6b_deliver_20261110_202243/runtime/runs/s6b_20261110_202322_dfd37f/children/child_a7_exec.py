
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
import executor as ex
from storage import Storage
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7"
src = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7\大二上\数据结构\讲义.pdf"

class Proxy:
    def __init__(self, real):
        self._real = real
    def rename(self, a, b):
        if os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(src)):
            raise OSError("injected rename failure (new process)")
        return self._real.rename(a, b)
    def __getattr__(self, name):
        return getattr(self._real, name)

ex.os = Proxy(os)
st = Storage(root)
import planner
from planner import MODE_BY_COURSE_THEN_TYPE
from scanner import scan_directory
p = planner.generate_plan(scan_directory(root), MODE_BY_COURSE_THEN_TYPE,
                          planner.DEFAULT_COURSE_RULES)
r = ex.execute_plan(p, st)
acts = st.get_actions(r.batch_id)
print(json.dumps({"moved": r.moved, "failed": r.failed,
                  "status": acts[0].status, "err": acts[0].error},
                 ensure_ascii=False))
st.close()
