
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
from storage import Storage
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7"
st = Storage(root)
bs = st.list_batches(include_actions=True)
acts = st.get_actions(bs[0].batch_id)
left = []
for dp, dn, fn in os.walk(root):
    for n in fn:
        if n.startswith(".abx-copy-"):
            left.append(os.path.join(dp, n))
print(json.dumps({"batches": len(bs), "statuses": [a.status for a in acts],
                  "err": acts[0].error, "leftovers": left,
                  "src_exists": os.path.isfile(r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7\大二上\数据结构\讲义.pdf"),
                  "tgt_exists": os.path.isfile(r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6b_deliver_20261110_202243\runtime\runs\s6b_20261110_202322_dfd37f\a7\_已整理/未分类课程/文档\讲义.pdf")},
                 ensure_ascii=False))
st.close()
