
import ctypes, os, sys, time
from ctypes import wintypes
path = os.environ["ABX_HOLD_PATH"]
ready = os.environ["ABX_HOLD_READY"]
release = os.environ["ABX_HOLD_RELEASE"]
GENERIC_READ = 0x80000000
FILE_SHARE_READ = 0x1
FILE_SHARE_WRITE = 0x2
OPEN_EXISTING = 3
k = ctypes.WinDLL("kernel32", use_last_error=True)
k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                          wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD,
                          wintypes.HANDLE]
k.CreateFileW.restype = wintypes.HANDLE
h = k.CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                  None, OPEN_EXISTING, 0, None)
if h == wintypes.HANDLE(-1).value or not h:
    print("HANDLE_FAIL", ctypes.get_last_error())
    sys.exit(2)
with open(ready, "w", encoding="utf-8") as f:
    f.write("ready")
t0 = time.time()
while not os.path.exists(release) and time.time() - t0 < 60:
    time.sleep(0.05)
k.CloseHandle(wintypes.HANDLE(h))
print("RELEASED")
sys.exit(0)
