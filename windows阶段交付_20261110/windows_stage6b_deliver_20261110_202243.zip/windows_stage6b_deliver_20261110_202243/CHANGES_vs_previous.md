# 与上一轮交付的差异（stage6 → stage6b）

上一轮交付：`windows_stage6_deliver_20261110_195710`（**未改动**）。
本轮交付：`windows_stage6b_deliver_20261110_202243`。

## 1. 生产代码方向性改变

stage6 的做法是"rename 失败 → 复制到自有临时副本 → 不覆盖发布 → 删源"。顾问的两个新反例证明这条兜底本身有缺陷：

- 发布后目标被替换成同内容新文件时，删源失败会以"哈希相同"删掉外部文件（P1）；
- 发布后、删源前源被改写时，兜底会删掉新修改并返回成功（P2）。

stage6b **删除整条复制兜底**，改为最小方案：

| 项 | stage6 | stage6b |
| --- | --- | --- |
| rename 失败后 | 复制兜底 | 如实失败，源留在原处，目标不碰 |
| 临时文件 | `.abx-copy-<pid>-<uuid10>.tmp` | 无 |
| 删除他人文件的可能 | 有（哈希相同即删） | 无（异常路径不做任何删除） |
| 撤销 rename 失败 | 复制回原始路径 | 记录 conflict，不复制、不删除 |
| 代码量 | 约 120 行辅助函数 | 13 行 `_move_failure_detail` |
| 平台依赖 | 依赖 Windows rename 不覆盖 | 无平台分支；只用 rename 的失败结果 |

## 2. 测试

| 文件 | 状态 | 说明 |
| --- | --- | --- |
| `tests/windows_stage6b_ownership.py` | 新增 | 20 项：P1/P2 修复前反例、B1/B2 修复后、A1 真实占用、A2/A3 外部目标、A7 新进程诊断、A8 正常回归、A9 撤销、P3/P3b 平台边界、R1 已移除路径记录 |
| `tests/frozen_executor_stage6.py` | 新增 | stage6 `executor.py` 原样副本，用于复现 P1/P2 |
| `tests/windows_stage6_ownership.py` | 移除 | 依赖已删除的临时副本函数；原文件与结果保留在 stage6 交付 |
| `tests/frozen_executor_stage5.py` | 移除 | 仅被上面旧套件引用 |

## 3. 复现入口

- 新增 `run_stage6b.ps1`（单独提供，非补丁产物）；实跑 `child_exit=0 self_report=0 intended=0`。
- stage6 的 `run_stage6.ps1` 保留在旧交付，未被本轮引用。

## 4. 交付索引

| 项 | stage6 | stage6b |
| --- | --- | --- |
| 索引 | 97 条，生成后自检 0 不一致 | 全部文件定稿后生成，生成后逐条重算，`self_check` 记录结果 |
| 补丁 | 23 文件 +6427/−15 | 23 文件 +6373/−27；独立基线 apply 后 74 文件 0 不一致 |
| 口径 | 74/23/74/1 | 同口径，并把 2 个被移除的旧测试写进 `changed_files.json` 的 `superseded` |
