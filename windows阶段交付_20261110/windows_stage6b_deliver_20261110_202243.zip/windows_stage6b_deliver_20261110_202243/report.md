# 归档盒 V1.7 Windows 阶段 stage6b 报告：异常移动改为"失败即保留"

- 交付目录：`windows_stage6b_deliver_20261110_202243`
- 对照目录（只读、未改动）：`windows_stage6_deliver_20261110_195710`、`windows_stage5_deliver_20261110_191543`
- 顾问审阅与独立反例（原样收录于 `consultant/`）：
  - `stage6_review_20261110_201504/review.md`
  - `stage6_review_20261110_201504/post_publish_probes.json`
- 运行环境：Windows 11 build 26200，Python 3.14.7，PySide6 6.12.0

本轮只处理 stage6 异常移动机制的阻断：不扩展功能、不扩大测试范围、不改 UI/schema。

---

## 1. 最终采用的方案与原因

**采用最小方案：删除复制兜底。`os.rename` 失败即如实失败并保留现场，不复制、不删除、不覆盖、不留临时文件。**

原因（按本轮顾问给的两个新反例倒推）：

1. `P1`：兜底发布成功后，目标被外部挪走并在原路径写入**同内容**新文件；源删除失败时，`_remove_owned(target, tmp_sha)` 以「哈希相同」删掉了外部文件。只要判据是内容，这个洞就补不上——哈希永远不能证明"这个文件是我建的"。
2. `P2`：发布成功后、删源之前，源被外部改写；兜底直接删源并返回成功，**新修改丢失**。这是"复制 → 删除源"两段式本身的窗口，不是某一处判断写错。
3. 继续在兜底里加"再检查一次哈希/存在性"只能缩小窗口，不能消除"检查"与"删除"之间的竞态，正是顾问明确否定的方向。

收益与代价：

- 收益：异常路径不再有任何"删除别人的文件"或"删掉新修改"的可能；实现从约 120 行缩到 13 行；执行与撤销共用同一条安全边界。
- 代价：被占用的文件在同一次执行中**不会**被搬走，会如实记为失败并保留源文件。这是有意接受的：该文件仍在原处、可读、可重试，而 stage6 的做法是用复制去绕开占用，绕开后就出现了上述两个缺陷。
- 跨盘移动本来不是已验收能力（整理目标始终在扫描根内，与源同卷），不为维持它保留兜底。

---

## 2. 修复前后反例（同一套件内对照）

修复前代码冻结为 `tests/frozen_executor_stage6.py`（stage6 交付 `executor.py` 的原样副本）。

| 用例 | 场景 | 修复前（冻结副本）实测 | 修复后（本轮）实测 |
| --- | --- | --- | --- |
| P1 | 发布成功后目标被挪走、原路径被写入同内容新文件、源删除失败 | `moved=0 failed=1`；**外部目标被删除**（`target_exists=false`，被挪走的 `parked_exists=true`）；错误串称「已撤回本次发布的目标副本」 | 该发布窗口已不存在：rename 失败即停（B1），外部同内容目标 `tgt_bytes=b"original"` 保留，源保留，无临时文件 |
| P2 | 发布成功后、删源前源被改写 | `moved=1 failed=0`；**新修改丢失**（`src_exists=false`，目标只有 `b"original"`） | 不再删源：失败后源 `b"original\|new-user-edit"` 完整保留，历史记 failed（B2） |

完整原始输出：`prefix_logs/suite.stdout.log`；结构化结果：`prefix_logs/results.json`。

---

## 3. 实现与安全边界

改动只发生在 `归档盒源码/executor.py`。

### 3.1 代码形态

删除：`TMP_PREFIX`、`_owned_tmp_path`、`_stage_copy`、`_remove_owned`、`_move_via_owned_temp`，以及 `import shutil` / `import uuid`。

新增一个纯描述函数：

```python
def _move_failure_detail(err, src_path, target_path) -> str:
    parts = [f"移动失败：{err}", f"源文件保留在 {src_path}（未由本次操作改动）"]
    parts.append(f"目标路径已存在，未由本次操作创建或改动：{target_path}"
                 if os.path.exists(target_path) else f"目标路径未创建：{target_path}")
    parts.append("本次未复制、未删除任何文件，也没有留下临时文件")
    return "；".join(parts)
```

执行路径：

```python
try:
    os.rename(src_path, target_path)
    ... STATUS_MOVED
except OSError as e:
    msg = _move_failure_detail(e, src_path, target_path)
    ... STATUS_FAILED, error=msg
```

撤销路径：同一边界，`rename` 失败 → `STATUS_CONFLICT` + `errors += 1`，错误串写明「目标文件保留在…（未由本次操作改动）；原始路径未写入任何内容：…；本次未复制、未删除任何文件」，若原始路径已有别的文件则额外注明未动它。

### 3.2 状态选择（沿用现有状态，不新增）

| 路径 | 状态 | 语义 |
| --- | --- | --- |
| 执行 rename 失败 | `failed` | 本次没有完成移动；磁盘状态（源在、目标在/不在、未复制未删除）全部写在 `error` 里 |
| 撤销 rename 失败 | `conflict` + `errors=1` | 目标保持原样，原始路径没有半成品；条件恢复后可重试 |

不再要求"失败时目标必须不存在"：失败可能发生在目标已存在的情况下，历史如实记录，不再靠删除去凑这个不变量。

### 3.3 历史与实际磁盘的一致性

每个失败的错误串都同时给出：`rename` 的原始异常、源文件的绝对路径与"未改动"、目标路径是"已存在未改动"还是"未创建"、以及"未复制/未删除/无临时文件"这一事实陈述。新进程只读 `error` 就能判断现场，不需要猜。

---

## 4. 定向回归结果

### 4.1 断言统计与退出码

| 项 | 值 |
| --- | --- |
| 用例 | 20（PASS 19 / FAIL 0 / BLOCK 0 / 未测 1，未测项是"旧路径已删除"的显式记录） |
| 必测项缺失 | 0 |
| L1 套件自报 `EXIT_CODE` | 0（不采信） |
| L2 被测进程真实 OS 退出码 | 0 |
| L3 包装器准备返回 | 0 |
| L4 调用者观察到的壳退出码 | 0（`prefix_logs/caller_observed_exit.txt`） |

### 4.2 只验证了要求范围内的项

| 要求 | 用例 | 关键证据 |
| --- | --- | --- |
| 新反例 1（发布后目标被替换） | P1（修复前）→ B1（修复后） | P1：外部目标被删、被挪走的副本还在；B1：`tgt_bytes=b"original"`、`src_bytes=b"original"`、`leftovers=[]` |
| 新反例 2（复制完成后源变化） | P2（修复前）→ B2（修复后） | P2：`moved=1`、源消失、目标旧内容；B2：源 `b"original\|new-user-edit"` 完整、`failed=1`、`tgt_exists=false` |
| 原 Windows 真实共享占用 | A1_1–A1_4 | 子进程 `CreateFileW(GENERIC_READ, SHARE_READ\|SHARE_WRITE)` 持有，父进程改名探测 `WinError 32`；占用项 `failed`、源 SHA 不变、目标未创建、无残留；释放后子进程 exit=0 |
| 外部同内容目标保留 | A2 | `failed=1`、`tgt_bytes=b"original"`、`src_bytes=b"original"`、错误串含「未由本次操作创建或改动」 |
| 外部不同内容目标保留 | A3 | `tgt_bytes=b"EXTERNAL-DIFFERENT"` 未被覆盖 |
| 正常整理和撤销 | A8_1/A8_2 | 2 项 moved；撤销 2 项 restored；撤销后清单（含 SHA-256）`missing/extra/changed` 全空 |
| 失败后的历史与新进程诊断 | A7_1–A7_3 | 3 个独立进程 exit=0；历史 `status=failed`、错误串含源路径；无临时残留；撤销 `restored=0` 且不删除任何文件 |
| 撤销异常 | A9 | `errors=1 conflict=0`、目标存在且哈希不变、原始路径无文件、`leftovers=[]`、错误串写明现场 |
| 平台分支行为 | P3 / P3b | P3：`executor.py` 不含 `import shutil`、`shutil.move(`、`.abx-copy-`、`TMP_PREFIX`、`os.link(`、`sys.platform`、`os.name ==`；P3b：注入 `PermissionError`（POSIX 式失败形态）后同样失败即停、源保留、目标不创建 |

### 4.3 预期故障注入单列

| 用例 | 注入 |
| --- | --- |
| P1 | 冻结副本 rename 失败 + 发布后目标替换 + 删源失败 |
| P2 | 冻结副本 rename 失败 + 删源前改写源 |
| B1 | rename 失败 + 失败瞬间外部写入同内容目标 |
| B2 | rename 失败 + 失败期间外部追加源内容 |
| A2 / A3 | rename 失败 + 外部在检查后写目标 |
| A9 | 撤销 rename 失败 |
| P3b | rename 抛 `PermissionError`（模拟 POSIX 失败形态） |

非注入：A1 的占用由独立子进程用真实 Windows 共享模式建立；A7 三个子进程只读历史/撤销（执行进程内有注入）；A8 全程无注入。

### 4.4 已移除路径的说明

stage6 的 `A4`（部分复制失败）、`A5`（临时副本清理失败）、`A6`（复制期间源变化）对应的是**已删除的复制兜底**。本轮用 `R1`（状态 `未测`）显式记录："这三条路径随实现删除而不存在，不伪造为仍被覆盖"；旧实现与旧结果保留在 stage6 交付里。

---

## 5. 实际磁盘与历史核对（抽 4 例）

| 用例 | 源 | 目标 | 临时文件 | 历史 |
| --- | --- | --- | --- | --- |
| B1 | `b"original"` 在 | `b"original"` 在（外部写入） | 无 | `failed`，含源路径 + 「目标路径已存在，未由本次操作创建或改动」 |
| B2 | `b"original\|new-user-edit"` 在 | 不存在 | 无 | `failed`，含「源文件保留在…」 |
| A1 | 哈希与执行前一致 | 不存在 | 无 | `failed`，含 `WinError 32` + 源保留 + 未复制未删除 |
| A9 | 原始路径无文件（无半成品） | 存在且哈希不变 | 无 | `conflict`，`errors=1`，含「目标文件保留在…」「原始路径未写入任何内容…」 |

---

## 6. 补丁与源码资产口径

| 类别 | 数量 | 说明 |
| --- | --- | --- |
| 最终源码资产（`归档盒源码/`，排除 `__pycache__`、`tests/_abx_selftest`、`*.pyc`） | 74 | `source_snapshot/SHA256SUMS.txt` |
| 补丁改动文件 | 23 | `patches/stage6b_windows_source.stat.txt`：+6373 / −27 |
| 补丁可重建的源码资产 | 74 | 独立基线副本 `apply --check` / `apply` 均 exit=0，逐文件比对 0 不一致（`patches/apply_check.log`） |
| 单独提供的复现入口 | 1 | `run_stage6b.ps1`，不由源码补丁生成 |

源码树中被移除的两个旧测试（已写入 `source_snapshot/changed_files.json` 的 `superseded` 字段）：

- `tests/windows_stage6_ownership.py`：其 import 依赖本轮删除的临时副本函数，已失效；原文件与 20 项结果保留在 stage6 交付。
- `tests/frozen_executor_stage5.py`：仅被上面的旧套件引用；本轮保留的是 `tests/frozen_executor_stage6.py`（用于复现 P1/P2）。

验证时必须显式 `-c core.autocrlf=false`，否则 Windows 上的 Git 会把补丁里的 LF 写成 CRLF，导致所有被改文件哈希不一致（stage6 已踩过）。

复现入口本次实际运行：`child_exit=0 self_report=0 intended=0 elapsed=3.06s`，调用者观察退出码 0。

---

## 7. Windows / Mac 验证边界（准确表述）

- **实现无平台分支**：异常路径只读取 `os.rename` 失败这一结果，随后不改变磁盘。P3 用源码扫描证明没有 `shutil`、临时副本、`os.link` 或平台判断；P3b 只是"注入 `PermissionError` 模拟 POSIX 风格失败"，属于**分支/模拟验证，不等于原生 Mac 通过**。
- **Mac 保留的是冻结基线能力**：本轮删除的正是 stage6 新增的复制兜底，Mac 上的代码路径与冻结基线一致（rename 失败 → 记录失败、保留文件）。本轮没有引入任何"只在 Windows 成立"的新增异常路径。
- **未消除、也不声称消除的风险（基线既存）**：POSIX `rename(2)` 对已存在目标是**替换**语义。若在"存在性检查"与 `rename` 之间外部创建了目标，macOS 上仍可能覆盖。这不是本轮引入的，但也不能当作"不覆盖发布"来宣称；它属于 Mac 原生复验项（见 `MAC_BOUNDARY.md`）。
- **跨盘**：本轮不提供跨盘移动能力，属于未验收范围；整理场景中源与目标同卷。

---

## 8. 未测边界

- 原生 macOS：未运行（本机只有 Windows）；POSIX 替换式 rename 的竞态未在原生环境验证。
- 被占用文件在"占用解除后重试"：A1 只验证失败现场与释放；未验证第二次执行成功（既有能力，未回归）。
- 撤销失败后的重试成功：A9 只验证第一次失败的现场。
- 大文件复制、磁盘满、只读属性、`os.makedirs` 失败等分支：本轮不涉及（复制路径已删除）。
- GUI 层错误提示文案与交互：本轮只测 executor 层。
- 扫描期取消入口：产品没有，继续列未测，不新增按钮。
- 20 个检查项不等于 20 个功能点：其中 2 项是修复前反例、1 项是"已移除路径"的显式未测记录、1 项是子进程退出码闸门。

---

## 9. 交付物

| 路径 | 内容 |
| --- | --- |
| `consultant/` | 本轮顾问 review.md 与 post_publish_probes.json 原样副本 |
| `patches/stage6b_windows_source.patch` | 冻结基线 → 最终源码（23 文件，+6373/−27） |
| `patches/stage6b_windows_source.stat.txt` | 补丁改动统计 |
| `patches/apply_check.log` | `apply --check` / `apply` 退出码 + 74 文件逐一比对 |
| `source_snapshot/SHA256SUMS.txt` | 74 个源码资产逐文件 SHA-256 |
| `source_snapshot/changed_files.json` | 23 项补丁产物 + 1 个单独入口 + 2 项被取代文件 + 验证口径 |
| `source_snapshot/changed_files/` | 改动文件扁平副本（含 `run_stage6b.ps1`） |
| `prefix_logs/suite.stdout.log` / `suite.stderr.log` | 正式运行完整输出 |
| `prefix_logs/results.json` | 20 项结构化结果 |
| `prefix_logs/outer_powershell_exitcode.json` | L1/L2/L3 |
| `prefix_logs/caller_observed_exit.txt` | L4 |
| `prefix_logs/a7_manifest_before.json` | A7 执行前逐文件清单（含 SHA-256） |
| `run_stage6b.ps1` | 复现入口（单独提供，非补丁产物） |
| `evidence_index.json` / `FILES.sha256.txt` | 全部文件定稿后生成，并已逐条重算校验 |

旧交付与顾问证据目录均未改动。
