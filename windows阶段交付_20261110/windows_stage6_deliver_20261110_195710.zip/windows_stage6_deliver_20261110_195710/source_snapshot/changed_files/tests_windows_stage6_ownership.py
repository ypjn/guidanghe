"""S6：异常移动的文件所有权与残留处理（定向补验，全部独立合成目录）。

被测对象：executor.execute_plan / undo_latest_batch 的异常移动路径。

约束（按顾问审阅）：
- 不能用“目标内容与源相同”当作“目标由本次操作创建”的证据；
- 未能证明归属的目标一律保留，不覆盖、不删除；
- 部分复制、清理失败、源变化必须准确记录，不能静默当“磁盘未改变”；
- 复用现有历史/错误/恢复机制，不新增产品功能。

故障注入一律用测试专属同步点（模块级 os/shutil 代理），不改产品代码。
修复前的两份反例代码冻结在 tests/frozen_executor_stage5.py，用于长期复现对照。
"""
from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import json
import os
import sys
import threading
import time

TESTS = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(TESTS)
sys.path.insert(0, SRC)
sys.path.insert(0, TESTS)

from windows_harness import (Results, RunDir, run_child, full_manifest,  # noqa: E402
                             save_manifest, sha256_file, diff_manifests)

BASE = os.environ.get("ARCHIVEBOX_TEST_BASE",
                      os.path.join(os.environ.get("TEMP", "/tmp"), "_abx_s6"))
OUT = os.environ.get("ARCHIVEBOX_RESULTS_DIR", os.path.join(BASE, "results"))
os.makedirs(OUT, exist_ok=True)

rd = RunDir(BASE, "s6")
CH = rd.sub("children")
R = Results("s6_ownership")
print(f"=== S6 run={rd.run_id} ===")

import planner  # noqa: E402
from scanner import scan_directory  # noqa: E402
from planner import MODE_BY_COURSE_THEN_TYPE  # noqa: E402
import executor as ex  # noqa: E402
from executor import execute_plan, undo_latest_batch, TMP_PREFIX  # noqa: E402
from storage import Storage  # noqa: E402

TMP_MARK = TMP_PREFIX


# ------------------------------------------------------------------ 工具
def mkfile(root, rel, data):
    p = os.path.join(root, rel.replace("/", os.sep))
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "wb") as f:
        f.write(data if isinstance(data, bytes) else data.encode("utf-8"))
    return p


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def plan_of(root):
    sr = scan_directory(root)
    return planner.generate_plan(sr, MODE_BY_COURSE_THEN_TYPE,
                                 planner.DEFAULT_COURSE_RULES)


def tmp_files_under(root):
    found = []
    for dp, _, fn in os.walk(root):
        for n in fn:
            if n.startswith(TMP_MARK):
                found.append(os.path.join(dp, n))
    return found


class OsProxy:
    """只代理 rename/remove，其余属性原样转发。"""

    def __init__(self, real, rename_fn=None, remove_fn=None):
        self._real = real
        self._rename = rename_fn
        self._remove = remove_fn

    def rename(self, a, b, *args, **kw):
        if self._rename:
            return self._rename(a, b, *args, **kw)
        return self._real.rename(a, b, *args, **kw)

    def remove(self, p, *args, **kw):
        if self._remove:
            return self._remove(p, *args, **kw)
        return self._real.remove(p, *args, **kw)

    def __getattr__(self, name):
        return getattr(self._real, name)


class ShutilProxy:
    def __init__(self, real, copyfileobj_fn=None, move_fn=None):
        self._real = real
        self._copyfileobj = copyfileobj_fn
        self._move = move_fn

    def copyfileobj(self, fsrc, fdst, length=0):
        if self._copyfileobj:
            return self._copyfileobj(fsrc, fdst, length)
        return self._real.copyfileobj(fsrc, fdst, length)

    def move(self, src, dst, *args, **kw):
        if self._move:
            return self._move(src, dst, *args, **kw)
        return self._real.move(src, dst, *args, **kw)

    def __getattr__(self, name):
        return getattr(self._real, name)


@contextlib.contextmanager
def faults(mod, rename=None, remove=None, copyfileobj=None, move=None):
    real_os, real_sh = mod.os, mod.shutil
    mod.os = OsProxy(real_os, rename, remove)
    mod.shutil = ShutilProxy(real_sh, copyfileobj, move)
    try:
        yield
    finally:
        mod.os, mod.shutil = real_os, real_sh


def load_frozen():
    """加载修复前的冻结副本（仅用于复现反例）。"""
    p = os.path.join(TESTS, "frozen_executor_stage5.py")
    name = "frozen_executor_stage5"
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m          # dataclass 需要能按 __module__ 找到模块
    spec.loader.exec_module(m)
    return m


# ============================================================ X. 修复前反例（冻结副本）
frozen = load_frozen()

# ---- X1 外部同内容目标被错误删除
root = rd.sub("x1")
src_rel = "大二上/数据结构/讲义.pdf"
src_abs = mkfile(root, src_rel, "SAME-CONTENT-123")
plan = plan_of(root)
tgt_rel = plan.items[0].target_rel_path
tgt_abs = os.path.join(root, tgt_rel.replace("\\", os.sep))
data = open(src_abs, "rb").read()
state = {"hit": False}


def x1_rename(a, b, *args, **kw):
    if not state["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
        state["hit"] = True
        with open(b, "wb") as f:
            f.write(data)              # 存在性检查之后，外部程序写入同内容文件
        raise OSError(32, "injected: 外部程序在检查后创建了目标")
    return os.rename(a, b)


def x1_move(a, b, *args, **kw):
    with open(b, "wb") as f:
        f.write(data)                  # 模拟 move 复制出目标后失败
    raise OSError(32, "injected move failure")


st = Storage(root)
with faults(frozen, rename=x1_rename, move=x1_move):
    res = frozen.execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
x1_err = (acts[0].error or "") if acts else ""
x1 = {"moved": res.moved, "failed": res.failed,
      "src": os.path.isfile(src_abs), "tgt": os.path.isfile(tgt_abs),
      "err": x1_err}
R.check("X1", "修复前（冻结副本）反例：外部同内容目标被当作“本次副本”删除",
        x1["failed"] == 1 and x1["src"] and not x1["tgt"]
        and "已清理本次失败留下的目标副本" in x1["err"],
        json.dumps(x1, ensure_ascii=False))
st.close()

# ---- X2 部分复制残留且只有 failed
root = rd.sub("x2")
src_abs = mkfile(root, src_rel, "PARTIAL-SOURCE")
plan = plan_of(root)
tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
state = {"hit": False}


def x2_rename(a, b, *args, **kw):
    if not state["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
        state["hit"] = True
        raise OSError(32, "injected: rename 失败")
    return os.rename(a, b)


def x2_move(a, b, *args, **kw):
    with open(b, "wb") as f:
        f.write(b"partia")             # 只写了部分字节
    raise OSError(28, "injected: 复制中途失败")


st = Storage(root)
with faults(frozen, rename=x2_rename, move=x2_move):
    res = frozen.execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
x2 = {"failed": res.failed, "tgt": os.path.isfile(tgt_abs),
      "tgt_bytes": open(tgt_abs, "rb").read().decode("utf-8", "replace") if os.path.isfile(tgt_abs) else None,
      "err": (acts[0].error or "") if acts else ""}
R.check("X2", "修复前（冻结副本）反例：部分复制残留、历史只有 failed、无残留说明",
        x2["failed"] == 1 and x2["tgt"] and x2["tgt_bytes"] == "partia"
        and "残留" not in x2["err"],
        json.dumps(x2, ensure_ascii=False))
st.close()

# ---- X3 修复前撤销异常：原始路径出现半成品
root = rd.sub("x3")
src_abs = mkfile(root, src_rel, "UNDO-CONTENT")
plan = plan_of(root)
st = Storage(root)
res = execute_plan(plan, st)
tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
state = {"hit": False}


def x3_rename(a, b, *args, **kw):
    if not state["hit"] and os.path.abspath(a) == os.path.abspath(tgt_abs):
        state["hit"] = True
        raise OSError(32, "injected: 撤销 rename 失败")
    return os.rename(a, b)


def x3_move(a, b, *args, **kw):
    with open(b, "wb") as f:
        f.write(b"undo-partial")
    raise OSError(28, "injected: 撤销复制中途失败")


with faults(frozen, rename=x3_rename, move=x3_move):
    ures = frozen.undo_latest_batch(st)
acts = st.get_actions(res.batch_id)
x3 = {"conflict": ures.conflict, "errors": ures.errors,
      "src": os.path.isfile(src_abs),
      "src_bytes": open(src_abs, "rb").read().decode("utf-8", "replace") if os.path.isfile(src_abs) else None,
      "status": acts[0].status if acts else "",
      "err": (acts[0].error or "") if acts else ""}
R.check("X3", "修复前（冻结副本）反例：撤销异常在原始路径留下半成品，重试会以“原路径已被占用”卡住",
        x3["src"] and x3["src_bytes"] == "undo-partial" and x3["status"] == "conflict"
        and "恢复失败" in x3["err"],
        json.dumps(x3, ensure_ascii=False))
st.close()

# ============================================================ A1. 原占用反例（修复后）
root = rd.sub("a1")
mkfile(root, "大二上/数据结构/甲-未占用.pdf", "FREE")
held_rel = "大二上/数据结构/乙-被占用.pdf"
held_abs = mkfile(root, held_rel, "HELD")
held_sha = sha(held_abs)

ready = os.path.join(CH, "a1_ready.json")
release = os.path.join(CH, "a1_release.flag")
HOLDER = r'''
import ctypes, json, os, sys, time
from ctypes import wintypes
path = r"__PATH__"
ready = r"__READY__"
release = r"__RELEASE__"
GENERIC_READ = 0x80000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
OPEN_EXISTING = 3
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                            ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
                            ctypes.c_void_p]
k32.CreateFileW.restype = ctypes.c_void_p
INVALID = ctypes.c_void_p(-1).value
h = k32.CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                    None, OPEN_EXISTING, 0, None)
ok = h not in (None, INVALID)
info = {"handle_ok": bool(ok), "handle": hex(h) if ok else None,
        "share_mode": "FILE_SHARE_READ|FILE_SHARE_WRITE (无 FILE_SHARE_DELETE)",
        "get_last_error": ctypes.get_last_error(), "pid": os.getpid()}
with open(ready, "w", encoding="utf-8") as f:
    json.dump(info, f, ensure_ascii=False)
if not ok:
    sys.exit(3)
deadline = time.time() + 90
while not os.path.exists(release) and time.time() < deadline:
    time.sleep(0.05)
k32.CloseHandle(ctypes.c_void_p(h))
sys.exit(0)
'''.replace("__PATH__", held_abs).replace("__READY__", ready).replace(
    "__RELEASE__", release)

rec_holder = {}


def _hold():
    rec_holder["rec"] = run_child(HOLDER, "a1_holder", CH, BASE, timeout=120)


th = threading.Thread(target=_hold, daemon=True)
th.start()
t0 = time.time()
while time.time() - t0 < 60 and not os.path.exists(ready):
    time.sleep(0.05)
info = {}
if os.path.exists(ready):
    info = json.load(open(ready, encoding="utf-8"))
R.check("A1_1", "占用子进程已按显式共享模式（无 FILE_SHARE_DELETE）打开目标文件",
        bool(info.get("handle_ok")), json.dumps(info, ensure_ascii=False))

probe = held_abs + ".__probe"
probe_err = ""
try:
    os.rename(held_abs, probe)
    probe_err = "改名成功（占用未建立）"
    os.rename(probe, held_abs)
except OSError as e:
    probe_err = f"{type(e).__name__}: winerror={getattr(e, 'winerror', None)} {e}"
R.check("A1_2", "父进程改名探测被拒 → 占用客观成立，不是“声称已占用”",
        "占用未建立" not in probe_err and not os.path.exists(probe), probe_err)

plan = plan_of(root)
st = Storage(root)
res = execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
failed = [a for a in acts if a.status == "failed"]
free_ok = [a for a in acts if a.status == "moved"]
tgt_held = (os.path.join(root, failed[0].target_rel.replace("/", os.sep))
            if failed else "")
R.check("A1_3", "占用中执行：未占用项 moved、占用项 failed，失败未记成成功",
        res.moved == 1 and res.failed == 1
        and len(failed) == 1 and len(free_ok) == 1
        and failed[0].source_rel.replace("\\", "/") == held_rel,
        f"summary={res.summary()} actions="
        f"{[(a.source_rel, a.status) for a in acts]}")
a1_err = failed[0].error if failed else ""
R.check("A1_4", "占用失败项：源文件原样保留、目标位不存在、无临时残留，错误串写清“已撤回”",
        bool(failed) and os.path.isfile(held_abs) and sha(held_abs) == held_sha
        and not os.path.isfile(tgt_held)
        and not tmp_files_under(root)
        and "无法删除原文件" in a1_err and "已撤回本次发布的目标副本" in a1_err,
        f"src={os.path.isfile(held_abs)} tgt={os.path.isfile(tgt_held)} "
        f"tmp={tmp_files_under(root)} err={a1_err}")
st.close()
open(release, "w").close()
th.join(20)
R.check("A1_5", "释放占用后持有进程正常退出（exit=0，无超时）",
        th.is_alive() is False and rec_holder.get("rec", {}).get("exit_code") == 0
        and rec_holder.get("rec", {}).get("timed_out") is False,
        json.dumps({k: rec_holder.get("rec", {}).get(k)
                    for k in ("exit_code", "exit_code_kind", "timed_out")},
                   ensure_ascii=False))

# ============================================================ A2/A3. 检查后外部创建目标
def external_target_case(tag, ext_bytes):
    root = rd.sub(tag)
    src_abs = mkfile(root, src_rel, "SRC-FOR-" + tag)
    plan = plan_of(root)
    tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
    stt = {"hit": False}

    def rn(a, b, *args, **kw):
        if not stt["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
            stt["hit"] = True
            with open(b, "wb") as f:
                f.write(ext_bytes)      # 存在性检查之后才出现的外部文件
            raise OSError(32, "injected: 外部程序在检查后创建了目标")
        return os.rename(a, b)

    stx = Storage(root)
    with faults(ex, rename=rn):
        r = execute_plan(plan, stx)
    a = stx.get_actions(r.batch_id)
    stx.close()
    return {
        "moved": r.moved, "failed": r.failed,
        "src": os.path.isfile(src_abs),
        "tgt": os.path.isfile(tgt_abs),
        "tgt_bytes": open(tgt_abs, "rb").read() if os.path.isfile(tgt_abs) else None,
        "want": ext_bytes,
        "tmp": tmp_files_under(root),
        "err": (a[0].error or "") if a else "",
        "status": a[0].status if a else "",
    }


c2 = external_target_case("a2", b"EXTERNAL-IDENTICAL")
R.check("A2", "目标检查后外部创建同内容文件：外部文件保留、字节不变、源保留、历史 failed 且写明“不是本次创建”",
        c2["status"] == "failed" and c2["src"] and c2["tgt"]
        and c2["tgt_bytes"] == c2["want"] and c2["want"] == b"EXTERNAL-IDENTICAL"
        and not c2["tmp"] and "已保留未动" in c2["err"],
        json.dumps({k: c2[k] for k in ("status", "src", "tgt", "tmp", "err")},
                   ensure_ascii=False))

c3 = external_target_case("a3", b"EXTERNAL-DIFFERENT")
R.check("A3", "目标检查后外部创建不同内容文件：同样不覆盖、不删除，历史 failed 且写明保留",
        c3["status"] == "failed" and c3["src"] and c3["tgt"]
        and c3["tgt_bytes"] == c3["want"]
        and not c3["tmp"] and "已保留未动" in c3["err"],
        json.dumps({k: c3[k] for k in ("status", "src", "tgt", "tmp", "err")},
                   ensure_ascii=False))

# ============================================================ A4. 部分复制
root = rd.sub("a4")
src_abs = mkfile(root, src_rel, "PARTIAL-A4")
src_sha = sha(src_abs)
plan = plan_of(root)
tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
stt = {"hit": False}


def a4_rename(a, b, *args, **kw):
    if not stt["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
        stt["hit"] = True
        raise OSError(32, "injected: rename 失败")
    return os.rename(a, b)


def a4_copy(fsrc, fdst, length=0):
    fdst.write(fsrc.read(6))
    raise OSError(28, "injected: 复制中途失败（磁盘已写入部分字节）")


st = Storage(root)
with faults(ex, rename=a4_rename, copyfileobj=a4_copy):
    res = execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
a4_err = (acts[0].error or "") if acts else ""
a4 = {"failed": res.failed, "src": os.path.isfile(src_abs),
      "src_sha_ok": os.path.isfile(src_abs) and sha(src_abs) == src_sha,
      "tgt": os.path.isfile(tgt_abs), "tmp": tmp_files_under(root), "err": a4_err}
R.check("A4", "复制部分字节后失败：不产生目标、源未变、临时副本已清理或残留路径明确写出",
        a4["failed"] == 1 and a4["src"] and a4["src_sha_ok"] and not a4["tgt"]
        and ("复制到临时副本时失败" in a4["err"])
        and (("已清理" in a4["err"] and not a4["tmp"])
             or ("残留临时文件" in a4["err"] and len(a4["tmp"]) == 1)),
        json.dumps(a4, ensure_ascii=False))
st.close()

# ============================================================ A5. 自有临时副本清理失败
root = rd.sub("a5")
src_abs = mkfile(root, src_rel, "CLEANUP-FAIL")
plan = plan_of(root)
tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
stt = {"hit": False}


def a5_rename(a, b, *args, **kw):
    if not stt["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
        stt["hit"] = True
        raise OSError(32, "injected: rename 失败")
    return os.rename(a, b)


def a5_remove(p, *args, **kw):
    if TMP_MARK in os.path.basename(p):
        raise OSError(32, "injected: 临时副本被其他程序占用，清理失败")
    return os.remove(p, *args, **kw)


st = Storage(root)
with faults(ex, rename=a5_rename, remove=a5_remove, copyfileobj=a4_copy):
    res = execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
a5_err = (acts[0].error or "") if acts else ""
a5_tmp = tmp_files_under(root)
a5 = {"failed": res.failed, "src": os.path.isfile(src_abs),
      "tgt": os.path.isfile(tgt_abs), "tmp": a5_tmp, "err": a5_err}
R.check("A5", "本次临时副本清理失败：原始异常与清理失败都可追溯，残留临时文件路径写进历史且文件确实存在",
        a5["failed"] == 1 and a5["src"] and not a5["tgt"] and len(a5_tmp) == 1
        and "复制到临时副本时失败" in a5_err
        and "本次临时副本清理失败" in a5_err
        and os.path.normcase(a5_tmp[0]).replace("\\", "/")
        in os.path.normcase(a5_err).replace("\\", "/"),
        json.dumps(a5, ensure_ascii=False))
st.close()
for p in a5_tmp:
    try:
        os.remove(p)
    except OSError:
        pass

# ============================================================ A6. 复制期间源内容变化
root = rd.sub("a6")
src_abs = mkfile(root, src_rel, "SOURCE-V1")
plan = plan_of(root)
tgt_abs = os.path.join(root, plan.items[0].target_rel_path.replace("\\", os.sep))
stt = {"hit": False}


def a6_rename(a, b, *args, **kw):
    if not stt["hit"] and os.path.abspath(a) == os.path.abspath(src_abs):
        stt["hit"] = True
        raise OSError(32, "injected: rename 失败")
    return os.rename(a, b)


def a6_copy(fsrc, fdst, length=0):
    # 复制开始后、结束前，外部进程改写源文件；
    # 本次复制读到的是改动后的内容（不是计划时那份），因此临时副本哈希 ≠ 计划哈希。
    with open(src_abs, "ab") as f:
        f.write(b"|EXTERNAL-APPEND")
        f.flush()
        os.fsync(f.fileno())
    with open(src_abs, "rb") as f:
        fdst.write(f.read())


st = Storage(root)
with faults(ex, rename=a6_rename, copyfileobj=a6_copy):
    res = execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
a6_err = (acts[0].error or "") if acts else ""
a6_src_bytes = open(src_abs, "rb").read() if os.path.isfile(src_abs) else b""
a6 = {"failed": res.failed, "src": os.path.isfile(src_abs),
      "src_bytes": a6_src_bytes.decode("utf-8", "replace"),
      "tgt": os.path.isfile(tgt_abs), "tmp": tmp_files_under(root), "err": a6_err}
R.check("A6", "复制期间源内容变化：不发布、不按变化后的内容认定完成，源保留改动后的内容",
        a6["failed"] == 1 and a6["src"] and not a6["tgt"]
        and "|EXTERNAL-APPEND" in a6["src_bytes"]
        and "内容发生变化" in a6_err and not a6["tmp"],
        json.dumps(a6, ensure_ascii=False))
st.close()

# ============================================================ A7. 失败后新进程诊断与恢复
root = rd.sub("a7")
src_abs = mkfile(root, src_rel, "NEWPROC-SRC")
before = full_manifest(root)
save_manifest(os.path.join(OUT, "a7_manifest_before.json"), before,
              {"phase": "before"})

CHILD_EXEC = r'''
import json, os, sys
sys.path.insert(0, r"__SRC__")
import executor as ex
from scanner import scan_directory
import planner
from storage import Storage
root = r"__ROOT__"
sr = scan_directory(root)
plan = planner.generate_plan(sr, planner.MODE_BY_COURSE_THEN_TYPE,
                             planner.DEFAULT_COURSE_RULES)
it = plan.items[0]
src = os.path.join(root, it.file.rel_path.replace("/", os.sep))
tgt = os.path.join(root, it.target_rel_path.replace("/", os.sep))
data = open(src, "rb").read()
real = ex.os
class P:
    def __init__(self, r):
        self._r = r
        self.hit = False
    def rename(self, a, b, *args, **kw):
        if not self.hit and os.path.abspath(a) == os.path.abspath(src):
            self.hit = True
            with open(b, "wb") as f:
                f.write(data)
            raise OSError(32, "injected: 外部程序在检查后创建了目标")
        return self._r.rename(a, b)
    def __getattr__(self, n):
        return getattr(self._r, n)
ex.os = P(real)
st = Storage(root)
res = ex.execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
print(json.dumps({"batch_id": res.batch_id, "failed": res.failed,
                  "moved": res.moved,
                  "actions": [{"status": a.status, "error": a.error,
                               "source_rel": a.source_rel,
                               "target_rel": a.target_rel} for a in acts],
                  "src": os.path.isfile(src), "tgt": os.path.isfile(tgt)}, ensure_ascii=False))
st.close()
'''.replace("__SRC__", SRC).replace("__ROOT__", root)

CHILD_INSPECT = r'''
import json, os, sys
sys.path.insert(0, r"__SRC__")
from storage import Storage
root = r"__ROOT__"
st = Storage(root)
bs = st.list_batches()
out = {"batches": [], "tmp": []}
for b in bs:
    out["batches"].append({"id": b.batch_id, "status": b.status,
                           "actions": [{"status": a.status, "error": a.error,
                                        "source_rel": a.source_rel,
                                        "target_rel": a.target_rel}
                                       for a in b.actions]})
for dp, _, fn in os.walk(root):
    for n in fn:
        if n.startswith("__PREFIX__"):
            out["tmp"].append(os.path.join(dp, n))
print(json.dumps(out, ensure_ascii=False))
st.close()
'''.replace("__SRC__", SRC).replace("__ROOT__", root).replace(
    "__PREFIX__", TMP_MARK)

CHILD_UNDO = r'''
import json, os, sys
sys.path.insert(0, r"__SRC__")
from storage import Storage
from executor import undo_latest_batch
root = r"__ROOT__"
st = Storage(root)
r = undo_latest_batch(st)
bs = st.list_batches()
print(json.dumps({"restored": r.restored, "conflict": r.conflict,
                  "errors": r.errors, "batch_status": bs[0].status if bs else ""},
                 ensure_ascii=False))
st.close()
'''.replace("__SRC__", SRC).replace("__ROOT__", root)

rec_exec = run_child(CHILD_EXEC, "a7_exec", CH, BASE, timeout=120)
rec_insp = run_child(CHILD_INSPECT, "a7_inspect", CH, BASE, timeout=120)
rec_undo = run_child(CHILD_UNDO, "a7_undo", CH, BASE, timeout=120)
o_exec = json.loads(rec_exec["stdout"].strip().splitlines()[-1] or "{}")
o_insp = json.loads(rec_insp["stdout"].strip().splitlines()[-1] or "{}")
o_undo = json.loads(rec_undo["stdout"].strip().splitlines()[-1] or "{}")
a7_tgt = os.path.join(root, o_exec["actions"][0]["target_rel"].replace("/", os.sep))
a7_want = hashlib.sha256(b"NEWPROC-SRC").hexdigest()
R.check("A7_1", "新进程读历史：状态与错误原样可读，外部目标未被删除、未被覆盖",
        o_exec["failed"] == 1 and o_exec["src"] and o_exec["tgt"]
        and os.path.isfile(a7_tgt) and sha(a7_tgt) == a7_want
        and o_insp["batches"] and o_insp["batches"][0]["actions"][0]["status"] == "failed"
        and "已保留未动" in o_insp["batches"][0]["actions"][0]["error"],
        json.dumps({"exec": o_exec, "inspect_status":
                    o_insp["batches"][0]["actions"][0]["status"] if o_insp["batches"] else None},
                   ensure_ascii=False))
R.check("A7_2", "新进程看不到任何临时副本残留（磁盘与历史一致）",
        o_insp["tmp"] == [] and o_exec["failed"] == 1,
        json.dumps({"tmp": o_insp["tmp"]}, ensure_ascii=False))
R.check("A7_3", "新进程按现有撤销流程处理：无 moved 可撤销、外部目标与源都保留，不静默删除",
        o_undo["restored"] == 0 and os.path.isfile(a7_tgt) and sha(a7_tgt) == a7_want
        and os.path.isfile(src_abs) and sha(src_abs) == a7_want,
        json.dumps({"undo": o_undo, "tgt_ok": os.path.isfile(a7_tgt),
                    "src_ok": os.path.isfile(src_abs)}, ensure_ascii=False))

# ============================================================ A8. 正常整理 + 撤销回归
root = rd.sub("a8")
mkfile(root, "大二上/数据结构/讲义.pdf", "NORMAL-1")
mkfile(root, "图片素材/logo.png", "NORMAL-2")
m0 = full_manifest(root)
save_manifest(os.path.join(OUT, "a8_manifest_before.json"), m0, {"phase": "before"})
plan = plan_of(root)
st = Storage(root)
res = execute_plan(plan, st)
m1 = full_manifest(root)
R.check("A8_1", "正常整理小样本：2 项 moved、无 failed、无临时文件、源目录已空",
        res.moved == 2 and res.failed == 0 and not tmp_files_under(root)
        and len(diff_manifests(m0, m1)["extra"]) == 2,
        f"summary={res.summary()} diff={diff_manifests(m0, m1)}")
ures = undo_latest_batch(st)
m2 = full_manifest(root)
R.check("A8_2", "正常撤销小样本：完整恢复，逐文件清单（含 SHA-256）与初始一致",
        ures.restored == 2 and ures.conflict == 0 and ures.errors == 0
        and m2 == m0,
        f"restore={ures.restored} conflict={ures.conflict} errors={ures.errors} "
        f"diff={diff_manifests(m0, m2)}")
st.close()

# ============================================================ A9. 撤销异常路径（修复后）
root = rd.sub("a9")
src_abs = mkfile(root, src_rel, "UNDO-A9")
st = Storage(root)
res = execute_plan(plan_of(root), st)
tgt_abs = os.path.join(root, st.get_actions(res.batch_id)[0].target_rel.replace("/", os.sep))
tgt_sha = sha(tgt_abs)
stt = {"hit": False}


def a9_rename(a, b, *args, **kw):
    if not stt["hit"] and os.path.abspath(a) == os.path.abspath(tgt_abs):
        stt["hit"] = True
        raise OSError(32, "injected: 撤销 rename 失败")
    return os.rename(a, b)


with faults(ex, rename=a9_rename, copyfileobj=a4_copy):
    ures = undo_latest_batch(st)
acts = st.get_actions(res.batch_id)
a9 = {"conflict": ures.conflict, "errors": ures.errors,
      "src": os.path.isfile(src_abs), "tgt": os.path.isfile(tgt_abs),
      "tmp": tmp_files_under(root), "status": acts[0].status,
      "err": acts[0].error}
R.check("A9", "撤销异常：原始路径不留半成品、目标未丢、状态 conflict 且错误串含失败原因与残留处理说明",
        a9["errors"] == 1 and a9["conflict"] == 0 and a9["src"] is False
        and a9["tgt"] and sha(tgt_abs) == tgt_sha and not a9["tmp"]
        and a9["status"] == "conflict" and "恢复失败" in a9["err"]
        and ("已清理" in a9["err"] or "残留临时文件" in a9["err"]),
        json.dumps({k: a9[k] for k in ("conflict", "errors", "src", "tgt", "tmp",
                                       "status", "err")},
                   ensure_ascii=False))
st.close()

# ============================================================ 收尾
R.check_child_exits("S6_EXIT",
                    title_extra="占用持有进程 a1_holder 必须 exit=0；"
                                "预期故障注入在父进程内完成，不产生子进程")
sys.exit(R.finalize(os.path.join(OUT, "results.json"),
                    required_ids=["X1", "X2", "X3",
                                  "A1_1", "A1_2", "A1_3", "A1_4", "A1_5",
                                  "A2", "A3", "A4", "A5", "A6",
                                  "A7_1", "A7_2", "A7_3",
                                  "A8_1", "A8_2", "A9", "S6_EXIT"]))
