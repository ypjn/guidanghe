"""N5 复核：由独立进程重新打开 CON.txt，验证字节持久（不是仅创建时可见）。"""
import json
import os
import stat
import sys

d = sys.argv[1]
p = os.path.join(d, "CON.txt")
out = {"listdir": sorted(os.listdir(d)), "exists": os.path.isfile(p)}
if out["exists"]:
    st = os.stat(p)
    with open(p, "rb") as f:
        out["bytes"] = f.read().decode("ascii")
    out["is_regular"] = stat.S_ISREG(st.st_mode)
    out["size"] = st.st_size
print(json.dumps(out, ensure_ascii=False))
