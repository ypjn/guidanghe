
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
from storage import Storage
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6_deliver_20261110_195710\runtime\runs\s6_20261110_200459_3b9f8d\a7"
st = Storage(root)
bs = st.list_batches()
out = {"batches": [], "tmp": []}
for b in bs:
    out["batches"].append({"id": b.batch_id, "status": b.status,
                           "actions": [{"status": a.status, "error": a.error,
                                        "source_rel": a.source_rel,
                                        "target_rel": a.target_rel}
                                       for a in b.actions]})
for dp, _, fn in os.walk(root):
    for n in fn:
        if n.startswith(".abx-copy-"):
            out["tmp"].append(os.path.join(dp, n))
print(json.dumps(out, ensure_ascii=False))
st.close()
