
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
from storage import Storage
from executor import undo_latest_batch
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6_deliver_20261110_195710\runtime\runs\s6_20261110_200459_3b9f8d\a7"
st = Storage(root)
r = undo_latest_batch(st)
bs = st.list_batches()
print(json.dumps({"restored": r.restored, "conflict": r.conflict,
                  "errors": r.errors, "batch_status": bs[0].status if bs else ""},
                 ensure_ascii=False))
st.close()
