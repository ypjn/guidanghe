
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
import executor as ex
from scanner import scan_directory
import planner
from storage import Storage
root = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage6_deliver_20261110_195710\runtime\runs\s6_20261110_200459_3b9f8d\a7"
sr = scan_directory(root)
plan = planner.generate_plan(sr, planner.MODE_BY_COURSE_THEN_TYPE,
                             planner.DEFAULT_COURSE_RULES)
it = plan.items[0]
src = os.path.join(root, it.file.rel_path.replace("/", os.sep))
tgt = os.path.join(root, it.target_rel_path.replace("/", os.sep))
data = open(src, "rb").read()
real = ex.os
class P:
    def __init__(self, r):
        self._r = r
        self.hit = False
    def rename(self, a, b, *args, **kw):
        if not self.hit and os.path.abspath(a) == os.path.abspath(src):
            self.hit = True
            with open(b, "wb") as f:
                f.write(data)
            raise OSError(32, "injected: 外部程序在检查后创建了目标")
        return self._r.rename(a, b)
    def __getattr__(self, n):
        return getattr(self._r, n)
ex.os = P(real)
st = Storage(root)
res = ex.execute_plan(plan, st)
acts = st.get_actions(res.batch_id)
print(json.dumps({"batch_id": res.batch_id, "failed": res.failed,
                  "moved": res.moved,
                  "actions": [{"status": a.status, "error": a.error,
                               "source_rel": a.source_rel,
                               "target_rel": a.target_rel} for a in acts],
                  "src": os.path.isfile(src), "tgt": os.path.isfile(tgt)}, ensure_ascii=False))
st.close()
