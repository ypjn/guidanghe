"""生成交付索引并立即自校验（用 Python 读字节，避免 PowerShell 对 CON.txt 的设备名解析）。

- 覆盖交付目录下所有文件，排除 evidence_index.json 与 FILES.sha256.txt 自身；
- 写出后重新读盘逐文件重算，与索引值比较，把结果写入 self_check；
- 有任何不一致则以非零退出码结束。
"""
import hashlib
import json
import os
import sys
import time

root = os.path.abspath(sys.argv[1])
EXCLUDE = {"evidence_index.json", "FILES.sha256.txt"}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


entries = []
for dirpath, dirnames, filenames in os.walk(root):
    dirnames.sort()
    for name in sorted(filenames):
        abs_path = os.path.join(dirpath, name)
        rel = os.path.relpath(abs_path, root).replace(os.sep, "/")
        if rel in EXCLUDE:
            continue
        st = os.stat(abs_path)
        entries.append({"path": rel, "size": st.st_size, "sha256": sha256(abs_path)})

entries.sort(key=lambda e: e["path"])

with open(os.path.join(root, "FILES.sha256.txt"), "w", encoding="utf-8", newline="\n") as f:
    for e in entries:
        f.write(f"{e['sha256']}  {e['path']}\n")

rechecked, problems = 0, []
for e in entries:
    p = os.path.join(root, e["path"].replace("/", os.sep))
    if not os.path.isfile(p):
        problems.append(f"MISSING {e['path']}")
        continue
    if sha256(p) != e["sha256"]:
        problems.append(f"DIFF {e['path']}")
    else:
        rechecked += 1

doc = {
    "schema": "archivebox.delivery.evidence_index/1",
    "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "deliver_dir": root,
    "algorithm": "sha256",
    "excluded": sorted(EXCLUDE),
    "entry_count": len(entries),
    "entries": entries,
    "self_check": {
        "method": "写出后用 Python 重新读盘逐文件重算 SHA-256 并与索引值比较",
        "rechecked": rechecked,
        "mismatches": len(problems),
        "problems": problems,
        "note": "索引在全部文件定稿后生成；path 为相对交付目录的 POSIX 形式；"
                "CON.txt 用 Python 读取（PowerShell 会按设备名解析而失败）",
    },
}
with open(os.path.join(root, "evidence_index.json"), "w", encoding="utf-8", newline="\n") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)

print(f"entries={len(entries)} rechecked={rechecked} mismatches={len(problems)}")
for p in problems[:10]:
    print("  " + p)
sys.exit(0 if not problems else 1)
