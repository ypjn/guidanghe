"""N5 复核：在本机独立合成目录实测 CON.txt 的真实身份（创建 + 目录项 + stat）。"""
import json
import os
import stat
import sys

d = sys.argv[1]
os.makedirs(d, exist_ok=True)
p = os.path.join(d, "CON.txt")
out = {"dir": d, "path": p}
try:
    with open(p, "wb") as f:
        f.write(b"HELLO-CON-123")
    out["created"] = True
except OSError as e:
    out["created"] = False
    out["create_error"] = f"{type(e).__name__}: winerror={getattr(e, 'winerror', None)} {e}"

out["listdir"] = sorted(os.listdir(d))
if out.get("created"):
    st = os.stat(p)
    out["stat"] = {
        "mode_oct": oct(stat.S_IMODE(st.st_mode)),
        "st_mode_oct": oct(st.st_mode),
        "is_regular": stat.S_ISREG(st.st_mode),
        "is_dir": stat.S_ISDIR(st.st_mode),
        "size": st.st_size,
        "ino": st.st_ino,
        "file_attributes": getattr(st, "st_file_attributes", None),
    }
    with open(p, "rb") as f:
        out["bytes_this_process"] = f.read().decode("ascii")
print(json.dumps(out, ensure_ascii=False))
