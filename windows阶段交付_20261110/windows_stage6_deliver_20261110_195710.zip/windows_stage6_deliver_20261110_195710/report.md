# 归档盒 V1.7 Windows 阶段 stage6 报告：异常移动的文件所有权与残留处理

- 交付目录：`windows_stage6_deliver_20261110_195710`
- 上一轮交付（只读、未改动）：`windows_stage5_deliver_20261110_191543`
- 顾问审阅与独立反例（原样收录于 `consultant/`）：
  - `stage5_review_20261110_194940/review.md`
  - `stage5_review_20261110_194940/cleanup_probes.json`
- 被审阅阻断点：`source_snapshot/changed_files/executor.py`（stage5 版本）第 216–229 行
- 运行环境：Windows 11 build 26200，Python 3.14.7，PySide6 6.12.0，LongPathsEnabled=1

本轮**只**做两件事：修正异常移动路径的文件所有权与残留处理；完善交付索引。没有新增产品功能、没有改 UI、没有改数据库 schema、没有扩展平台测试。

---

## 1. 阻断是什么，为什么 stage5 的修法不成立

stage5 的实现是：`os.rename` 失败 → `shutil.move` → 再失败 → **如果源和目标都存在且 SHA-256 相同，就删除目标**，并在错误串里写「已清理本次失败留下的目标副本」。

问题不在断言，在所有权推断：

- 「内容相同」不能证明「这个目标文件是本进程刚创建的」。目标可能是存在性检查之后，由别的程序写入的。
- 顾问用真实 `execute_plan` / `Storage` / 独立合成目录复现了两例（原文数据见 `consultant/cleanup_probes.json`）：
  1. `external_identical_target`：检查后外部写入同内容目标；rename 与 move 均失败；清理逻辑**删除了外部文件**，错误串还声称「已清理本次失败留下的目标副本」。
  2. `partial_copy`：复制部分字节后失败；目标残留 `"partial"`；哈希不同所以没删，但历史只记 `failed`，没有残留说明。
- 因此不能以「失败 = 源在、目标不在」作为实现前提。失败可能已经改变磁盘，必须如实记录。

本轮把这两例连同撤销路径的同类反例一起冻结成可长期复现的基线：`tests/frozen_executor_stage5.py`（stage5 交付中 `source_snapshot/changed_files/executor.py` 的原样副本），由 `X1/X2/X3` 三个用例驱动。

---

## 2. 修复前后的反例与结果（同一套件内对照）

| 用例 | 被测代码 | 注入 | 修复前（冻结副本）实测 | 修复后（本轮）实测 |
| --- | --- | --- | --- | --- |
| X1 | `frozen_executor_stage5.execute_plan` | 检查后外部创建同内容目标；rename / move 均失败 | 外部目标被删除：`tgt=false`，错误串含「已清理本次失败留下的目标副本」 | 不适用（这是修复前代码的定性证据） |
| X2 | 同上 | 复制部分字节后失败 | 残留目标 `tgt_bytes="partia"`，历史只有 `failed`，无残留说明 | 不适用 |
| X3 | `frozen_executor_stage5.undo_latest_batch` | 撤销时 rename 失败、move 复制一半失败 | 原始路径留下半成品 `src_bytes="undo-partial"`，状态 `conflict`，重试会被「原路径已被占用」永久卡住 | 不适用 |
| A2 | 本轮 `execute_plan` | 检查后外部创建**同内容**目标 | — | 外部文件保留、字节不变；源保留；`failed`；错误串写明「目标路径上的文件不是本次操作创建的，已保留未动」；无临时残留 |
| A3 | 本轮 `execute_plan` | 检查后外部创建**不同内容**目标 | — | 同样不覆盖、不删除；`failed`；同样写明保留 |
| A4 | 本轮 `execute_plan` | 复制部分字节后失败 | — | 不产生目标；源 SHA-256 不变；`failed`；错误串含「复制到临时副本时失败」+ 临时副本已清理（或写明残留路径） |
| A5 | 本轮 `execute_plan` | 本次自有临时副本删除失败 | — | `failed`；错误串同时含复制失败原因、清理失败原因、残留临时文件绝对路径；该文件在磁盘上确实存在 |
| A6 | 本轮 `execute_plan` | 复制期间源被外部追加内容 | — | 不发布；`failed`；错误串含「复制期间源文件内容发生变化（临时副本 … ≠ 计划时 …）」；源保留被追加后的内容 |
| A9 | 本轮 `undo_latest_batch` | 撤销 rename 失败 + 复制一半失败 | — | 原始路径**没有**半成品；目标文件与原哈希都在；状态 `conflict`；`errors=1`；错误串含失败原因与残留处理说明 |

完整逐条输出见 `prefix_logs/suite.stdout.log`，结构化结果见 `prefix_logs/results.json`。

---

## 3. 实现说明：所有权从哪里来，残留怎么记

改动只发生在 `executor.py`（本轮唯一改动的生产文件）。

### 3.1 所有权模型（不再用内容当授权）

1. **创建**：临时副本用 `os.open(tmp, O_WRONLY|O_CREAT|O_EXCL|O_BINARY, 0o600)` 独占创建，文件名 `.abx-copy-<pid>-<uuid10>.tmp`，位于**目标目录内**（同卷，保证发布是同一卷 rename）。
   - `O_EXCL` 保证这个名字此前不存在、且由本进程创建；`uuid` 保证并发不撞名。
   - 创建失败时返回「无法创建本次临时副本」，磁盘确定未改变。
2. **复制**：`shutil.copyfileobj` + `flush` + `fsync`；复制后计算临时副本 SHA-256，与**计划时记录的源哈希**比较。
   - 不一致 → 视为「复制期间源内容发生变化」，不发布，清理临时副本。
3. **发布**：`os.rename(tmp, target)`。Windows 语义下目标已存在即失败（`WinError 183`），**不会覆盖**。
4. **删除**：只允许删除两类文件——本进程用 `O_EXCL` 创建的唯一临时名，或本进程刚 `os.rename` 发布到目标位的那份。删除前若提供了发布时的 SHA-256，还会再校验一次（发布之后被别人改写就不删）。

**内容哈希从不作为「这个文件属于我」的证据**；它只有两个用途：复制完整性与计划一致性校验、发布后额外护栏。

### 3.2 失败分支与磁盘状态（写进现有历史字段）

| 分支 | 磁盘实际状态 | 历史 |
| --- | --- | --- |
| 临时副本创建失败 | 未改变 | `failed`：`无法创建本次临时副本…；本次未产生任何副本（原文件未动、目标未创建）` |
| 复制失败 | 可能有本进程临时文件 | `failed`：`复制到临时副本时失败：…；本次临时副本已清理（<文件名>）` 或 `…；本次临时副本清理失败：…；残留临时文件：<绝对路径>` |
| 复制期间源变化 | 临时副本内容与计划不符 | `failed`：`复制期间源文件内容发生变化（临时副本 xxxx… ≠ 计划时 yyyy…）；本次临时副本已清理…` |
| 发布失败（目标已存在） | 目标是他人的，保留 | `failed`：`发布失败：…；本次临时副本已清理…；目标路径上的文件不是本次操作创建的，已保留未动` |
| 发布成功但源删不掉（占用/权限） | 目标已发布（本次创建），源仍在 | `failed`：`复制已完成但无法删除原文件：…；已撤回本次发布的目标副本（原文件未动）` |
| 撤回也失败 | 目标与源都在，可能还有临时文件 | `failed`：`…；撤回目标副本失败：…；残留目标：<绝对路径>（原文件仍在：<绝对路径>）` |

### 3.3 状态选择（没有新增状态）

- 执行路径继续用现有 `failed`（`STATUS_FAILED`）。语义扩展为：**本次没有完成移动，且磁盘现状已在错误串里写清**；不再暗含「磁盘未改变」。
- 撤销路径继续用现有 `conflict`（`STATUS_CONFLICT`）并把 `UndoResult.errors` 加 1，与原实现的错误计数口径一致（`restored/conflict/errors` 三个计数不新增字段）。
- 不新增批次状态、不新增动作状态、不新增恢复入口；跨进程诊断复用 `storage.get_actions` / `list_batches` 里已有的 `status` + `error`。

### 3.4 撤销路径的同类修复

`undo_latest_batch` 原先在 `os.rename` 失败后直接 `shutil.move(target, source)`；失败会**在用户原始路径上留下半成品文件**（X3 实测 `undo-partial`），下一次撤销便以「原路径已被占用」永久冲突。本轮让撤销也走同一个 `_move_via_owned_temp`：先在源目录建自有临时副本，再 `os.rename` 发布到原始路径。原始路径没有半成品；目标文件保持不动且哈希不变；状态 `conflict` 并写清原因。

只对实际复现的这一处撤销异常路径做了修复，没有扩大范围。

### 3.5 明确的处理边界

- 目标位已存在的文件：**一律保留**，不覆盖、不删除，不管内容是否与本文件相同。
- 无法证明归属的东西：保留，并把路径写进历史；不猜、不静默清理。
- 本机制不负责清理历史遗留的、非本进程创建的文件；这类文件需要人工判断。
- 正常路径（`os.rename` 一次成功）**不会**产生任何临时文件。

---

## 4. 定向验证

### 4.1 断言统计（来自 `prefix_logs/results.json` 与 `suite.stdout.log`）

| 项 | 值 |
| --- | --- |
| 用例总数 | 20 |
| PASS / FAIL / BLOCK / 未测 | 20 / 0 / 0 / 0 |
| 必测项缺失 | 0 |
| 套件自报 `EXIT_CODE`（L1，不采信） | 0 |
| 被测进程真实 OS 退出码（L2） | 0 |
| 包装器准备返回（L3，`run_stage6.ps1`） | 0 |
| 调用者观察到的壳退出码（L4，`caller_observed_exit.txt`） | 0 |

四层记录见 `prefix_logs/outer_powershell_exitcode.json` 与 `prefix_logs/caller_observed_exit.txt`。四层均为 0 才视为通过；L1 单独为 0 不作为通过依据。

### 4.2 覆盖的 8 项要求（逐项对应）

| 要求 | 用例 | 关键证据（看文件，不只看计数） |
| --- | --- | --- |
| 1. 原 Windows 占用反例，显式共享模式持有 | A1_1–A1_5 | 子进程 `CreateFileW(GENERIC_READ, FILE_SHARE_READ\|FILE_SHARE_WRITE)`（无 `FILE_SHARE_DELETE`）`handle_ok=true`；父进程改名探测 `WinError 32` → 占用客观成立；未占用项 `moved`、占用项 `failed`；占用文件 SHA-256 不变、目标位不存在、无临时残留；释放后子进程 exit=0 |
| 2. 检查后外部创建**同内容**目标 | A2 | 外部目标存在且字节等于注入值；源存在；`failed`；错误串含「已保留未动」；无临时残留 |
| 3. 检查后外部创建**不同内容**目标 | A3 | 同上，外部目标字节未被覆盖 |
| 4. 复制部分字节后失败 | A4 | `failed`；源哈希与执行前一致；目标不存在；错误串含「复制到临时副本时失败」；临时副本已清理 |
| 5. 自有临时副本**清理失败** | A5 | 错误串含原始复制失败 + 清理失败 + 残留绝对路径；该路径 `os.path.isfile` 为真（路径按规范化比较） |
| 6. 复制期间源内容变化 | A6 | 不发布；`failed`；错误串含「内容发生变化」；源保留追加后的内容；无临时残留 |
| 7. 失败后新进程诊断与恢复/撤销 | A7_1–A7_3 | 3 个独立子进程（执行 / 读历史 / 撤销）均 exit=0；历史里 `status=error` 原样可读、含「已保留未动」；新进程看不到任何临时副本；撤销 `restored=0`，外部目标与源都保留、哈希不变 |
| 8. 正常整理与撤销小样本回归 | A8_1–A8_2 | 2 项 `moved`、无 `failed`、无临时文件；撤销后逐文件清单（含 SHA-256）与初始完全一致（`missing/extra/changed` 全空） |

### 4.3 预期故障注入单列（不是产品缺陷）

以下用例在父进程内用测试专属同步点注入失败，仅替换被测模块的 `os` / `shutil` 引用，不改产品代码：

| 用例 | 注入内容 |
| --- | --- |
| X1 / X2 / X3 | 冻结副本的 rename / move 失败（修复前代码的定性证据） |
| A2 / A3 | rename 失败 + 外部在检查后写目标（同内容 / 不同内容） |
| A4 | rename 失败 + 复制中途抛错（已写入 6 字节） |
| A5 | A4 的注入 + 删除临时副本抛错 |
| A6 | rename 失败 + 复制期间外部追加源内容 |
| A9 | 撤销 rename 失败 + 撤销复制中途抛错 |

非注入项：A1 的占用由独立子进程用真实 Windows 共享模式建立；A7 的失败由子进程内的注入产生，但"读历史/撤销"两个子进程无注入；A8 全程无注入。

### 4.4 只重跑了直接相关项

本轮未重跑桌面 GUI、规模、取消关闭等历史套件。重跑范围：

- 原占用反例（A1，真实共享模式 + 改名探测）
- 新增异常路径（A2–A7、A9）
- 直接相关回归（A8 正常整理 + 撤销）
- 修复前反例（X1–X3，冻结副本）

---

## 5. 逐文件清单与新进程恢复证据

- `prefix_logs/a7_manifest_before.json`：A7 场景执行前的逐文件清单（含 SHA-256）。
- `prefix_logs/a8_manifest_before.json`：A8 正常场景执行前的逐文件清单。
- A8_2 的判定是**清单全等**（`missing/extra/changed` 三者都为空），不是"撤销调用没抛异常"。
- A7_1/A7_2/A7_3 的判定读的是磁盘真实文件与历史数据库内容：外部目标字节不变、源不变、临时残留为空、撤销不会删除非本次创建的文件。
- 子进程记录（cmd/cwd/env 白名单/stdout/stderr/退出码）由 `windows_harness.run_child` 写入本轮 run 目录，路径记录在 `prefix_logs/results.json`。

---

## 6. 补丁与源码资产口径（区分清楚，不混称）

| 类别 | 数量 | 说明 |
| --- | --- | --- |
| 最终源码资产（`归档盒源码/` 下，排除 `__pycache__`、`tests/_abx_selftest`、`*.pyc`） | **74** | 逐文件 SHA-256 见 `source_snapshot/SHA256SUMS.txt` |
| 补丁实际改动的文件 | **23** | `patches/stage6_windows_source.stat.txt`；+6427 / −15 |
| 补丁可重建的源码资产 | **74** | 从冻结基线应用补丁后逐一比对，0 处不一致 |
| 单独提供的复现入口 | **1** | `run_stage6.ps1`（本交付目录根 + `source_snapshot/changed_files/run_stage6.ps1`），**不由源码补丁生成** |

上一轮顾问核对的是「73 项清单 / 72 项源码资产匹配」，差额正是 `run_stage5.ps1` 这个复现入口；本轮同样的区分适用：补丁只重建 `归档盒源码/` 下的文件，`run_stage6.ps1` 是单独入口。

### 6.1 补丁生成与验证（实际执行过的步骤）

```text
1. 取冻结基线 归档盒源码/ → 临时 git 仓库（排除 __pycache__、tests/_abx_selftest、*.pyc）
2. git init / add / commit（core.autocrlf=false，core.quotepath=false）
3. 用本轮最终源码覆盖同一路径；删除基线里有、当前没有的文件（本轮为 0 个）
4. git add -A；git diff --cached HEAD > patches/stage6_windows_source.patch
5. 新建基线副本 → 在副本根目录执行：
   git -c core.autocrlf=false apply --check -p1 <patch>   → exit=0
   git -c core.autocrlf=false apply        -p1 <patch>   → exit=0
6. 与最终源码逐文件比对 SHA-256：74 个文件，0 不一致，0 缺失，0 多余
```

原始输出见 `patches/apply_check.log`。注意：验证时必须显式 `-c core.autocrlf=false`，否则 Git 在 Windows 上会把补丁里的 LF 写成 CRLF，导致 23 个被修改/新增文件哈希全部不一致（本轮第一次验证即踩到此点，已修正后重跑）。

### 6.2 复现入口（本轮实际运行过）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run_stage6.ps1 `
  -Src   <最终源码 归档盒源码 绝对路径> `
  -Out   .\prefix_logs `
  -Base  .\runtime `
  -Python <venv python 绝对路径>
```

本次实际结果：`child_exit=0 self_report=0 intended=0 elapsed=4.08s`，调用者 `$LASTEXITCODE=0`。

---

## 7. 已有结论的准确表述

1. **扫描期取消入口**：产品在扫描阶段没有取消按钮。本轮未新增；该项继续列为**未测**，不为验收补按钮。
2. **CON.txt**：不再用「`open` 没报错」当作普通文件的证据。本轮在独立合成目录用两个独立进程复测（`prefix_logs/con_txt_probe.json`）：
   - 创建进程 exit=0，`listdir` 出现 `CON.txt`；`stat`：`st_mode=0o100666`，`S_ISREG=True`，`size=13`，`st_ino=1125899908076640`，`st_file_attributes=32`（ARCHIVE）。
   - 另一个独立进程重开：`exists=true`，读回 `HELLO-CON-123`，`S_ISREG=True`。
   - 结论收窄为：**在本机 Windows 11 build 26200 上，`CON.txt` 表现为普通文件**（目录项、常规文件身份、跨进程持久字节三项都满足）。这不等于 Microsoft 文档语义失效，也不外推到其他 Windows 版本。
3. **条目数 ≠ 功能覆盖数**：本轮 20 个检查项对应 3 个修复前反例、8 类要求、1 个退出码闸门与 1 个正常回归，**不是**"覆盖了 20 个功能点"。历史套件里也存在多个检查项指向同一条执行路径的情况，不能相加当覆盖率。

---

## 8. 未测边界与已知限制

- **平台**：本轮所有验证只在 Windows 11 build 26200 上做。macOS 未重跑（见 `MAC_REVERIFY.md`）。
- **POSIX rename 语义（重要）**：本机制的"发布不覆盖"依赖 Windows `os.rename` 在目标存在时失败。POSIX 的 `rename(2)` 会**静默替换**已存在目标；若直接把本实现搬到 macOS，检查后外部创建的目标仍可能被覆盖。该差异本轮未改代码、未测试，明确列为 Mac 复验必测项。
- **跨卷**：临时副本与目标同目录，因此不会跨卷。跨卷场景（源与目标在不同卷）未覆盖，因为整理目标始终在扫描根内。
- **大文件**：未做 GB 级复制性能/中断测试；复制中断只验证了"部分字节 + 异常"这一形态。
- **并发外部写入**：只覆盖"检查后创建目标"与"复制期间改源"两种时序；更细的并发窗口未穷举。
- **其他异常路径**：`os.makedirs` 失败、磁盘满、只读属性等沿用原有分支，本轮未改也未重测。
- **撤销重试**：A9 只验证第一次失败后的状态与磁盘；"修好外部条件后再次撤销成功"未包含在本轮（`conflict` 可重试是既有能力，未回归）。
- **GUI**：异常移动路径在 GUI 中的提示文案与交互未做桌面复验（本轮只测 executor 层）。

---

## 9. 交付物与索引

| 路径 | 内容 |
| --- | --- |
| `consultant/` | 顾问 review.md 与 cleanup_probes.json 原样副本 |
| `patches/stage6_windows_source.patch` | 冻结基线 → 最终源码的累计补丁（23 文件） |
| `patches/stage6_windows_source.stat.txt` | 补丁改动统计 |
| `patches/apply_check.log` | `apply --check` / `apply` 退出码 + 74 文件逐一比对结果 |
| `source_snapshot/SHA256SUMS.txt` | 74 个源码资产的逐文件 SHA-256 |
| `source_snapshot/changed_files.json` | 补丁产物清单（23）+ 单独入口（1）+ 基线路径 + 验证口径 |
| `source_snapshot/changed_files/` | 改动文件的扁平副本（便于直接查看），含 `run_stage6.ps1` |
| `prefix_logs/suite.stdout.log` / `suite.stderr.log` | 本轮唯一一次正式运行的完整输出 |
| `prefix_logs/results.json` | 20 项结构化结果（含每项 detail） |
| `prefix_logs/outer_powershell_exitcode.json` | L1/L2/L3 记录 |
| `prefix_logs/caller_observed_exit.txt` | L4 调用者观察到的退出码 |
| `prefix_logs/con_txt_probe.json` | CON.txt 两进程实测证据 |
| `prefix_logs/a7_manifest_before.json` / `a8_manifest_before.json` | 逐文件清单（含 SHA-256） |
| `run_stage6.ps1` | 复现入口（单独提供，非补丁产物） |
| `evidence_index.json` | 本交付全部文件（除自身与 `FILES.sha256.txt`）的 SHA-256 索引 |
| `FILES.sha256.txt` | 同上，`sha256sum` 兼容格式 |

索引在**所有文件定稿之后**生成，并在生成后立即逐文件复核（`evidence_index.json` 里 `self_check` 字段记录复核结果）。旧交付 `windows_stage5_deliver_20261110_191543` 与顾问证据目录均未改动。
