
raise RuntimeError("injected boom")
