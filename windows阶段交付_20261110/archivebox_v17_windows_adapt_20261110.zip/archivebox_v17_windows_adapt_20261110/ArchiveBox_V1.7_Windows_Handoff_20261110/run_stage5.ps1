# Windows stage5 outer wrapper.
# Records, for each layer, exactly what was observed:
#   level1  supervisor self-reported EXIT_CODE (from its stdout, NOT trusted)
#   level2  real OS exit code of the supervisor child process (Start-Process -PassThru)
#   level3  the exit code this wrapper intends to return
#   level4  the exit code the *caller* of this wrapper observes -> NOT captured here
#           (written by the calling shell into caller_observed_exit.txt)
param(
    [Parameter(Mandatory = $true)][string]$Out,
    [Parameter(Mandatory = $true)][string]$Base,
    [string]$Only = "",
    [string]$Python = ""
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
# locate the source tree without hardcoding non-ASCII path segments
$srcDir = Get-ChildItem -Path $here -Directory |
    Where-Object { Test-Path (Join-Path $_.FullName "tests\windows_supervisor.py") } |
    Select-Object -First 1
if ($null -eq $srcDir) { throw "cannot locate source tree (tests\windows_supervisor.py) under $here" }
$tests = Join-Path $srcDir.FullName "tests"
$supervisor = Join-Path $tests "windows_supervisor.py"

if ([string]::IsNullOrWhiteSpace($Python)) {
    $cand = Join-Path (Split-Path -Parent $here) ".venv\Scripts\python.exe"
    if (Test-Path $cand) { $Python = $cand } else { $Python = "python" }
}

New-Item -ItemType Directory -Force -Path $Out | Out-Null
$outLog = Join-Path $Out "outer_supervisor.stdout.log"
$errLog = Join-Path $Out "outer_supervisor.stderr.log"

$supArgs = @($supervisor, "--out", $Out, "--base", $Base)
if (-not [string]::IsNullOrWhiteSpace($Only)) { $supArgs += @("--only", $Only) }

$started = (Get-Date).ToUniversalTime().ToString("o")
$t0 = Get-Date
$p = Start-Process -FilePath $Python -ArgumentList $supArgs -WorkingDirectory $tests `
    -NoNewWindow -PassThru -Wait `
    -RedirectStandardOutput $outLog -RedirectStandardError $errLog
$elapsed = [math]::Round(((Get-Date) - $t0).TotalSeconds, 2)
$ended = (Get-Date).ToUniversalTime().ToString("o")
$childExit = $p.ExitCode

# level1: what the supervisor *claims* (parsed from its own stdout, never trusted)
$selfReport = "not_captured"
if (Test-Path $outLog) {
    $lines = Get-Content $outLog
    for ($i = $lines.Count - 1; $i -ge 0; $i--) {
        if ($lines[$i] -match '^EXIT_CODE=(-?\d+)$') { $selfReport = [int]$Matches[1]; break }
    }
}

$intended = 0
if ($childExit -ne 0) { $intended = 1 }

$payload = [ordered]@{
    wrapper             = "run_stage5.ps1"
    started_utc         = $started
    ended_utc           = $ended
    elapsed_sec         = $elapsed
    python              = $Python
    cmd                 = @($Python) + $supArgs
    cwd                 = $tests
    out_dir             = $Out
    base_dir            = $Base
    level1_supervisor_self_reported_exit_code = $selfReport
    level2_supervisor_child_os_exit_code      = $childExit
    level3_wrapper_intended_exit              = $intended
    level4_caller_observed_shell_exit         = "not_captured_by_this_layer"
    note                = "level4 is written by the calling shell to caller_observed_exit.txt; -999 anywhere means the framework timeout sentinel, not an OS exit code"
    stdout_log          = $outLog
    stderr_log          = $errLog
}
$jsonPath = Join-Path $Out "outer_powershell_exitcode.json"
($payload | ConvertTo-Json -Depth 6) | Set-Content -Path $jsonPath -Encoding UTF8

Write-Output ("[stage5] child_exit={0} self_report={1} intended={2} elapsed={3}s" -f $childExit, $selfReport, $intended, $elapsed)
exit $intended
