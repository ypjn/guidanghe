"""完整桌面闭环：主窗口交互 + 三份清单 + 新进程历史撤销 + 反例检出。
Windows 原生桌面，隔离状态目录。

被外层监督进程启动；脚本自身退出码 + 监督进程退出码 + 进程真实退出码三重记录。
"""
from __future__ import annotations
import hashlib
import json
import os
import shutil
import sys
import time

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)

# ======= 路径与隔离 =======
BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_full_round")
EVIDENCE = os.environ.get("ARCHIVEBOX_EVIDENCE", os.path.join(BASE, "evidence"))
SHOT_DIR = os.path.join(EVIDENCE, "shots")
MANIFEST_DIR = os.path.join(EVIDENCE, "manifests")

os.environ.setdefault("ARCHIVEBOX_RECENT_FILE", os.path.join(BASE, "recent.json"))
os.environ.setdefault("ARCHIVEBOX_APP_DIR", os.path.join(BASE, "appdata"))
os.environ.setdefault("ARCHIVEBOX_SCHEME_DIR", os.path.join(BASE, "appdata", "schemes"))
os.environ.pop("QT_QPA_PLATFORM", None)   # 强制原生

import recent_spaces, scheme_store

# ======= 清理并重建（新运行目录，不覆盖旧证据）=======
import uuid
RUN_ID = time.strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
ROOT = os.path.join(BASE, "runs", RUN_ID, "root")
os.makedirs(ROOT, exist_ok=True)
os.makedirs(SHOT_DIR, exist_ok=True)
os.makedirs(MANIFEST_DIR, exist_ok=True)

# ======= 合成文件 =======
def mk(rel, content="x"):
    p = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(p) or ROOT, exist_ok=True)
    with open(p, "wb") as f: f.write(content.encode("utf-8") if isinstance(content, str) else content)
    return rel

mk("大二上/数据结构/讲义.pdf", "数据结构PDF")
mk("大二上/数据结构/作业/hw1.docx", "作业一")
mk("大二上/数据结构/实验/report.docx", "实验报告")
mk("大二上/高等数学/期末复习.pdf", "高数期末")
mk("大一下/程序设计基础/代码/main.py", "print('hello world')")
mk("大一下/程序设计基础/笔记.md", "# 编程笔记\n一行")
mk("图片素材/logo.png", "png-bytes-here")
mk("图片素材/截图 2026.png", "截图-2026")
mk("讲义.pdf", "根目录讲义")
mk(".hidden_config_backup", "隐藏备份内容")   # 隐藏文件样例，不进入整理

# 一个项目保护样例（.git 目录整体保护）
mk("myproj/.git/config", "[core]\n\trepositoryformatversion = 0")
mk("myproj/src/main.py", "print('project main')")
mk("myproj/README.md", "# myproj")

# ======= 清单工具（只排除 .organizer，全量覆盖）=======
def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(65536), b""): h.update(c)
    return h.hexdigest()

def _norm(p):
    return p.replace("\\", "/")

def full_manifest(root, exclude=None):
    """全量清单：所有文件（含隐藏、含 _已整理 中文件），只排除 exclude 目录。"""
    exclude = set(exclude or [".organizer"])
    m = {}
    for dp, dn, fn in os.walk(root, followlinks=False):
        dn[:] = [d for d in dn if d not in exclude]
        for f in fn:
            full = os.path.join(dp, f)
            rel = _norm(os.path.relpath(full, root))
            m[rel] = (os.path.getsize(full), _sha(full))
    return m

def save_manifest(path, manifest):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({
            "count": len(manifest),
            "items": {k: {"size": v[0], "sha256": v[1]} for k, v in sorted(manifest.items())},
        }, f, ensure_ascii=False, indent=2)

def diff_manifests(expected, actual):
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    changed = sorted(k for k in set(expected) & set(actual) if expected[k] != actual[k])
    return {"missing": missing, "extra": extra, "changed": changed}

# ======= 结果收集 =======
RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK", "N/A": "未测"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:3]:
        print(f"         {line}")

# ======= PySide6 =======
from PySide6.QtWidgets import QApplication, QMessageBox, QDialog

for n in ("information", "warning", "critical"):
    setattr(QMessageBox, n, staticmethod(lambda *a, **k: QMessageBox.Ok))
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

def pump(app, sec=0.3):
    t0 = time.time()
    while time.time() - t0 < sec:
        app.processEvents(); time.sleep(0.02)

def wait(app, cond, timeout=30, label=""):
    t0 = time.time()
    while time.time() - t0 < timeout:
        app.processEvents()
        if cond():
            return True
        time.sleep(0.02)
    print(f"  wait TIMEOUT ({label or cond.__name__})")
    return bool(cond())

def shot(w, name):
    path = os.path.join(SHOT_DIR, f"{RUN_ID}_{name}")
    w.grab().save(path)
    return path

# ======= 主流程 =======
print(f"=== windows_desktop_full RUN_ID={RUN_ID} ===")
print(f"ROOT={ROOT}")
print(f"PLATFORM={sys.platform}")
print(f"PY={sys.version.split()[0]}")

BEFORE = full_manifest(ROOT)
save_manifest(os.path.join(MANIFEST_DIR, f"before_{RUN_ID}.json"), BEFORE)

app = QApplication(sys.argv)
print(f"platform={app.platformName()}  screens={len(app.screens())}")
rec("G0", "Qt 平台插件为 windows（非 offscreen）", "PASS" if app.platformName() == "windows" else "FAIL",
    f"platform={app.platformName()}")

from main import MainWindow
w = MainWindow()
w.path_edit.setText(ROOT)
w._reset_for_new_dir(ROOT)
w.show()
pump(app)
assert w.isVisible(), "主窗口应可见"
rec("G1", "主窗口 show() 后 isVisible()=True", "PASS")
shot(w, "01_main_window.png")

# === 扫描 ===
w.on_scan()
ok = wait(app, lambda: (not w._working and not w._plan_working and w.scan_result is not None), timeout=30)
rec("S1", "扫描完成并产生 ScanResult", "PASS" if ok else "FAIL",
    f"scan_result.files={len(w.scan_result.files) if w.scan_result else None}")

files = w.scan_result.files if w.scan_result else []
protected = w.scan_result.protected_count if w.scan_result else 0
rec("S2", f"扫描得到 {len(files)} 个可整理文件 + {protected} 受保护", "PASS")

# 逐项检查
for label, keywords in [
    ("中文路径", "讲义"), ("空格路径", "截图"),
    ("myproj/src/main.py", "main.py"),
]:
    found = any(label in f.rel_path or keywords in f.rel_path for f in files)
    rec("S3a" if "中文" in label else ("S3b" if "空格" in label else "S3c"),
        f"{label} 文件出现在扫描结果", "PASS" if found else "FAIL",
        f"sample_files={[f.rel_path for f in files[:5]]}")

# 项目保护
myproj = [f for f in files if f.rel_path.startswith("myproj/")]
rec("S4", "myproj 项目被保护（无文件进入扫描）",
    "PASS" if len(myproj) == 0 else "FAIL", f"myproj残留={myproj}")

# === 预览 ===
rec("P1", f"计划有效 {w._plan_valid} 共 {w.current_plan.total if w.current_plan else None} 项",
    "PASS" if (w._plan_valid and w.current_plan is not None) else "FAIL")
rec("P2", f"表格行数 {w.table.rowCount()}",
    "PASS" if w.table.rowCount() >= 1 else "FAIL")
shot(w, "02_preview.png")

# === 执行 ===
w.on_execute()
ok2 = wait(app, lambda: (not w._working and w._exec_worker is None or
                         (hasattr(w, '_exec_worker') and not w._exec_worker.isRunning())),
           timeout=45, label="execute")
rec("E1", "执行线程结束", "PASS" if ok2 else "FAIL")

AFTER = full_manifest(ROOT)
save_manifest(os.path.join(MANIFEST_DIR, f"after_move_{RUN_ID}.json"), AFTER)

# 断言归档目录出现了正确数目的文件
organized_after_move = [k for k in AFTER if k.startswith("_已整理/")]
rec("E2", f"归档目录 {len(organized_after_move)} 个文件（应为 {len(files)}）",
    "PASS" if len(organized_after_move) == len(files) else "FAIL",
    f"expected={len(files)} got={len(organized_after_move)}")

# SHA 检查
before_nm = BEFORE
sha_ok = 0; sha_fail = 0
for item in w.current_plan.items:
    if not item.selected: continue
    src = _norm(item.file.rel_path)
    tgt = _norm(item.target_rel_path)
    if src in before_nm and tgt in AFTER:
        if before_nm[src][1] == AFTER[tgt][1]: sha_ok += 1
        else: sha_fail += 1
    else:
        sha_fail += 1
rec("E3", f"移动后 SHA-256 不变：ok={sha_ok} fail={sha_fail}",
    "PASS" if sha_fail == 0 and sha_ok == len(files) else "FAIL")

shot(w, "03_after_execute.png")

# === 数据库批次状态 ===
from storage import Storage
st = Storage(ROOT)
batch = st.get_latest_batch()
actions = st.get_actions(batch.batch_id) if batch else []
st.close()
rec("E4", f"数据库批次 batch_id={batch.batch_id if batch else None} status={batch.status if batch else None}",
    "PASS" if (batch and batch.status == "done" and len(actions) == len(files)) else "FAIL",
    f"actions={[a.status for a in actions[:5]]}")

# === 先关闭当前进程 ===
w.close()
pump(app)
print(f"GUI_AFTER_EXIT  batch={batch.batch_id if batch else None}")

# 把 RUN_ID 和 ROOT 写下来，让下一个进程能用
state_file = os.path.join(EVIDENCE, "state.json")
with open(state_file, "w", encoding="utf-8") as f:
    json.dump({"run_id": RUN_ID, "root": ROOT, "evidence": EVIDENCE}, f, ensure_ascii=False, indent=2)

print(f"DESKTOP_PART1_OK  exit=0")
sys.exit(0)
