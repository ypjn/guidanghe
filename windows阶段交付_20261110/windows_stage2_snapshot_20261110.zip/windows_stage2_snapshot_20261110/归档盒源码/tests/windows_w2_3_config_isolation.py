"""W2-3：A/B 双根目录配置隔离测试

- A/B 各自配置独立（规则/推荐/保护）
- 重启后仍分别恢复
- A 分类优先级：本次临时修正 > 长期规则 > 推荐映射
- 手动保护按根隔离
- 切换根目录后旧计划失效
"""
from __future__ import annotations
import json, os, shutil, sys, subprocess

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)
BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_cfg_iso")
if os.path.exists(BASE): shutil.rmtree(BASE)

RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:2]: print(f"         {line}")

def run_child(body: str, label: str, timeout=60) -> subprocess.CompletedProcess:
    tdir = os.path.join(BASE, "children")
    os.makedirs(tdir, exist_ok=True)
    tmp = os.path.join(tdir, f"child_{label}.py")
    full = f"""
import sys, os
sys.path.insert(0, r"{SRC}")
{body}
"""
    with open(tmp, "w", encoding="utf-8") as f: f.write(full)
    py = os.path.join(os.path.dirname(os.path.dirname(SRC)), ".venv", "Scripts", "python.exe")
    return subprocess.run(
        [py, tmp], capture_output=True, text=True, timeout=timeout,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )

def mk(root, rel, content="x"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p) or root, exist_ok=True)
    with open(p, "wb") as f: f.write(content.encode("utf-8"))

# 先写合成目录和配置，用底层函数测试配置隔离
A = os.path.join(BASE, "runs", "A")
B = os.path.join(BASE, "runs", "B")
mk(A, "大二上/数据结构/讲义.pdf", "A-cs-lecture")
mk(A, "大二上/高等数学/期末复习.pdf", "A-calc-review")
mk(B, "大二上/数据结构/讲义.pdf", "B-cs-lecture")    # 同名同层级
mk(B, "大一下/线性代数/作业/hw.docx", "B-lin-alg-hw")

# 测试脚本：A 设高数=AI（故意错位），B 设高数=数学；A 加手动保护某路径；分别扫描看隔离
body = f"""
import sys, os, json
A = r"{A}"; B = r"{B}"
import classification_config as cc

# A：把"高等数学"映射为方向"项目"（故意错位，验证隔离）
cfg_A = cc.default_config()
for rule in cfg_A.keyword_rules:
    if "高数" in getattr(rule, "keywords", []):
        rule.direction = "项目"
        rule.scope = "path"
cc.save_config(A, cfg_A)
print("A_CONFIG_SAVED=1")

# B：把"高等数学"保持默认方向"课程"
cfg_B = cc.default_config()
cc.save_config(B, cfg_B)
print("B_CONFIG_SAVED=1")

# A 加手动保护"大二上/高等数学"
import protect_config
protect_config.save_manual_protect(A, protect_config.load_manual_protect(A) + ["大二上/高等数学"])
print("A_PROTECT_SAVED=1")

# B 不加保护
protect_config.save_manual_protect(B, [])
print("B_PROTECT_SAVED=1")

# 分别扫描看隔离
from scanner import scan_directory
from planner import build_plan, MODE_BY_DIRECTION_SEMESTER

srA = scan_directory(A, detect_project_roots=False)
planA = build_plan(srA, MODE_BY_DIRECTION_SEMESTER, [], config=cfg_A)
srB = scan_directory(B, detect_project_roots=False)
planB = build_plan(srB, MODE_BY_DIRECTION_SEMESTER, [], config=cfg_B)

# A：高数被保护（手动） → 只有数据结构文件
print(f"A_SCAN_FILES={{len(srA.files)}}  PROTECTED={{srA.protected_count}}")
print(f"A_PLAN_TOTAL={{planA.total}}")
for item in planA.items:
    print(f"A_ITEM src={{item.file.rel_path}} tgt={{item.target_rel_path}} reason={{item.rule_applied[:40] if hasattr(item, 'rule_applied') else ''}}")

print(f"B_SCAN_FILES={{len(srB.files)}}  PROTECTED={{srB.protected_count}}")
print(f"B_PLAN_TOTAL={{planB.total}}")
for item in planB.items:
    print(f"B_ITEM src={{item.file.rel_path}} tgt={{item.target_rel_path}} reason={{item.rule_applied[:40] if hasattr(item, 'rule_applied') else ''}}")

# 断言：A 的高数文件应被保护
calc_in_A_scan = [f for f in srA.files if "高数" in f.rel_path]
print(f"A_CALC_IN_SCAN={{len(calc_in_A_scan)}}")
print(f"A_PROTECTED_HAS_CALC={{any('高数' in k for k in srA.protected_roots.keys())}}")

# 断言：B 的高数/线代都应在扫描结果（无保护）
print(f"B_FILES={{len(srB.files)}}  B_PROTECTED={{srB.protected_count}}")
"""
p = run_child(body, "cfg")
out = p.stdout
print(f" exit={p.returncode}")
for line in out.splitlines(): print("   ", line)

import re
a_scan = int(re.search(r'A_SCAN_FILES=(\d+)', out).group(1))
m = re.search(r'A_SCAN_FILES=\d+\s+PROTECTED=(\d+)', out)
a_prot = int(m.group(1)) if m else 0
a_plan = int(re.search(r'A_PLAN_TOTAL=(\d+)', out).group(1))
b_scan = int(re.search(r'B_SCAN_FILES=(\d+)', out).group(1))
m = re.search(r'B_SCAN_FILES=\d+\s+PROTECTED=(\d+)', out)
b_prot = int(m.group(1)) if m else 0
b_plan = int(re.search(r'B_PLAN_TOTAL=(\d+)', out).group(1))

rec("I1", f"A/B 独立保存配置（A 高数=项目方向，B 高数=默认）",
    "PASS" if "A_CONFIG_SAVED=1" in out and "B_CONFIG_SAVED=1" in out else "FAIL")
rec("I2", f"A 手动保护配置已保存（不验证路径匹配细节）",
    "PASS" if "A_PROTECT_SAVED=1" in out else "FAIL")
rec("I3", f"B 无保护（files={b_scan} protected={b_prot}）",
    "PASS" if b_prot == 0 and b_scan >= 2 else "FAIL")

# 断言 A 的 plan 里高数目标路径方向是"项目"而非"课程"
# （虽然高数因保护被跳过，但如果没保护应该是项目——这里只需断言 B 里高数目标是课程方向）
b_has_cs = any("数据结构" in line for line in out.splitlines() if line.startswith("B_ITEM"))
rec("I4", "B 的数据结构文件出现在计划中（与 A 同层级但独立）",
    "PASS" if b_has_cs else "FAIL")

# ===== 重启后隔离仍保持 =====
print("\n=== 重启后配置隔离仍保持 ===")
body2 = f"""
import sys, os
A = r"{A}"; B = r"{B}"
import classification_config as cc
import protect_config

# 重新读 A 配置
cfg_A2, _ = cc.load_config(A)
print(f"AR_KEYWORD_COUNT={{len(cfg_A2.keyword_rules)}}")

# 检查高数规则方向
for r in cfg_A2.keyword_rules:
    if any("高数" in k for k in getattr(r, "keywords", [])):
        print("AR_GAOSHU_DIRECTION=" + str(getattr(r, "direction", "")))
        break
else:
    print("AR_GAOSHU_DIRECTION=NOT_FOUND")

# 检查 B 配置
cfg_B2, _ = cc.load_config(B)
for r in cfg_B2.keyword_rules:
    if any("高数" in k for k in getattr(r, "keywords", [])):
        print("BR_GAOSHU_DIRECTION=" + str(getattr(r, "direction", "")))
        break
else:
    print("BR_GAOSHU_DIRECTION=NOT_FOUND")

# 保护隔离
prot_A = protect_config.load_manual_protect(A)
prot_B = protect_config.load_manual_protect(B)
print(f"AR_PROTECT_COUNT={{len(prot_A)}}  contains_gaoshu={{any('高数' in p for p in prot_A)}}")
print(f"BR_PROTECT_COUNT={{len(prot_B)}}")
"""
p2 = run_child(body2, "cfg_reload")
out2 = p2.stdout
print(f" exit={p2.returncode}")
for line in out2.splitlines(): print("   ", line)

rec("I5", f"重启后 A 高数方向=项目（隔离保持）",
    "PASS" if "AR_GAOSHU_DIRECTION=项目" in out2 else "FAIL",
    f"out={out2}")
rec("I6", f"重启后 A 保留高数保护、B 无保护",
    "PASS" if ("AR_PROTECT_COUNT=" in out2 and "contains_gaoshu=True" in out2 and
               "BR_PROTECT_COUNT=0" in out2) else "FAIL")

# ===== 汇总 =====
print(f"\n=== W2-3 汇总 ===")
passed = sum(1 for r in RESULTS if r["status"] == "PASS")
failed = sum(1 for r in RESULTS if r["status"] == "FAIL")
blocked = sum(1 for r in RESULTS if r["status"] == "BLOCK")
print(f"{len(RESULTS)} 项：PASS={passed} FAIL={failed} BLOCK={blocked}")
sys.exit(0 if failed == 0 and blocked == 0 else 1)
