"""W2-1 子进程版本：场景 1=执行中取消，场景 2=执行中关闭窗口。"""
from __future__ import annotations
import hashlib, json, os, shutil, sys, time, subprocess, re

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)
BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_cancel")

RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:2]: print(f"         {line}")

def run_child(script_body: str, label: str) -> subprocess.CompletedProcess:
    tmp_dir = os.path.join(BASE, "children")
    os.makedirs(tmp_dir, exist_ok=True)
    tmp = os.path.join(tmp_dir, f"child_{label}.py")
    full = f"""
# === 自动生成的子进程脚本 ===
import sys, os
sys.path.insert(0, r"{SRC}")
{script_body}
"""
    with open(tmp, "w", encoding="utf-8") as f: f.write(full)
    py = os.path.join(os.path.dirname(os.path.dirname(SRC)), ".venv", "Scripts", "python.exe")
    print(f"  → launch {tmp}")
    return subprocess.run(
        [py, tmp], capture_output=True, text=True, timeout=180,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )

def parse_out(s: str) -> dict:
    d = {}
    for key in ("MOVED_BEFORE_CANCEL", "CANCEL_CALLED", "BATCH_STATUS",
                "ACTIONS_MOVED", "ACTIONS_CANCELLED", "UNDO_RESTORED",
                "ORGANIZER_RESIDUE", "SRC_AFTER", "CLOSING_FLAG",
                "EXEC_ALIVE", "BATCH_COUNT", "BATCH_ACTIVE"):
        m = re.search(rf'{key}=([^\s]+)', s)
        if m: d[key] = m.group(1)
    return d

# ===== 场景 1 =====
print("=== 场景 1：执行过程中取消 ===")
run1 = os.path.join(BASE, "runs", "cancel_mid_exec", "root")
if os.path.exists(run1): shutil.rmtree(run1)

body1 = f"""
import os, time, sys, shutil
os.environ.pop("QT_QPA_PLATFORM", None)
os.environ.setdefault("ARCHIVEBOX_RECENT_FILE", r"{BASE}\\recent.json")
os.environ.setdefault("ARCHIVEBOX_APP_DIR", r"{BASE}\\appdata")
RUN1 = r"{run1}"
if os.path.exists(RUN1): shutil.rmtree(RUN1)
for i in range(200):
    p = os.path.join(RUN1, f"大二上/数据结构/作业/hw{{i:03d}}.docx")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write(f"hw-{{i}}")

from PySide6.QtWidgets import QApplication, QMessageBox
for n in ("information", "warning", "critical"):
    setattr(QMessageBox, n, staticmethod(lambda *a, **k: QMessageBox.Ok))
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

app = QApplication(sys.argv)
from main import MainWindow
w = MainWindow()
w.path_edit.setText(RUN1)
w._reset_for_new_dir(RUN1)
w.show()

def wait(app, cond, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        app.processEvents()
        if cond(): return True
        time.sleep(0.02)
    return False

w.on_scan()
wait(app, lambda: (not w._working and not w._plan_working), 30)
w.on_execute()

# 等至少 5 个文件已移动
mv_before = 0
t0 = time.time()
while time.time() - t0 < 20:
    app.processEvents()
    org = os.path.join(RUN1, "_已整理")
    if os.path.exists(org):
        cnt = sum(1 for dp, dn, fn in os.walk(org) for f in fn)
        if cnt >= 5: mv_before = cnt; break
    time.sleep(0.02)

print(f"MOVED_BEFORE_CANCEL={{mv_before}}")
w.on_cancel_execute()
print("CANCEL_CALLED")

wait(app, lambda: (not w._working and
                   (not hasattr(w, '_exec_worker') or w._exec_worker is None or
                    not w._exec_worker.isRunning())), 30)

from storage import Storage
from executor import undo_latest_batch, undo_is_available
st = Storage(RUN1)
batch = st.get_latest_batch()
actions = st.get_actions(batch.batch_id) if batch else []
print(f"BATCH_STATUS={{batch.status if batch else None}}")
print(f"ACTIONS_MOVED={{sum(1 for a in actions if a.status=='moved')}}")
print(f"ACTIONS_CANCELLED={{sum(1 for a in actions if a.status=='cancelled')}}")

if undo_is_available(st):
    ur = undo_latest_batch(st)
    print(f"UNDO_RESTORED={{ur.restored}}")
else:
    print("UNDO_RESTORED=-1")
st.close()

ORG = os.path.join(RUN1, "_已整理")
res = sum(1 for dp, dn, fn in os.walk(ORG) for f in fn) if os.path.exists(ORG) else 0
print(f"ORGANIZER_RESIDUE={{res}}")
sys.exit(0)
"""

p1 = run_child(body1, "cancel")
out1 = p1.stdout
err1 = p1.stderr[-500:] if p1.stderr else ""
print(f"  SUB1 exit={p1.returncode}")
for line in out1.splitlines(): print("   ", line)
if err1: print("   stderr:", err1)
d1 = parse_out(out1 + " " + err1)

rec("C1_0", "执行中调用 on_cancel_execute",
    "PASS" if "CANCEL_CALLED" in out1 else "FAIL")
bs = d1.get("BATCH_STATUS")
rec("C1_1", f"批次 status={bs}",
    "PASS" if bs in ("cancelled", "partial", "cancelled_clean") else "FAIL",
    f"status={bs} moved_before={d1.get('MOVED_BEFORE_CANCEL')}")
ur = d1.get("UNDO_RESTORED")
rec("C1_2", f"撤销 restored={ur}",
    "PASS" if ur and ur != "-1" and int(ur) >= 0 else "FAIL")
residue = d1.get("ORGANIZER_RESIDUE")
rec("C1_3", f"归档目录残留 {residue} 个文件",
    "PASS" if residue is not None and residue == "0" else "FAIL")

# ===== 场景 2 =====
print("\n=== 场景 2：执行中关闭窗口 ===")
run2 = os.path.join(BASE, "runs", "close_during_exec", "root")
if os.path.exists(run2): shutil.rmtree(run2)

body2 = f"""
import os, time, sys, shutil
os.environ.pop("QT_QPA_PLATFORM", None)
os.environ.setdefault("ARCHIVEBOX_RECENT_FILE", r"{BASE}\\recent.json")
os.environ.setdefault("ARCHIVEBOX_APP_DIR", r"{BASE}\\appdata")
RUN2 = r"{run2}"
for i in range(200):
    p = os.path.join(RUN2, f"大二上/高等数学/期末复习/rev{{i:03d}}.pdf")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w").write(f"rev-{{i}}")

from PySide6.QtWidgets import QApplication, QMessageBox
for n in ("information", "warning", "critical"):
    setattr(QMessageBox, n, staticmethod(lambda *a, **k: QMessageBox.Ok))
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

app = QApplication(sys.argv)
from main import MainWindow
w = MainWindow()
w.path_edit.setText(RUN2)
w._reset_for_new_dir(RUN2)
w.show()

def wait(app, cond, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        app.processEvents()
        if cond(): return True
        time.sleep(0.02)
    return False

w.on_scan()
wait(app, lambda: (not w._working and not w._plan_working), 30)
w.on_execute()

# 等至少 3 个文件已移动后再 close
mv_before = 0
t0 = time.time()
while time.time() - t0 < 20:
    app.processEvents()
    org = os.path.join(RUN2, "_已整理")
    if os.path.exists(org):
        cnt = sum(1 for dp, dn, fn in os.walk(org) for f in fn)
        if cnt >= 3: mv_before = cnt; break
    time.sleep(0.02)

# 发起关闭
w.close()
app.processEvents()

# 等待协作取消和线程结束
wait(app, lambda: w._closing, 15)
wait(app, lambda: (not hasattr(w, '_exec_worker') or w._exec_worker is None or not w._exec_worker.isRunning()), 20)

print(f"CLOSING_FLAG={{w._closing}}")
exec_alive = (hasattr(w, '_exec_worker') and w._exec_worker is not None and w._exec_worker.isRunning())
print(f"EXEC_ALIVE={{exec_alive}}")

from storage import Storage
st = Storage(RUN2)
bs2 = st.list_batches()
print(f"BATCH_COUNT={{len(bs2)}}")
print(f"BATCH_ACTIVE={{[b.status for b in bs2]}}")
st.close()
sys.exit(0)
"""

p2 = run_child(body2, "close")
out2 = p2.stdout
err2 = p2.stderr[-500:] if p2.stderr else ""
print(f"  SUB2 exit={p2.returncode}")
for line in out2.splitlines(): print("   ", line)
if err2: print("   stderr:", err2)
d2 = parse_out(out2 + " " + err2)

rec("C2_1", "关闭触发 _closing=True",
    "PASS" if d2.get("CLOSING_FLAG") == "True" else "FAIL")
rec("C2_2", "协作等待后执行线程已结束",
    "PASS" if d2.get("EXEC_ALIVE") == "False" else "FAIL")
rec("C2_3", f"磁盘批次可读取 count={d2.get('BATCH_COUNT')}",
    "PASS" if d2.get("BATCH_COUNT") is not None else "FAIL")

# ===== 汇总 =====
print(f"\n=== W2-1 汇总 ===")
passed = sum(1 for r in RESULTS if r["status"] == "PASS")
failed = sum(1 for r in RESULTS if r["status"] == "FAIL")
blocked = sum(1 for r in RESULTS if r["status"] == "BLOCK")
print(f"{len(RESULTS)} 项：PASS={passed} FAIL={failed} BLOCK={blocked}")
sys.exit(0 if failed == 0 and blocked == 0 else 1)
