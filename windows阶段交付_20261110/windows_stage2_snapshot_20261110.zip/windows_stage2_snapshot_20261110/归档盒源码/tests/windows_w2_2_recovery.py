"""W2-2：中断恢复 4 种状态夹具

不做 kill 进程注入，直接用 Storage 手工构造 4 种状态，然后恢复。
"""
from __future__ import annotations
import json, os, shutil, sys, time, subprocess, re

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)
BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_recover")

RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:2]: print(f"         {line}")

def run_child(body: str, label: str, timeout=60) -> subprocess.CompletedProcess:
    tdir = os.path.join(BASE, "children")
    os.makedirs(tdir, exist_ok=True)
    tmp = os.path.join(tdir, f"child_{label}.py")
    full = f"""
import sys, os
sys.path.insert(0, r"{SRC}")
{body}
"""
    with open(tmp, "w", encoding="utf-8") as f: f.write(full)
    py = os.path.join(os.path.dirname(os.path.dirname(SRC)), ".venv", "Scripts", "python.exe")
    return subprocess.run(
        [py, tmp], capture_output=True, text=True, timeout=timeout,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )

def mk(root, rel, content="x"):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p) or root, exist_ok=True)
    with open(p, "wb") as f: f.write(content.encode("utf-8"))

if os.path.exists(BASE): shutil.rmtree(BASE)

# ===== 夹具 1：planned（已登记但未移动）——执行刚开始就中断 =====
print("=== 夹具 1：动作已登记但文件未移动 ===")
run1 = os.path.join(BASE, "runs", "f1_planned", "root")
os.makedirs(os.path.join(run1, ".organizer"), exist_ok=True)
mk(run1, "大二上/数据结构/讲义.pdf", "c1")

body1 = f"""
import os, sys, shutil
RUN1 = r"{run1}"
from storage import Storage
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory

sr = scan_directory(RUN1, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])

st = Storage(RUN1)
batch = st.open_batch(root=RUN1, mode=plan.mode)
idx = 0
for item in plan.items:
    if not item.selected: continue
    st.add_action(batch, idx, item.file.rel_path, item.target_rel_path,
                  item.file.size, item.file.sha256 or "", "planned")
    idx += 1
st.finalize_batch(batch, moved=0, failed=0, skipped=0, summary="中断夹具-未移动")
print(f"F1_BATCH status={{batch.status}}  actions={{idx}}")

# 验证文件还在原位
print(f"F1_SRC_EXISTS={{os.path.exists(os.path.join(RUN1, '大二上/数据结构/讲义.pdf'))}}")
# 目标目录不应有文件
import glob
organized_files = []
for dp, dn, fn in os.walk(os.path.join(RUN1, "_已整理")):
    organized_files.extend(os.path.join(dp, f) for f in fn)
print(f"F1_TGT_FILES={{len(organized_files)}}")
st.close()

# 新进程做恢复
print("F1_EXECUTING_RECOVERY=1")
"""
p1 = run_child(body1, "f1")
out1 = p1.stdout
print(f" exit={p1.returncode}")
for line in out1.splitlines(): print("   ", line)

# 断言夹具正确建立
src_exists = "F1_SRC_EXISTS=True" in out1
tgt_cnt = 0
m = re.search(r'F1_TGT_FILES=(\d+)', out1)
if m: tgt_cnt = int(m.group(1))
rec("F1_1", "夹具 1：源文件在原位", "PASS" if src_exists else "FAIL")
rec("F1_2", f"夹具 1：归档目录 0 文件", "PASS" if tgt_cnt == 0 else "FAIL")

# 尝试用 executor 的恢复入口（undo_latest_batch 能处理 partial/cancelled 批次）
body1b = f"""
import sys, os
RUN1 = r"{run1}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available

st = Storage(RUN1)
print(f"F1B_UNDO_AVAILABLE={{undo_is_available(st)}}")
ur = undo_latest_batch(st)
print(f"F1B_RESTORED={{ur.restored}}  complete={{ur.is_complete}}")

import glob, os
src_after = os.path.exists(os.path.join(RUN1, "大二上/数据结构/讲义.pdf"))
print(f"F1B_SRC_AFTER={{src_after}}")
organized = os.path.join(RUN1, "_已整理")
cnt = 0
if os.path.exists(organized):
    for dp, dn, fn in os.walk(organized):
        cnt += len(fn)
print(f"F1B_ORGANIZED_AFTER={{cnt}}")
st.close()
"""
p1b = run_child(body1b, "f1b")
out1b = p1b.stdout
print(f" exit={p1b.returncode}")
for line in out1b.splitlines(): print("   ", line)
rec("F1_3", "夹具 1 恢复（planned 状态）：源保留归档清空",
    "PASS" if ("F1B_SRC_AFTER=True" in out1b and "F1B_ORGANIZED_AFTER=0" in out1b) else "FAIL")

# ===== 夹具 2：源与目标同时存在 =====
print("\n=== 夹具 2：源与目标同时存在 ===")
run2 = os.path.join(BASE, "runs", "f2_both", "root")
mk(run2, "讲义.pdf", "original")
mk(run2, "_已整理/待定/讲义.pdf", "original")   # 手动把目标文件也放进去

body2 = f"""
import os, sys, shutil, hashlib
RUN2 = r"{run2}"
from storage import Storage
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory
sr = scan_directory(RUN2, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
st = Storage(RUN2)
batch = st.open_batch(root=RUN2, mode=plan.mode)
idx = 0
for item in plan.items:
    if not item.selected: continue
    st.add_action(batch, idx, item.file.rel_path, item.target_rel_path,
                  item.file.size, item.file.sha256 or "", "moved")
    idx += 1
st.finalize_batch(batch, moved=idx, failed=0, summary="中断夹具-源目标共存")
print(f"F2_BATCH status={{batch.status}}")

import hashlib
def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()
src_p = os.path.join(RUN2, "讲义.pdf")
tgt_p = os.path.join(RUN2, "_已整理", "待定", "讲义.pdf")
src_sha = sha(src_p) if os.path.exists(src_p) else None
tgt_sha = sha(tgt_p) if os.path.exists(tgt_p) else None
print(f"F2_SRC_SHA={{src_sha}}")
print(f"F2_TGT_SHA={{tgt_sha}}")
print(f"F2_BOTH_EXIST={{os.path.exists(src_p) and os.path.exists(tgt_p)}}")
st.close()
"""
p2 = run_child(body2, "f2")
out2 = p2.stdout
print(f" exit={p2.returncode}")
for line in out2.splitlines(): print("   ", line)
rec("F2_1", "夹具 2 建立：源和目标同时存在",
    "PASS" if "F2_BOTH_EXIST=True" in out2 else "FAIL")

# 恢复
body2b = f"""
import sys, os
RUN2 = r"{run2}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available
st = Storage(RUN2)
ur = undo_latest_batch(st)
print(f"F2B_RESTORED={{ur.restored}}  conflict={{ur.conflict}}  errors={{ur.errors}}")
# 恢复后：源文件应该保留（因为是 moved 状态，undo 要从目标复制回源——但源已存在，可能冲突）
src_p = os.path.join(RUN2, "讲义.pdf")
tgt_p = os.path.join(RUN2, "_已整理", "待定", "讲义.pdf")
print(f"F2B_SRC_EXISTS={{os.path.exists(src_p)}}")
print(f"F2B_TGT_EXISTS={{os.path.exists(tgt_p)}}")
st.close()
"""
p2b = run_child(body2b, "f2b")
out2b = p2b.stdout
print(f" exit={p2b.returncode}")
for line in out2b.splitlines(): print("   ", line)
rec("F2_2", "夹具 2 恢复后源文件存在（不应被覆盖）",
    "PASS" if "F2B_SRC_EXISTS=True" in out2b else "FAIL",
    f"ur={out2b}")

# ===== 夹具 3：源和目标都不存在 =====
print("\n=== 夹具 3：源和目标都不存在 ===")
run3 = os.path.join(BASE, "runs", "f3_none", "root")
os.makedirs(os.path.join(run3, ".organizer"), exist_ok=True)

body3 = f"""
import os, sys
RUN3 = r"{run3}"
from storage import Storage
# 直接手工插一条 moved 状态的 action，但源和目标都不存在
st = Storage(RUN3)
batch = st.open_batch(root=RUN3, mode="by_direction_semester")
st.add_action(batch, 0, "讲义.pdf", "_已整理/待定/讲义.pdf",
              10, "abc123sha", "moved")
st.finalize_batch(batch, moved=1, summary="中断夹具-双不存在")
st.close()

src_p = os.path.join(RUN3, "讲义.pdf")
tgt_p = os.path.join(RUN3, "_已整理", "待定", "讲义.pdf")
print(f"F3_BOTH_MISSING={{not os.path.exists(src_p) and not os.path.exists(tgt_p)}}")

# 尝试恢复
from executor import undo_latest_batch, undo_is_available
st2 = Storage(RUN3)
print(f"F3_UNDO_AVAILABLE={{undo_is_available(st2)}}")
ur = undo_latest_batch(st2)
print(f"F3_RESTORED={{ur.restored}}  errors={{ur.errors}}  is_complete={{ur.is_complete}}")
st2.close()
"""
p3 = run_child(body3, "f3")
out3 = p3.stdout
print(f" exit={p3.returncode}")
for line in out3.splitlines(): print("   ", line)
rec("F3_1", "夹具 3 建立：源和目标都不存在",
    "PASS" if "F3_BOTH_MISSING=True" in out3 else "FAIL")
rec("F3_2", "夹具 3 恢复：不报异常，明确报告冲突/缺失",
    "PASS" if p3.returncode == 0 else "FAIL",
    f"exit={p3.returncode} stderr={p3.stderr.strip()[-200:]}")

# ===== 夹具 4：从新进程恢复（验证恢复入口有效）=====
print("\n=== 夹具 4：新进程恢复入口有效 ===")
# 夹具 1 的 run1 已经有一个 planned 批次，再跑一次完整夹具
run4 = os.path.join(BASE, "runs", "f4_recover", "root")
mk(run4, "大二上/数据结构/作业/hw.docx", "hw")
mk(run4, "大二上/数据结构/讲义.pdf", "pdf")

# 先让一个进程执行（生成 done 批次 + 文件移动）
body4a = f"""
import sys, os, shutil
RUN4 = r"{run4}"
from storage import Storage
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from scanner import scan_directory
from executor import execute_plan

sr = scan_directory(RUN4, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
st = Storage(RUN4)
result = execute_plan(plan, st)
st.close()
print(f"F4A_BATCH={{result.batch_id}}  moved={{result.moved}}  failed={{result.failed}}")
"""
p4a = run_child(body4a, "f4a")
out4a = p4a.stdout
print(f" exit={p4a.returncode}")
for line in out4a.splitlines(): print("   ", line)

# 第二个独立进程做撤销
body4b = f"""
import sys, os
RUN4 = r"{run4}"
from storage import Storage
from executor import undo_latest_batch, undo_is_available

st = Storage(RUN4)
print(f"F4B_UNDO_AVAILABLE={{undo_is_available(st)}}")
ur = undo_latest_batch(st)
print(f"F4B_RESTORED={{ur.restored}}  complete={{ur.is_complete}}")

# 核对
import os
org = os.path.join(RUN4, "_已整理")
cnt = sum(1 for dp, dn, fn in os.walk(org) for f in fn) if os.path.exists(org) else 0
print(f"F4B_ORGANIZED_AFTER={{cnt}}")
src1 = os.path.exists(os.path.join(RUN4, "大二上/数据结构/讲义.pdf"))
src2 = os.path.exists(os.path.join(RUN4, "大二上/数据结构/作业/hw.docx"))
print(f"F4B_SRC_OK={{src1 and src2}}")
st.close()
"""
p4b = run_child(body4b, "f4b")
out4b = p4b.stdout
print(f" exit={p4b.returncode}")
for line in out4b.splitlines(): print("   ", line)

rec("F4_1", "夹具 4：新进程可读取磁盘批次并撤销",
    "PASS" if ("F4B_RESTORED=2" in out4b and "F4B_ORGANIZED_AFTER=0" in out4b and "F4B_SRC_OK=True" in out4b) else "FAIL")
rec("F4_2", "夹具 4：子进程退出码 0",
    "PASS" if p4b.returncode == 0 else "FAIL",
    f"exit={p4b.returncode} stderr={p4b.stderr.strip()[-200:]}")

# ===== 汇总 =====
print(f"\n=== W2-2 汇总 ===")
passed = sum(1 for r in RESULTS if r["status"] == "PASS")
failed = sum(1 for r in RESULTS if r["status"] == "FAIL")
blocked = sum(1 for r in RESULTS if r["status"] == "BLOCK")
print(f"{len(RESULTS)} 项：PASS={passed} FAIL={failed} BLOCK={blocked}")
sys.exit(0 if failed == 0 and blocked == 0 else 1)
