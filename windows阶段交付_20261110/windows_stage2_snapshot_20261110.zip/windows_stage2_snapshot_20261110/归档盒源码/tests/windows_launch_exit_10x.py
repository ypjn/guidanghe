"""10 次启动/退出修正版：每次进入事件循环 + 等待窗口可见 + 正常关闭 + 进程真正结束。"""
from __future__ import annotations
import json, os, subprocess, sys, time

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ.pop("QT_QPA_PLATFORM", None)
# 启动被测子进程的 launcher 脚本（内嵌，避免依赖其他文件）
LAUNCHER_CODE = r'''
import os, sys, time
os.environ.pop("QT_QPA_PLATFORM", None)
sys.path.insert(0, r"{SRC}")
from PySide6.QtWidgets import QApplication
from main import MainWindow

app = QApplication(sys.argv)
w = MainWindow()
w.show()

# 事件循环中等待窗口可见
deadline = time.time() + 10
while time.time() < deadline:
    app.processEvents()
    if w.isVisible():
        break
    time.sleep(0.02)

if not w.isVisible():
    print("FAIL window not visible")
    sys.exit(2)

app.processEvents()
w.close()

# 等待控件销毁完成
deadline2 = time.time() + 5
while time.time() < deadline2:
    app.processEvents()
    time.sleep(0.02)

print("OK")
sys.exit(0)
'''.format(SRC=SRC)

BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_full_round")
TMP = os.path.join(BASE, "launch_exit")
os.makedirs(TMP, exist_ok=True)
launcher = os.path.join(TMP, "launcher.py")
with open(launcher, "w", encoding="utf-8") as f: f.write(LAUNCHER_CODE)

venv_py = os.path.join(os.path.dirname(SRC), ".venv", "Scripts", "python.exe")
py = venv_py if os.path.exists(venv_py) else sys.executable

ALL_OK = True
results = []
for i in range(10):
    t0 = time.time()
    proc = subprocess.run(
        [py, launcher], capture_output=True, text=True, timeout=30,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
    )
    elapsed = round((time.time() - t0) * 1000, 1)
    ec = proc.returncode
    ok = ec == 0 and "OK" in proc.stdout
    results.append({"run": i + 1, "exit_code": ec, "elapsed_ms": elapsed,
                    "stdout": proc.stdout.strip()[-80:], "stderr": proc.stderr.strip()[-80:]})
    mark = "PASS" if ok else "FAIL"
    print(f"  L{i+1}/10: {mark} exit={ec} ({elapsed}ms)")
    if not ok: ALL_OK = False

out = os.path.join(TMP, "launch_exit_10x.json")
with open(out, "w", encoding="utf-8") as f: json.dump(results, f, ensure_ascii=False, indent=2)

print(f"[L0] 10 次启动/退出全部 OK = {ALL_OK}")
sys.exit(0 if ALL_OK else 1)
