"""新进程重启 → 历史窗口 → 撤销 → 关闭 + 三份清单核对 + 反例检出。

被外层监督进程启动；会读取 PART1 留下的 state.json。
"""
from __future__ import annotations
import hashlib, json, os, shutil, sys, time

SRC = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SRC)

BASE = os.environ.get("ARCHIVEBOX_TEST_BASE", r"C:\Users\Lenovo\AppData\Local\Temp\_abx_full_round")
EVIDENCE = os.environ.get("ARCHIVEBOX_EVIDENCE", os.path.join(BASE, "evidence"))
state_file = os.path.join(EVIDENCE, "state.json")

with open(state_file, "r", encoding="utf-8") as f:
    state = json.load(f)

RUN_ID = state["run_id"]
ROOT = state["root"]
SHOT_DIR = os.path.join(EVIDENCE, "shots")
MANIFEST_DIR = os.path.join(EVIDENCE, "manifests")

os.environ.setdefault("ARCHIVEBOX_RECENT_FILE", os.path.join(BASE, "recent.json"))
os.environ.setdefault("ARCHIVEBOX_APP_DIR", os.path.join(BASE, "appdata"))
os.environ.setdefault("ARCHIVEBOX_SCHEME_DIR", os.path.join(BASE, "appdata", "schemes"))
os.environ.pop("QT_QPA_PLATFORM", None)

from PySide6.QtWidgets import QApplication, QMessageBox
for n in ("information", "warning", "critical"):
    setattr(QMessageBox, n, staticmethod(lambda *a, **k: QMessageBox.Ok))
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.Yes)

RESULTS = []
def rec(tid, title, status, detail=""):
    RESULTS.append({"id": tid, "status": status, "title": title, "detail": detail})
    tag = {"PASS": "PASS", "FAIL": "FAIL", "BLOCK": "BLOCK"}.get(status, status)
    print(f"[{tag}] {tid} {title}")
    for line in str(detail).splitlines()[:2]:
        print(f"         {line}")

def pump(app, sec=0.3):
    t0 = time.time()
    while time.time() - t0 < sec:
        app.processEvents(); time.sleep(0.02)

def wait(app, cond, timeout=30, label=""):
    t0 = time.time()
    while time.time() - t0 < timeout:
        app.processEvents()
        if cond(): return True
        time.sleep(0.02)
    print(f"  wait TIMEOUT ({label})")
    return bool(cond())

def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(65536), b""): h.update(c)
    return h.hexdigest()
def _norm(p): return p.replace("\\", "/")

def full_manifest(root, exclude=None):
    exclude = set(exclude or [".organizer"])
    m = {}
    for dp, dn, fn in os.walk(root, followlinks=False):
        dn[:] = [d for d in dn if d not in exclude]
        for f in fn:
            full = os.path.join(dp, f)
            rel = _norm(os.path.relpath(full, root))
            m[rel] = (os.path.getsize(full), _sha(full))
    return m

def shot(w, name):
    path = os.path.join(SHOT_DIR, f"{RUN_ID}_{name}")
    w.grab().save(path)
    return path

print(f"=== windows_desktop_full PART2 RUN_ID={RUN_ID} ===")
print(f"ROOT={ROOT}")

app = QApplication(sys.argv)
print(f"platform={app.platformName()}")

from main import MainWindow, HistoryDialog
from storage import Storage

w = MainWindow()
w.path_edit.setText(ROOT)
w._reset_for_new_dir(ROOT)
w.show()
pump(app)
rec("R0", "新进程主窗口正常启动", "PASS", f"platform={app.platformName()}")

# === 直接从历史窗口读（不需要重新扫描）===
# 打开历史对话框
hist = HistoryDialog(w)
hist.load_items(force=True)
hist.show()
pump(app)
shot(hist, "04_history_dialog.png")

row_count = hist.batch_table.rowCount() if hasattr(hist, "batch_table") else -1
rec("R1", f"历史窗口 batch_table 有 {row_count} 条批次记录", "PASS" if row_count >= 1 else "FAIL")

# 找最近一个批次（不限状态）；如果已经 undone，说明前序已撤销过，重新扫描+执行+撤销
from storage import BatchRecord
st_probe = Storage(ROOT)
all_batches = st_probe.list_batches()
st_probe.close()
rec("R2", f"磁盘数据库批次列表共 {len(all_batches)} 条", "PASS" if len(all_batches) >= 1 else "FAIL",
    f"statuses={[b.status for b in all_batches]}")

# 找一个还可以撤销的 done 批次；如果没有，就先执行一遍生成新批次
target_batch = next((b for b in all_batches if b.status == "done"), None)

ok = wait(app, lambda: w._storage is not None, timeout=10, label="storage")
if ok:
    if target_batch is not None:
        # === 直接撤销已有的 done 批次 ===
        w.on_undo()
        ok2 = wait(app, lambda: (not w._working and
                                 hasattr(w, '_undo_worker') and w._undo_worker is not None and
                                 not w._undo_worker.isRunning()),
                   timeout=45, label="undo")
        rec("U1", "撤销线程正常结束（撤销已有的 done 批次）", "PASS" if ok2 else "FAIL")
    else:
        # === 没有可撤销批次（都 undone 了）：重新扫描→执行→撤销 ===
        rec("U1", "没有 done 批次，走 scan→execute→undo 完整路径", "PASS")
        w.on_scan()
        wait(app, lambda: (not w._working and not w._plan_working), timeout=30, label="rescan")
        w.on_execute()
        wait(app, lambda: (not w._working and (not hasattr(w, '_exec_worker') or not w._exec_worker.isRunning())),
             timeout=45, label="reexec")
        w.on_undo()
        ok2 = wait(app, lambda: (not w._working and
                                 hasattr(w, '_undo_worker') and w._undo_worker is not None and
                                 not w._undo_worker.isRunning()),
                   timeout=45, label="undo_after_reexec")
        rec("U1b", "scan→execute→undo 完整路径", "PASS" if ok2 else "FAIL")
else:
    rec("U1", "撤销前置条件未满足", "BLOCK")

shot(w, "05_after_undo.png")

# === 核对：批次所有 action 已 undone ===
st2 = Storage(ROOT)
latest = st2.get_latest_batch()
actions = st2.get_actions(latest.batch_id) if latest else []
st2.close()
undone_count = sum(1 for a in actions if a.status == "undone")
rec("U2", f"批次 {latest.batch_id if latest else None} 全部 {undone_count}/{len(actions)} action 已 undone",
    "PASS" if (latest and undone_count == len(actions) and len(actions) > 0) else "FAIL")

# === 三份清单最终核对 ===
AFTER_UNDO = full_manifest(ROOT)
save_path = os.path.join(MANIFEST_DIR, f"after_undo_{RUN_ID}.json")
import json as _j
_j.dump({"count": len(AFTER_UNDO),
         "items": {k: {"size": v[0], "sha256": v[1]} for k, v in sorted(AFTER_UNDO.items())}},
        open(save_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

# 读回 BEFORE
before_path = os.path.join(MANIFEST_DIR, f"before_{RUN_ID}.json")
BEFORE = {k: (v["size"], v["sha256"]) for k, v in
          _j.load(open(before_path, encoding="utf-8"))["items"].items()}

missing = sorted(set(BEFORE) - set(AFTER_UNDO))
extra = sorted(set(AFTER_UNDO) - set(BEFORE))
changed = sorted(k for k in set(BEFORE) & set(AFTER_UNDO) if BEFORE[k] != AFTER_UNDO[k])

rec("F1", f"缺失文件={len(missing)}", "PASS" if not missing else "FAIL", f"missing={missing[:5]}")
rec("F2", f"多余文件={len(extra)}", "PASS" if not extra else "FAIL", f"extra={extra[:5]}")
rec("F3", f"内容变化={len(changed)}", "PASS" if not changed else "FAIL", f"changed={changed[:5]}")

# === 反例验证：归档目录多出文件能被检出 ===
def anti_test():
    """在独立副本里故意制造'归档目录多出文件'，验证核对器能检出。"""
    anti_root = os.path.join(BASE, "anti_example", RUN_ID)
    if os.path.exists(anti_root): shutil.rmtree(anti_root)
    os.makedirs(anti_root, exist_ok=True)
    # 放一个正常文件 + 一个故意的"多余"归档文件
    for p, c in [("讲义.pdf", "content"),
                 ("_已整理/归档外残留.pdf", "stale-bytes")]:
        full = os.path.join(anti_root, p)
        os.makedirs(os.path.dirname(full) or anti_root, exist_ok=True)
        with open(full, "wb") as f: f.write(c.encode("utf-8"))

    # 模拟 BEFORE（只有讲义）和 AFTER（多出归档残留）
    before = full_manifest(anti_root)
    # 故意删掉多余项，模拟 BEFORE 没记录
    before_cleaned = {k: v for k, v in before.items() if "_已整理" not in k}
    after = before  # 实际 AFTER 多出了 _已整理 里的文件

    missing = set(before_cleaned) - set(after)
    extra = set(after) - set(before_cleaned)
    changed = [k for k in set(before_cleaned) & set(after) if before_cleaned[k] != after[k]]

    return len(missing) == 0 and len(extra) == 1 and "_已整理/归档外残留.pdf" in extra

anti_ok = anti_test()
rec("A1", "反例：归档目录多出文件能被检出", "PASS" if anti_ok else "FAIL")

# === 关闭 ===
w.close()
hist.close()
pump(app)

print(f"DESKTOP_PART2_OK  exit=0")
sys.exit(0)
