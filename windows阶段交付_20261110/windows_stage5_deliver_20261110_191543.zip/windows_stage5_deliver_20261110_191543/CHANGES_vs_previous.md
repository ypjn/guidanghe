# 相对上一轮（stage4 / 172431）的修改与差异

## 1. 证据与记录（不改产品）

| 项 | 上一轮 | 本轮 |
| --- | --- | --- |
| 证据溯源 | report/截图/desktop_state/stage_diffs 用了 172314 轮，process.json 用 172431 轮（**错配**） | `evidence_index.json` 全部指向单轮 `20261110_192155_7ac9ee`；上轮另出 `evidence_index_20261110_172431.json`，旧目录未改 |
| 排除周期 | 无此概念 | `excluded_cycle` 列出 10 个 run 目录与排除理由（包装器退出码无法证明），文件保留未删 |
| 退出码字段 | `exit_code`（超时也写 -999，易被误读为 OS 退出码） | 新增 `exit_code_kind` / `os_exit_code`；-999 明确标为 `timeout_sentinel`，`os_exit_code` 记为「未采集（进程被强制终止）」 |
| L4 调用者退出码 | 未采集，只有三级 | `run_stage5.ps1` → `caller_observed_exit.txt`，本轮 L4=0 |
| 子进程退出码 | 部分套件只看子进程 JSON 是否完整 | 新增 `Results.check_child_exits()`：非豁免子进程 `timed_out` 或 `exit_code!=0` 即判父套件 FAIL；无记录也 FAIL |
| 桌面截图/清单 | 命名与内容来自 172318_6f5054 | 全部来自 `192155_7ac9ee`（7 张截图 + 三份清单 + stage_diffs） |

## 2. 测试框架（`tests/`）

- `windows_harness.py`：新增模块级 `CHILD_LOG`（`run_child` 每条记录入册）、`Results.check_child_exits(tid, allow_labels, title_extra)`；`run_child` 增加 `exit_code_kind` / `os_exit_code`
- `windows_supervisor.py`：`SUITES` 增加 `s5_plan_scope`（timeout 1500s）与 `s5_names_occupancy`（600s）；`run_one` 写入 `exit_code_kind` / `os_exit_code`
- `windows_w2_1_cancel_close.py`：新增 `C_EXIT`（全部 GUI 子进程）
- `windows_w2_2_recovery.py`：新增 `F_EXIT`，唯一豁免 `f5_interrupt`（受控中断故障注入）
- `windows_w2_3_config_isolation.py`：新增 `Q_EXIT`
- `windows_protect_paths.py`：新增 `P2b`（HOME 在 root 外的矩阵子进程仍 `exit==0` 且产出结果）
- 新增 `windows_stage5_plan_scope.py`（5 个 GUI 子进程：范围失效 / 配置快照 / 迟到结果 / 计划取消 / 生命周期）
- 新增 `windows_stage5_names_occupancy.py`（名称与路径边界 + 占用 + 只读属性；含 ctypes `CreateFileW` 占用持有子进程）
- 新增 `run_stage5.ps1`（纯 ASCII；`Start-Process -PassThru -Wait` 取真实退出码；写双层退出码记录；`exit $intended`）

## 3. 生产代码（仅 1 处新修改）

- `executor.py`：`shutil.move` 兜底失败时，若目标确为本文件副本（SHA-256 相同）且源仍存在，删除该残留副本，并写入「已清理本次失败留下的目标副本」；保证「失败 = 源在、目标不在」，使撤销后清单与初始一致
- 其余生产文件（`main.py`、`protect_config.py`、`_windows_paths.py`）**本轮未改**，与上轮一致；补丁中包含它们是为了让补丁可从冻结基线一次应用到位

## 4. 未变

- 技术栈：Python 3.14.7 + PySide6 6.12.0 + Qt Widgets + SQLite
- 产品语义：分类模式、计划/执行/撤销/恢复、历史记录、批次状态机、`_current_plan_seq` 失效机制、启动快照（`deepcopy`）、扫描结果根目录守卫
- 未新增守卫、未改 UI 结构、未改数据库 schema

## 5. 补丁

`patches/stage5_windows_source.patch`（21 个文件，+5029 / -3）

- 来源：冻结基线 → 本轮最终源码
- 校验：`git apply --check -p1` exit=0；`git apply -p1` exit=0；应用后与最终源码 72 文件逐一比对，0 处不一致（`patches/apply_check.log`）
- 不含 `__pycache__`、`tests/_abx_selftest`、`.abx_owned_*`
