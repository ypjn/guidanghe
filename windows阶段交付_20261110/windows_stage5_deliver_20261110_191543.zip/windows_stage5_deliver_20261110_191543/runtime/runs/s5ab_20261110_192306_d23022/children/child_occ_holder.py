
import ctypes, json, os, sys, time
from ctypes import wintypes
path = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5ab_20261110_192306_d23022\occ\大二上\数据结构\乙-被占用.pdf"
ready = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5ab_20261110_192306_d23022\children\occ_ready.json"
release = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5ab_20261110_192306_d23022\children\occ_release.flag"
GENERIC_READ = 0x80000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
OPEN_EXISTING = 3
k32 = ctypes.WinDLL("kernel32", use_last_error=True)
k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                            ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
                            ctypes.c_void_p]
k32.CreateFileW.restype = ctypes.c_void_p
INVALID = ctypes.c_void_p(-1).value
h = k32.CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                    None, OPEN_EXISTING, 0, None)
ok = h not in (None, INVALID)
info = {"handle_ok": bool(ok), "handle": hex(h) if ok else None,
        "share_mode": "FILE_SHARE_READ|FILE_SHARE_WRITE (无 FILE_SHARE_DELETE)",
        "desired_access": "GENERIC_READ",
        "get_last_error": ctypes.get_last_error(),
        "pid": os.getpid()}
with open(ready, "w", encoding="utf-8") as f:
    json.dump(info, f, ensure_ascii=False)
if not ok:
    sys.exit(3)
deadline = time.time() + 90
while not os.path.exists(release) and time.time() < deadline:
    time.sleep(0.05)
k32.CloseHandle(ctypes.c_void_p(h))
sys.exit(0)
