
import json, os, sys, threading, time
SRC = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码"
TESTS = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests"
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\c2_root"
OUTJSON = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\children\c2_obs.json"
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
sys.path.insert(0, SRC)
sys.path.insert(0, TESTS)
os.environ.pop("QT_QPA_PLATFORM", None)
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
WINDOW = 2
TRACEFILE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\children\c2_obs.json.trace"
TRACE = []
OPEN_DIALOGS = []
def trace(msg):
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    TRACE.append(line)
    print(f"[trace] {msg}", flush=True)
    # 立即落盘：即使父进程超时强杀，也能看到最后观测到的阶段
    try:
        with open(TRACEFILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass

# 硬看门狗：模态弹窗等阻塞不会无限挂住父套件（退出码 9 可识别）
def _watchdog():
    trace("WATCHDOG_FIRED")
    os._exit(9)
_wd = threading.Timer(150, _watchdog)
_wd.daemon = True
_wd.start()

# 测试专属同步点：第 WINDOW 次真实移动完成后阻塞工作线程
real_rename = os.rename
_ren = {"n": 0}
reached = threading.Event()
gate = threading.Event()
def hooked_rename(a, b, **kw):
    real_rename(a, b)
    _ren["n"] += 1
    if WINDOW and _ren["n"] == WINDOW:
        trace("sync_point_hit after rename #%d" % _ren["n"])
        reached.set()
        gate.wait(60)
        trace("sync_point_released")
os.rename = hooked_rename

import storage as storage_mod
_storage_ctor = {"calls": []}
_orig_init = storage_mod.Storage.__init__
def patched_init(self, *a, **kw):
    _orig_init(self, *a, **kw)
    _storage_ctor["calls"].append({
        "thread": threading.current_thread().name,
        "id": id(self),
    })
storage_mod.Storage.__init__ = patched_init

from PySide6.QtWidgets import QApplication, QMessageBox, QDialogButtonBox
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, pump, wait_until

logs = []
_orig_set_working = main.MainWindow._set_working
def traced_set_working(self, busy, *a, **kw):
    trace(f"_set_working({busy})")
    return _orig_set_working(self, busy, *a, **kw)
main.MainWindow._set_working = traced_set_working

def dump(extra):
    payload = {"trace": TRACE, "renames": _ren["n"],
               "open_dialogs": OPEN_DIALOGS,
               "storage_calls": _storage_ctor["calls"], **extra}
    with open(OUTJSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

# 打开根目录时产品可能弹出「未完成批次」询问框。
# 本套件用全新根目录，正常不应出现；若出现则记录并选「否」，
# 由断言把「意外弹窗」暴露出来，而不是让子进程静默挂死。
def open_space(path):
    def on_q(dlg):
        txt = dialog_text(dlg)
        OPEN_DIALOGS.append(txt)
        trace("open_space_dialog: " + txt.splitlines()[0] if txt else "open_space_dialog")
        try:
            return dlg.button(QMessageBox.No)
        except Exception:
            return None
    st = arm_modal(on_q, timeout=6.0)
    w._open_recent_space(path)
    pump(app, 0.3)
    return st

def click_confirm():
    def on_confirm(dlg):
        bb = dlg.findChild(QDialogButtonBox)
        return bb.button(QDialogButtonBox.Ok)
    # 计划刚发布时按钮启用可能落后一个事件轮次：先等按钮可用，
    # 点击后若确认框未出现则重试（不能把“按钮没点动”当成通过）
    wait_until(app, lambda: w.btn_execute.isEnabled(), 30, "btn_execute enabled")
    st = None
    for _ in range(5):
        if st is not None and st.get("handled"):
            break
        st = arm_modal(on_confirm, timeout=8.0)
        QTest.mouseClick(w.btn_execute, Qt.LeftButton)
        pump(app, 0.3)
    return st

from PySide6.QtCore import QTimer
w = main.MainWindow()
w.show()
wait_until(app, lambda: w.isVisible(), 20, "visible")
recent_spaces.touch(ROOT)
open_space(ROOT)
w.path_edit.setText(ROOT)
QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: (w.scan_result is not None and not w._working
                        and not w._plan_working), 60, "scan")
click_confirm()
hit = wait_until(app, reached.is_set, 90, "sync point")
bs = w._storage.list_batches()
batch_id = bs[0].batch_id if bs else None
trace(f"reached={hit} in_flight={_ren['n']} batch={batch_id}")

# 关闭窗口：走正常 closeEvent，应进入等待相位而非立刻关闭
w.close()
pump(app, 0.3)
pending = getattr(w, "_close_pending", False)
closing = getattr(w, "_closing", False)
alive_storage = w._storage is not None
db_usable = False
if alive_storage:
    try:
        db_usable = w._storage.conn.execute("select 1").fetchone()[0] == 1
    except Exception as e:
        trace(f"db error {e!r}")
trace(f"close_pending={pending} closing={closing} storage_alive={alive_storage} db_usable={db_usable}")

# 关闭等待期间禁止启动新任务
scan_before = w.scan_result
nb_before = len(w._storage.list_batches()) if w._storage else -1
w.on_scan()
pump(app, 0.3)
blocked = (w.scan_result is scan_before) and (
    (len(w._storage.list_batches()) if w._storage else -1) == nb_before)
trace(f"new_task_blocked={blocked} working={w._working}")

# 各后台线程独立 SQLite 连接
calls = _storage_ctor["calls"]
main_thread_name = threading.main_thread().name
worker_calls = [c for c in calls if c["thread"] != main_thread_name]
distinct = len(set(c["id"] for c in calls)) == len(calls)
trace(f"storage_in_worker_threads={len(worker_calls)} distinct={distinct}")

gate.set()
trace("gate_released")
closed = wait_until(app, lambda: not w.isVisible(), 90, "window closed after worker end")
trace(f"closed={closed} closing_flag={getattr(w,'_closing',None)}")
dump({"phase": "after_close", "batch_id": batch_id, "hit": hit,
      "close_pending": pending, "closing_during_wait": closing,
      "storage_alive_during_wait": alive_storage, "db_usable": db_usable,
      "new_task_blocked": blocked,
      "storage_worker_threads": len(worker_calls),
      "storage_distinct": distinct,
      "closed": closed, "closing_after": getattr(w, "_closing", None),
      "renames": _ren["n"]})
sys.exit(0 if (hit and pending and not closing and closed) else 1)
