
import json, os, sys, threading, time
SRC = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码"
TESTS = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests"
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\c1_root"
OUTJSON = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\children\c1_undo.json"
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
sys.path.insert(0, SRC)
sys.path.insert(0, TESTS)
os.environ.pop("QT_QPA_PLATFORM", None)
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
WINDOW = 999
TRACEFILE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w21_20261110_192212_5a296d\children\c1_undo.json.trace"
TRACE = []
OPEN_DIALOGS = []
def trace(msg):
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    TRACE.append(line)
    print(f"[trace] {msg}", flush=True)
    # 立即落盘：即使父进程超时强杀，也能看到最后观测到的阶段
    try:
        with open(TRACEFILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass

# 硬看门狗：模态弹窗等阻塞不会无限挂住父套件（退出码 9 可识别）
def _watchdog():
    trace("WATCHDOG_FIRED")
    os._exit(9)
_wd = threading.Timer(150, _watchdog)
_wd.daemon = True
_wd.start()

# 测试专属同步点：第 WINDOW 次真实移动完成后阻塞工作线程
real_rename = os.rename
_ren = {"n": 0}
reached = threading.Event()
gate = threading.Event()
def hooked_rename(a, b, **kw):
    real_rename(a, b)
    _ren["n"] += 1
    if WINDOW and _ren["n"] == WINDOW:
        trace("sync_point_hit after rename #%d" % _ren["n"])
        reached.set()
        gate.wait(60)
        trace("sync_point_released")
os.rename = hooked_rename

import storage as storage_mod
_storage_ctor = {"calls": []}
_orig_init = storage_mod.Storage.__init__
def patched_init(self, *a, **kw):
    _orig_init(self, *a, **kw)
    _storage_ctor["calls"].append({
        "thread": threading.current_thread().name,
        "id": id(self),
    })
storage_mod.Storage.__init__ = patched_init

from PySide6.QtWidgets import QApplication, QMessageBox, QDialogButtonBox
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, pump, wait_until

logs = []
_orig_set_working = main.MainWindow._set_working
def traced_set_working(self, busy, *a, **kw):
    trace(f"_set_working({busy})")
    return _orig_set_working(self, busy, *a, **kw)
main.MainWindow._set_working = traced_set_working

def dump(extra):
    payload = {"trace": TRACE, "renames": _ren["n"],
               "open_dialogs": OPEN_DIALOGS,
               "storage_calls": _storage_ctor["calls"], **extra}
    with open(OUTJSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

# 打开根目录时产品可能弹出「未完成批次」询问框。
# 本套件用全新根目录，正常不应出现；若出现则记录并选「否」，
# 由断言把「意外弹窗」暴露出来，而不是让子进程静默挂死。
def open_space(path):
    def on_q(dlg):
        txt = dialog_text(dlg)
        OPEN_DIALOGS.append(txt)
        trace("open_space_dialog: " + txt.splitlines()[0] if txt else "open_space_dialog")
        try:
            return dlg.button(QMessageBox.No)
        except Exception:
            return None
    st = arm_modal(on_q, timeout=6.0)
    w._open_recent_space(path)
    pump(app, 0.3)
    return st

def click_confirm():
    def on_confirm(dlg):
        bb = dlg.findChild(QDialogButtonBox)
        return bb.button(QDialogButtonBox.Ok)
    # 计划刚发布时按钮启用可能落后一个事件轮次：先等按钮可用，
    # 点击后若确认框未出现则重试（不能把“按钮没点动”当成通过）
    wait_until(app, lambda: w.btn_execute.isEnabled(), 30, "btn_execute enabled")
    st = None
    for _ in range(5):
        if st is not None and st.get("handled"):
            break
        st = arm_modal(on_confirm, timeout=8.0)
        QTest.mouseClick(w.btn_execute, Qt.LeftButton)
        pump(app, 0.3)
    return st

from executor import undo_is_available, undo_latest_batch
from storage import Storage
s = Storage(ROOT)
avail = undo_is_available(s)
res = undo_latest_batch(s)
after = {"source": 0, "target": 0}
for dp, dn, fn in os.walk(ROOT):
    rel = os.path.relpath(dp, ROOT)
    head = rel.split(os.sep)[0]
    if head == ".organizer" or head.startswith(".abx_owned"):
        continue
    if head == "_已整理":
        after["target"] += len(fn)
    else:
        after["source"] += len(fn)
bs = s.list_batches()
b = bs[0] if bs else None
json.dump({"available": avail, "restored": res.restored,
           "conflict": res.conflict, "errors": res.errors,
           "batch_status": getattr(b, "status", None), "batch_id": getattr(b, "batch_id", None),
           "disk": after},
          open(OUTJSON, "w", encoding="utf-8"), ensure_ascii=False)
s.close()
