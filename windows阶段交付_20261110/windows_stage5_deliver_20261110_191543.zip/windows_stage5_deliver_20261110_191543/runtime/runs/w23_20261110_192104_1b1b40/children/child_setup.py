
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
ROOT_A = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192104_1b1b40\root_a"
ROOT_B = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192104_1b1b40\root_b"
from classification_config import default_config, save_config, load_config
from protect_config import save_manual_protect, load_manual_protect

cfg_a = default_config()
n_changed = 0
for r in cfg_a.semester_dir_rules:
    if r.semester == "大二上" and r.source == "数据结构":
        r.direction = "项目"
        n_changed += 1
save_config(ROOT_A, cfg_a)
save_config(ROOT_B, default_config())
save_manual_protect(ROOT_A, [os.path.join(ROOT_A, "大二上", "高等数学")])

back_a, src_a = load_config(ROOT_A)
back_b, src_b = load_config(ROOT_B)
prot_a = load_manual_protect(ROOT_A)
prot_b = load_manual_protect(ROOT_B)
print("SETUP_JSON=" + json.dumps({
    "changed": n_changed,
    "a_direction": sorted({r.direction for r in back_a.semester_dir_rules
                           if r.semester == "大二上" and r.source == "数据结构"}),
    "b_direction": sorted({r.direction for r in back_b.semester_dir_rules
                           if r.semester == "大二上" and r.source == "数据结构"}),
    "protect_a": prot_a, "protect_b": prot_b,
    "source_a": src_a, "source_b": src_b,
}, ensure_ascii=False))
