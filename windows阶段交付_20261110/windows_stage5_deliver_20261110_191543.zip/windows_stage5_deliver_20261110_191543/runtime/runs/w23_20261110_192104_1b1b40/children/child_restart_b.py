
import json, os, sys, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192104_1b1b40\root_b"
ROOT_A = ROOT
ROOT_B = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192104_1b1b40\root_b"
OUTJSON = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192104_1b1b40\children\restart_b.json"
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
STEPS = []
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")

from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until

dialogs = []

def open_space(path):
    def on_q(dlg):
        dialogs.append(dialog_text(dlg))
        try:
            return dlg.button(QMessageBox.No)
        except Exception:
            return None
    arm_modal(on_q, timeout=6.0)
    w._open_recent_space(path)
    pump(app, 0.3)

def rows():
    out = []
    for r in range(w.table.rowCount()):
        cells = []
        for c in range(w.table.columnCount()):
            it = w.table.item(r, c)
            cells.append((it.text() if it else "").replace("\\", "/"))
        out.append(cells)
    return out

def snap(tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": rows(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "invalid_visible": w.invalid_label.isVisible(),
        "execute_enabled": w.btn_execute.isEnabled(),
        "scope": getattr(w, "_plan_scope", "?"),
        "status": w.statusBar().currentMessage(),
    }

w = main.MainWindow()
w.show()
auto = AutoOk(app)   # 只自动确认“只有 Ok”的提示框（如配置变更提示），并记录全文
wait_until(app, lambda: w.isVisible(), 20, "visible")
recent_spaces.touch(ROOT)
open_space(ROOT)

obs = {"steps": STEPS, "first": None, "after_scan": None, "invalidate": {},
       "late": {}, "dialogs": dialogs}

QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: (w.scan_result is not None and not w._working
                        and not w._plan_working), 60, "scan+plan")
pump(app, 0.5)
obs["after_scan"] = snap("after_scan")

if "invalidate_config" in STEPS:
    # 通过产品自身的保存配置入口修改配置 → 旧计划必须失效
    before = snap("before_cfg_change")
    cfg = w.classification_config
    from classification_config import GenericDirRule
    cfg.generic_dir_rules.append(
        GenericDirRule(prefix="讲座", direction="校园事务", category="讲座"))
    w._save_classification_config(ROOT, cfg)
    pump(app, 0.4)
    obs["invalidate"]["config"] = {"before": before, "after": snap("after_cfg")}
    # 重新生成，再做“切根目录”
    QTest.mouseClick(w.btn_scan, Qt.LeftButton)
    wait_until(app, lambda: (not w._working and not w._plan_working), 60, "rescan")
    pump(app, 0.4)
    obs["invalidate"]["rescan"] = snap("after_rescan")
    open_space(ROOT_B)
    pump(app, 0.4)
    obs["invalidate"]["switch_root"] = snap("after_switch_root")

if "late_result" in STEPS:
    # 在 A 的计划生成过程中切到 B，A 的迟到结果不得覆盖 B 的界面
    open_space(ROOT_A)
    pump(app, 0.2)
    QTest.mouseClick(w.btn_scan, Qt.LeftButton)
    started = wait_until(app, lambda: w._working, 10, "A scan started")
    trace_started = bool(started)
    open_space(ROOT_B)
    wait_until(app, lambda: (not w._working and not w._plan_working), 60, "late settle")
    pump(app, 0.6)
    obs["late"] = snap("after_late")
    obs["late"]["a_scan_started"] = trace_started

auto.stop()
with open(OUTJSON, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
w.close()
pump(app, 0.3)
print("GUI_JSON_DONE")
