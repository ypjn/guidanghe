
import json, os, sys, threading, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
from PySide6.QtWidgets import (QApplication, QMessageBox, QFileDialog,
                               QDialogButtonBox)
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until, shot

EV = []
def mark(name, extra=None):
    d = {"t": time.perf_counter(), "ev": name}
    if extra:
        d.update(extra)
    EV.append(d)

def snap(w, tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": w.table.rowCount(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "selected": (0 if plan is None else plan.selected_count),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "plan_valid": bool(w._plan_valid),
        "invalid_visible": bool(w.invalid_label.isVisible()),
        "invalid_text": w.invalid_label.text(),
        "execute_enabled": bool(w.btn_execute.isEnabled()),
        "regenerate_enabled": bool(w.btn_regenerate.isEnabled()),
        "scan_result_none": w.scan_result is None,
        "scope": getattr(w, "_plan_scope", "?"),
        "seq": w._current_plan_seq,
        "status": w.statusBar().currentMessage(),
    }

ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\s2root"
OUTJ = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\children\s2.json"
from classification_config import save_config
import copy
recent_spaces.touch(ROOT)
w = main.MainWindow(); w.show()
auto = AutoOk(app)
wait_until(app, lambda: w.isVisible(), 20, "visible")
w._open_recent_space(ROOT)
pump(app, 0.4)

GATE = {"entered": threading.Event(), "release": threading.Event()}
rear = {"real": main.generate_plan}
def gated(*a, **kw):
    GATE["entered"].set()
    GATE["release"].wait(60)
    return rear["real"](*a, **kw)
main.generate_plan = gated

obs = {"dialogs": auto.seen}

# --- 阶段 A：任务启动时快照，界面对象中途被改也不影响本次结果
QTest.mouseClick(w.btn_scan, Qt.LeftButton)
entered = wait_until(app, lambda: GATE["entered"].is_set(), 60, "plan gate A")
obs["A_gate_entered"] = bool(entered)
mark("A_plan_task_running")
before_cfg = sorted({r.direction for r in w.classification_config.semester_dir_rules
                     if r.semester == "大二上" and r.source == "数据结构"})
n_mut = 0
for r in w.classification_config.semester_dir_rules:
    if r.semester == "大二上" and r.source == "数据结构":
        r.direction = "项目"
        n_mut += 1
obs["A_mutated_ui_object"] = {"n": n_mut, "before": before_cfg,
    "after": sorted({r.direction for r in w.classification_config.semester_dir_rules
                     if r.semester == "大二上" and r.source == "数据结构"})}
mark("A_config_object_mutated")
GATE["release"].set()
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "plan A done")
pump(app, 0.4)
obs["A_after"] = snap(w, "A_after")

# --- 阶段 B：计划任务进行中经产品入口保存配置 → 按失效机制丢弃旧结果
GATE["entered"].clear(); GATE["release"].clear()
QTest.mouseClick(w.btn_regenerate, Qt.LeftButton)
wait_until(app, lambda: GATE["entered"].is_set(), 60, "plan gate B")
obs["B_gate_entered"] = bool(GATE["entered"].is_set())
seq_before = w._current_plan_seq
cfg2 = copy.deepcopy(w.classification_config)
w._save_classification_config(ROOT, cfg2)
pump(app, 0.5)
seq_after = w._current_plan_seq
mark("B_config_saved_via_product_entry")
obs["B_seq"] = {"before": seq_before, "after": seq_after}
obs["B_after_save"] = snap(w, "B_after_save")
GATE["release"].set()
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "plan B done")
pump(app, 0.6)
obs["B_after_release"] = snap(w, "B_after_release")
mark("B_late_result_settled")

# --- 阶段 C：重新生成 → 新配置生效，且计划可执行
if w.btn_regenerate.isEnabled():
    QTest.mouseClick(w.btn_regenerate, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "plan C")
pump(app, 0.4)
obs["C_after"] = snap(w, "C_after")
obs["events"] = EV
with open(OUTJ, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
auto.stop()
w.close(); pump(app, 0.3)
print("S2_DONE")
