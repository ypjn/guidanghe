
import json, os, sys, threading, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
from PySide6.QtWidgets import (QApplication, QMessageBox, QFileDialog,
                               QDialogButtonBox)
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until, shot

EV = []
def mark(name, extra=None):
    d = {"t": time.perf_counter(), "ev": name}
    if extra:
        d.update(extra)
    EV.append(d)

def snap(w, tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": w.table.rowCount(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "selected": (0 if plan is None else plan.selected_count),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "plan_valid": bool(w._plan_valid),
        "invalid_visible": bool(w.invalid_label.isVisible()),
        "invalid_text": w.invalid_label.text(),
        "execute_enabled": bool(w.btn_execute.isEnabled()),
        "regenerate_enabled": bool(w.btn_regenerate.isEnabled()),
        "scan_result_none": w.scan_result is None,
        "scope": getattr(w, "_plan_scope", "?"),
        "seq": w._current_plan_seq,
        "status": w.statusBar().currentMessage(),
    }

ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\s5root"
OUTJ = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\children\s5.json"
import sqlite3
recent_spaces.touch(ROOT)
EVENTS = []
class LoggedConn(sqlite3.Connection):
    def close(self):
        EVENTS.append({"t": time.perf_counter(), "ev": "conn_close",
                       "id": id(self), "thread": threading.get_ident(),
                       "thread_name": threading.current_thread().name})
        return super().close()
_real = sqlite3.connect
def _connect(*a, **kw):
    kw.setdefault("factory", LoggedConn)
    c = _real(*a, **kw)
    EVENTS.append({"t": time.perf_counter(), "ev": "conn_connect", "id": id(c),
                   "db": (a[0] if a else kw.get("database")),
                   "thread": threading.get_ident(),
                   "thread_name": threading.current_thread().name})
    return c
sqlite3.connect = _connect

w = main.MainWindow(); w.show()
auto = AutoOk(app)
wait_until(app, lambda: w.isVisible(), 20, "visible")
w._open_recent_space(ROOT)
pump(app, 0.4)
obs = {"main_thread": threading.main_thread().name,
       "main_thread_ident": threading.main_thread().ident}
QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "scan")
pump(app, 0.4)
obs["plan_items"] = (0 if w.current_plan is None else len(w.current_plan.items))
ew_holder = {}
st = arm_modal(lambda d: d.findChild(QDialogButtonBox).button(QDialogButtonBox.Ok),
               timeout=10)
QTest.mouseClick(w.btn_execute, Qt.LeftButton)
wait_until(app, lambda: (not w._working), 120, "execute")
pump(app, 0.6)
obs["exec_confirm"] = st["captured"] is not None
obs["after_exec_status"] = w.statusBar().currentMessage()
EVENTS.append({"t": time.perf_counter(), "ev": "exec_thread_finished_observed",
               "thread": threading.get_ident(),
               "thread_name": threading.current_thread().name})

st2 = arm_modal(lambda d: d.button(QMessageBox.Yes), timeout=10)
QTest.mouseClick(w.btn_undo, Qt.LeftButton)
wait_until(app, lambda: (not w._working), 120, "undo")
pump(app, 0.6)
obs["undo_confirm"] = st2["captured"] is not None
obs["after_undo_status"] = w.statusBar().currentMessage()

EVENTS.append({"t": time.perf_counter(), "ev": "close_requested"})
w.close()
pump(app, 0.8)
EVENTS.append({"t": time.perf_counter(), "ev": "close_returned",
               "storage_is_none": w._storage is None,
               "closing": bool(w._closing), "close_pending": bool(w._close_pending)})
obs["events"] = EVENTS
obs["dialogs"] = auto.seen
with open(OUTJ, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
auto.stop()
print("S5_DONE")
