
import json, os, sys, threading, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
from PySide6.QtWidgets import (QApplication, QMessageBox, QFileDialog,
                               QDialogButtonBox)
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until, shot

EV = []
def mark(name, extra=None):
    d = {"t": time.perf_counter(), "ev": name}
    if extra:
        d.update(extra)
    EV.append(d)

def snap(w, tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": w.table.rowCount(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "selected": (0 if plan is None else plan.selected_count),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "plan_valid": bool(w._plan_valid),
        "invalid_visible": bool(w.invalid_label.isVisible()),
        "invalid_text": w.invalid_label.text(),
        "execute_enabled": bool(w.btn_execute.isEnabled()),
        "regenerate_enabled": bool(w.btn_regenerate.isEnabled()),
        "scan_result_none": w.scan_result is None,
        "scope": getattr(w, "_plan_scope", "?"),
        "seq": w._current_plan_seq,
        "status": w.statusBar().currentMessage(),
    }

ROOTA = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\s3A"; ROOTB = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\s3B"
OUTJ = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192124_11f7bb\children\s3.json"
recent_spaces.touch(ROOTA); recent_spaces.touch(ROOTB)
w = main.MainWindow(); w.show()
auto = AutoOk(app)
wait_until(app, lambda: w.isVisible(), 20, "visible")
w._open_recent_space(ROOTA)
pump(app, 0.4)
obs = {"dialogs": auto.seen}

GATE = {"entered": threading.Event(), "release": threading.Event()}
real_scan = main.scan_directory
def gated_scan(*a, **kw):
    GATE["entered"].set()
    GATE["release"].wait(60)
    return real_scan(*a, **kw)
main.scan_directory = gated_scan

QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: GATE["entered"].is_set(), 60, "scan gate")
mark("A_scan_worker_blocked")
obs["scan_running"] = bool(w._working)
obs["cancel_visible_during_scan"] = bool(w.btn_cancel.isVisible())
obs["cancel_enabled_during_scan"] = bool(w.btn_cancel.isEnabled())
obs["storage"] = None if w._storage is None else w._storage.root
w._open_recent_space(ROOTB)
pump(app, 0.5)
mark("switched_to_B")
obs["after_switch"] = snap(w, "after_switch")
GATE["release"].set()
mark("scan_gate_released")
got = wait_until(app, lambda: "已忽略旧目录的扫描结果"
                 in w.statusBar().currentMessage(), 60, "late scan result")
mark("late_result_delivered", {"observed": bool(got)})
obs["late_observed"] = bool(got)
obs["late_status"] = w.statusBar().currentMessage()
pump(app, 0.5)
obs["after_late"] = snap(w, "after_late")

QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "scan B")
pump(app, 0.4)
obs["after_scan_B"] = snap(w, "after_scan_B")
obs["events"] = EV
with open(OUTJ, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
auto.stop()
w.close(); pump(app, 0.3)
print("S3_DONE")
