
import importlib.util, json, os, sys
mod_path, ROOT, BASE = sys.argv[1], sys.argv[2], sys.argv[3]
cases = json.loads(sys.argv[4])
spec = importlib.util.spec_from_file_location("pc_under_test", mod_path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
out = {}
for name, values in cases.items():
    try:
        out[name] = {"ok": True, "paths": [m.normalize_manual_path(ROOT, v) for v in values]}
    except m.ProtectConfigError as e:
        out[name] = {"ok": False, "error": str(e)}
out["dedupe_same_two_forms"] = {
    "ok": True,
    "paths": m.dedupe_manual_paths(ROOT, ["大二上/高等数学", "./大二上/高等数学"]),
}
out["dedupe_repeat"] = {
    "ok": True,
    "paths": m.dedupe_manual_paths(ROOT, ["大二上/数据结构", "大二上/数据结构/."]),
}
print("RESULT_JSON=" + json.dumps(out, ensure_ascii=False))
