
import json, os, sys, threading, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
from PySide6.QtWidgets import (QApplication, QMessageBox, QFileDialog,
                               QDialogButtonBox)
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until, shot

EV = []
def mark(name, extra=None):
    d = {"t": time.perf_counter(), "ev": name}
    if extra:
        d.update(extra)
    EV.append(d)

def snap(w, tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": w.table.rowCount(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "selected": (0 if plan is None else plan.selected_count),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "plan_valid": bool(w._plan_valid),
        "invalid_visible": bool(w.invalid_label.isVisible()),
        "invalid_text": w.invalid_label.text(),
        "execute_enabled": bool(w.btn_execute.isEnabled()),
        "regenerate_enabled": bool(w.btn_regenerate.isEnabled()),
        "scan_result_none": w.scan_result is None,
        "scope": getattr(w, "_plan_scope", "?"),
        "seq": w._current_plan_seq,
        "status": w.statusBar().currentMessage(),
    }

ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192248_1e1985\s1root"
OUTJ = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192248_1e1985\children\s1.json"
recent_spaces.touch(ROOT)
w = main.MainWindow(); w.show()
auto = AutoOk(app)
wait_until(app, lambda: w.isVisible(), 20, "visible")
w._open_recent_space(ROOT)
pump(app, 0.4)
obs = {"dialogs": auto.seen, "events": EV}

QTest.mouseClick(w.btn_intake, Qt.LeftButton)
wait_until(app, lambda: w._intake_dialog is not None
           and w._intake_dialog.isVisible(), 10, "intake dialog")
dlg = w._intake_dialog
obs["intake_dialog_visible"] = bool(dlg is not None and dlg.isVisible())

picks = [os.path.join(ROOT, "大二上", "数据结构"),
         os.path.join(ROOT, "图片素材")]
QFileDialog.getExistingDirectory = staticmethod(
    lambda *a, **k: picks.pop(0) if picks else "")
QTest.mouseClick(dlg.btn_add_dir, Qt.LeftButton)
pump(app, 0.4)
obs["after_add1"] = {"list_count": dlg.list_widget.count(),
                     "intake_len": len(w.intake),
                     "list_texts": [dlg.list_widget.item(i).text()
                                    for i in range(dlg.list_widget.count())]}

QTest.mouseClick(w.btn_scan_intake, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 60, "scan1")
pump(app, 0.4)
obs["after_scan1"] = snap(w, "after_scan1")
mark("scope_change_start")
QTest.mouseClick(dlg.btn_add_dir, Qt.LeftButton)
pump(app, 0.5)
obs["after_add2"] = {"list_count": dlg.list_widget.count(),
                     "intake_len": len(w.intake)}
obs["after_invalidate"] = snap(w, "after_invalidate")
obs["invalidate_status"] = w.statusBar().currentMessage()

if w.btn_regenerate.isEnabled():
    QTest.mouseClick(w.btn_regenerate, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 60, "regen")
pump(app, 0.5)
obs["after_regen"] = snap(w, "after_regen")

# 真实确认界面：读取根目录/范围/已选统计后取消（不执行移动）
st = arm_modal(lambda d: d.findChild(QDialogButtonBox).button(
    QDialogButtonBox.Cancel), timeout=10)
QTest.mouseClick(w.btn_execute, Qt.LeftButton)
pump(app, 0.5)
obs["confirm"] = {"captured": st["captured"], "error": st["error"],
                  "handled": st["handled"]}
obs["events"] = EV
with open(OUTJ, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
auto.stop()
w.close(); pump(app, 0.3)
print("S1_DONE")
