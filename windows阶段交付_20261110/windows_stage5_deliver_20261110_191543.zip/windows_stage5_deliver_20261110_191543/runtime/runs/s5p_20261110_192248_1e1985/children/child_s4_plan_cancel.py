
import json, os, sys, threading, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")
from PySide6.QtWidgets import (QApplication, QMessageBox, QFileDialog,
                               QDialogButtonBox)
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
app = QApplication([])
import main, recent_spaces
from windows_harness import AutoOk, arm_modal, dialog_text, pump, wait_until, shot

EV = []
def mark(name, extra=None):
    d = {"t": time.perf_counter(), "ev": name}
    if extra:
        d.update(extra)
    EV.append(d)

def snap(w, tag):
    plan = w.current_plan
    return {
        "tag": tag,
        "path": w.path_edit.text().replace("\\", "/"),
        "rows": w.table.rowCount(),
        "plan_items": (0 if plan is None else len(plan.items)),
        "selected": (0 if plan is None else plan.selected_count),
        "sources": ([] if plan is None else
                    [i.file.rel_path.replace("\\", "/") for i in plan.items]),
        "targets": ([] if plan is None else
                    [i.target_rel_path.replace("\\", "/") for i in plan.items]),
        "plan_valid": bool(w._plan_valid),
        "invalid_visible": bool(w.invalid_label.isVisible()),
        "invalid_text": w.invalid_label.text(),
        "execute_enabled": bool(w.btn_execute.isEnabled()),
        "regenerate_enabled": bool(w.btn_regenerate.isEnabled()),
        "scan_result_none": w.scan_result is None,
        "scope": getattr(w, "_plan_scope", "?"),
        "seq": w._current_plan_seq,
        "status": w.statusBar().currentMessage(),
    }

ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192248_1e1985\s4root"
OUTJ = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\s5p_20261110_192248_1e1985\children\s4.json"
recent_spaces.touch(ROOT)
w = main.MainWindow(); w.show()
auto = AutoOk(app)
wait_until(app, lambda: w.isVisible(), 20, "visible")
w._open_recent_space(ROOT)
pump(app, 0.4)
obs = {"dialogs": auto.seen}
GATE = {"entered": threading.Event(), "release": threading.Event()}
real_gen = main.generate_plan
def gated(*a, **kw):
    GATE["entered"].set()
    GATE["release"].wait(60)
    return real_gen(*a, **kw)
main.generate_plan = gated

QTest.mouseClick(w.btn_scan, Qt.LeftButton)
wait_until(app, lambda: GATE["entered"].is_set(), 60, "gate")
mark("plan_task_running")
obs["cancel_visible"] = bool(w.btn_cancel.isVisible())
obs["cancel_enabled"] = bool(w.btn_cancel.isEnabled())
QTest.mouseClick(w.btn_cancel, Qt.LeftButton)
pump(app, 0.3)
mark("cancel_clicked")
obs["cancel_state"] = {
    "cancel_seq": w._plan_cancel_seq, "cur_seq": w._current_plan_seq,
    "requested": bool(w._plan_cancel_requested),
    "status": w.statusBar().currentMessage(),
    "cancel_btn_enabled_after": bool(w.btn_cancel.isEnabled()),
}
GATE["release"].set()
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "cancelled")
pump(app, 0.5)
obs["after_cancel"] = snap(w, "after_cancel")
obs["batches_after_cancel"] = (None if w._storage is None else
                               len(w._storage.list_batches()))
_pb = None if w._storage is None else w._storage.get_pending_batch()
obs["stray_iter_batches"] = None if _pb is None else _pb.batch_id
if w.btn_regenerate.isEnabled():
    QTest.mouseClick(w.btn_regenerate, Qt.LeftButton)
wait_until(app, lambda: (not w._working and not w._plan_working), 90, "regen")
pump(app, 0.4)
obs["after_regen"] = snap(w, "after_regen")
obs["events"] = EV
with open(OUTJ, "w", encoding="utf-8") as f:
    json.dump(obs, f, ensure_ascii=False, indent=2)
auto.stop()
w.close(); pump(app, 0.3)
print("S4_DONE")
