
import copy, json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w23_20261110_192232_7637f8\root_b"
from scanner import scan_directory
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from classification_config import (default_config, ClassificationConfig,
                                   SemesterDirRule, save_config,
                                   LongTermRule, MATCH_DIR_SCOPE)
from plan_patch import OverrideParams, apply_override_to_plan
import main
from main import PlanWorker
from storage import Storage

sr = scan_directory(ROOT, detect_project_roots=False)
cfg = default_config()
save_config(ROOT, cfg)

# 推荐映射基线：数据结构 → 课程
base_plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [], config=cfg)
base_t = {i.file.rel_path.replace("\\", "/"): i.target_rel_path.replace("\\", "/")
          for i in base_plan.items}

# 长期规则：大二上/数据结构 → 方向“长期”
cfg2 = copy.deepcopy(cfg)
cfg2.long_term_rules.append(LongTermRule(
    rule_id="lt-test-0001", name="数据结构长期规则",
    match_type=MATCH_DIR_SCOPE, source_path="大二上/数据结构",
    include_subdirs=True, direction="项目", semester="大二上",
    category="数据结构"))
lt_plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [], config=cfg2)
lt_t = {i.file.rel_path.replace("\\", "/"): i.target_rel_path.replace("\\", "/")
        for i in lt_plan.items}
lt_key = {i.file.rel_path.replace("\\", "/"): i.rule_key for i in lt_plan.items}

# 临时修正（在长期规则命中的计划上）→ 必须压过长期规则
ov_t = ""
ov_note = ""
ov_auto = ""
for src_rel, item in [(i.file.rel_path, i) for i in lt_plan.items]:
    if "数据结构" in src_rel.replace("\\", "/"):
        auto_before = item.target_rel_path.replace("\\", "/")
        apply_override_to_plan(lt_plan, src_rel, OverrideParams(
            direction="竞赛", semester="大二上", category="临时修正课",
            inner_path="", override_note="测试临时修正"))
        ov_t = item.target_rel_path.replace("\\", "/")
        ov_note = item.override_note
        ov_auto = auto_before
        break

# 后台任务快照：产品在把配置交给 PlanWorker 前做深拷贝
import inspect
_src = inspect.getsource(main.MainWindow)
caller_deepcopies = "plan_config = copy.deepcopy(self.classification_config)" in _src
pw = PlanWorker(0, sr, MODE_BY_DIRECTION_SEMESTER, [], config=copy.deepcopy(cfg))
snapshot_copy = copy.deepcopy(pw.config)
cfg.semester_dir_rules.append(SemesterDirRule(
    semester="大二上", source="数据结构", direction="被改坏", category=""))
snap_plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [], config=pw.config)
snap_t = {i.file.rel_path.replace("\\", "/"): i.target_rel_path.replace("\\", "/")
          for i in snap_plan.items}

print("PROBE_JSON=" + json.dumps({
    "base": base_t, "long_term": lt_t, "long_term_keys": lt_key,
    "override_target": ov_t, "override_auto": ov_auto, "override_note": ov_note,
    "worker_same_object": (pw.config is cfg),
    "caller_deepcopies": caller_deepcopies,
    "snapshot_targets": snap_t, "snapshot_is_deep": snapshot_copy is not cfg,
}, ensure_ascii=False))
