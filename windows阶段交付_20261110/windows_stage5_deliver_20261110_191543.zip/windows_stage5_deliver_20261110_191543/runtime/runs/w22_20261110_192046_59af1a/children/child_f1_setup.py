
import hashlib, json, os, shutil, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w22_20261110_192046_59af1a\f1_src_here"
CASE = "src_here"
from scanner import scan_directory
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from storage import Storage, BATCH_EXECUTING

def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()

sr = scan_directory(ROOT, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
items = [i for i in plan.items if i.selected]
st = Storage(ROOT)
bid = st.create_batch(plan, "中断夹具 " + CASE)
for i, item in enumerate(items):
    st.create_action(bid, item, i,
                     sha(os.path.join(ROOT, item.file.rel_path)))
st.update_batch_status(bid, BATCH_EXECUTING)

first = items[0]
src = os.path.join(ROOT, first.file.rel_path)
tgt = os.path.join(ROOT, first.target_rel_path)
os.makedirs(os.path.dirname(tgt), exist_ok=True)
orig_sha = sha(src)
if CASE == "moved_only":
    os.rename(src, tgt)
elif CASE == "both":
    shutil.copy2(src, tgt)
elif CASE == "neither":
    os.remove(src)

out = {"batch_id": bid, "count": len(items),
       "src_rel": first.file.rel_path.replace("\\", "/"),
       "tgt_rel": first.target_rel_path.replace("\\", "/"),
       "orig_sha": orig_sha,
       "src_after_setup": os.path.isfile(src),
       "tgt_after_setup": os.path.isfile(tgt),
       "db_status_after_setup": st.get_batch(bid).status,
       "actions_after_setup": [a.status for a in st.get_actions(bid)]}
st.close()
print("SETUP_JSON=" + json.dumps(out, ensure_ascii=False))
