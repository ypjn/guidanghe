
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w22_20261110_192046_59af1a\f5_interrupt"
OUTJSON = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w22_20261110_192046_59af1a\children\f5_interrupt.json"
from scanner import scan_directory
from planner import generate_plan, MODE_BY_DIRECTION_SEMESTER
from storage import Storage, STATUS_MOVED
from executor import execute_plan

orig = Storage.update_action
def patched(self, batch_id, action_index, status, error=""):
    if status == STATUS_MOVED and action_index == 1:
        with open(OUTJSON, "w", encoding="utf-8") as f:
            json.dump({"interrupted_before_persist_index": action_index,
                       "note": "os.rename 已成功，moved 状态尚未写库"},
                      f, ensure_ascii=False)
        os._exit(7)
    return orig(self, batch_id, action_index, status, error)
Storage.update_action = patched

sr = scan_directory(ROOT, detect_project_roots=False)
plan = generate_plan(sr, MODE_BY_DIRECTION_SEMESTER, [])
st = Storage(ROOT)
execute_plan(plan, st)
st.close()
print("SHOULD_NOT_REACH_END")
