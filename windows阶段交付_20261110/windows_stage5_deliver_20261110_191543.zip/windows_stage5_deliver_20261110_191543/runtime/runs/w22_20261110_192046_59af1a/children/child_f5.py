
import json, os, sys, time
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码\tests")
os.environ.pop("QT_QPA_PLATFORM", None)
ROOT = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w22_20261110_192046_59af1a\f5_interrupt"
OUTJSON = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\w22_20261110_192046_59af1a\children\f5_recover.json"
BASE = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime"
BID = 1
os.environ["ARCHIVEBOX_RECENT_FILE"] = os.path.join(BASE, "recent.json")
os.environ["ARCHIVEBOX_APP_DIR"] = os.path.join(BASE, "appdata")
os.environ["ARCHIVEBOX_SCHEME_DIR"] = os.path.join(BASE, "appdata", "schemes")

from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import Qt
app = QApplication([])
import main, recent_spaces
from windows_harness import (AutoOk, arm_modal, dialog_text, full_manifest,
                             pump, sha256_file, wait_until)

auto = AutoOk(app)          # 只自动确认“只有 Ok”的结果提示框
dialogs = []

w = main.MainWindow()
w.show()
wait_until(app, lambda: w.isVisible(), 20, "visible")
recent_spaces.touch(ROOT)

def on_interrupted(dlg):
    dialogs.append(dialog_text(dlg))
    return dlg.button(QMessageBox.Yes)

st_modal = arm_modal(on_interrupted, timeout=10.0)
w._open_recent_space(ROOT)
pump(app, 0.5)
done = wait_until(app, lambda: (not w._working and not w._plan_working),
                  120, "recover finished")
pump(app, 0.8)
auto.stop()

b = w._storage.get_batch(BID) if w._storage is not None else None
acts = w._storage.get_actions(BID) if w._storage is not None else []
actions = [{"index": a.action_index, "source_rel": a.source_rel,
            "target_rel": a.target_rel, "status": a.status,
            "error": a.error, "sha": a.source_sha256} for a in acts]
src_rel = actions[0]["source_rel"] if actions else ""
tgt_rel = actions[0]["target_rel"] if actions else ""
src_abs = os.path.join(ROOT, src_rel.replace("/", os.sep)) if src_rel else ""
tgt_abs = os.path.join(ROOT, tgt_rel.replace("/", os.sep)) if tgt_rel else ""
disk = {"source": 0, "target": 0}
for dp, dn, fn in os.walk(ROOT):
    rel = os.path.relpath(dp, ROOT)
    head = rel.split(os.sep)[0]
    if head == ".organizer" or head.startswith(".abx_owned"):
        continue
    if head == "_已整理":
        disk["target"] += len(fn)
    else:
        disk["source"] += len(fn)

payload = {"handled": st_modal.get("handled"), "modal_error": st_modal.get("error"),
           "done": done, "dialogs": dialogs,
           "batch_status": getattr(b, "status", None),
           "batch_summary": getattr(b, "summary", ""),
           "actions": actions,
           "src_exists": os.path.isfile(src_abs) if src_abs else None,
           "tgt_exists": os.path.isfile(tgt_abs) if tgt_abs else None,
           "src_sha": sha256_file(src_abs) if src_abs and os.path.isfile(src_abs) else None,
           "tgt_sha": sha256_file(tgt_abs) if tgt_abs and os.path.isfile(tgt_abs) else None,
           "disk": disk}
with open(OUTJSON, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)
w.close()
pump(app, 0.3)
print("RECOVER_JSON=" + json.dumps(payload, ensure_ascii=False))
sys.exit(0 if (payload["done"] and payload["handled"]) else 1)
