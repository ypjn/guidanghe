
import json, os, sys
sys.path.insert(0, r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码")
os.environ.pop("QT_QPA_PLATFORM", None)
os.environ["ARCHIVEBOX_RECENT_FILE"] = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\launch_20261110_192200_c6ba93\children\run01_recent.json"
os.environ["ARCHIVEBOX_APP_DIR"] = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\launch_20261110_192200_c6ba93\children\run01_appdata"
os.environ["ARCHIVEBOX_SCHEME_DIR"] = r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\launch_20261110_192200_c6ba93\children\run01_appdata\schemes"

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
import main

state = {"visible": False, "closed": False, "threads_running": None,
         "python": sys.version.split()[0]}

app = QApplication(sys.argv)
win = main.MainWindow()
win.show()

def after_visible():
    state["visible"] = win.isVisible()
    win.close()                     # 等同用户正常关闭（最后一个窗口关闭 → 事件循环退出）

QTimer.singleShot(400, after_visible)
code = app.exec()
from PySide6.QtCore import QThread
state["closed"] = not win.isVisible()
state["threads_running"] = [t.objectName() or t.__class__.__name__
                            for t in win.findChildren(QThread) if t.isRunning()]
main.shutdown_widgets()      # 生产入口的显式销毁步骤（在 QApplication 存活时执行）
state["shutdown_done"] = True
with open(r"C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage5_deliver_20261110_191543\runtime\runs\launch_20261110_192200_c6ba93\children\run01.json", "w", encoding="utf-8") as f:
    json.dump(state, f, ensure_ascii=False)
sys.exit(code)
