# 归档盒 V1.7 · Windows 阶段第五轮交付（stage5）

- 交付时间：2026-11-10 19:5x（Asia/Shanghai）
- 源码树：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码`
- 冻结基线：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_baseline_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110`
- 本机环境：Windows 11 家庭版 中文版 build 26200，LongPathsEnabled=1；Python 3.14.7；PySide6 6.12.0
- 技术栈未变：Python + PySide6/Qt Widgets + SQLite；未改产品语义

---

## 0. 结论摘要

| 项 | 结果 |
| --- | --- |
| 证据归集 | 已按**单轮**重新归集：本轮 `20261110_192155_7ac9ee`（19:21:52–19:23:08）；上轮 `20261110_172435_aab5e0`（172431 轮）已在新目录重做索引，旧目录未改 |
| 套件 | 11 个，全部 PASS（supervisor `verdict=PASS`） |
| 检查条目 | 200 PASS + 1 UNTESTED（其中框架自检 8 项；产品项 192 PASS + 1 UNTESTED） |
| 独立功能覆盖 | 见 §9，**不是** 200 个独立功能（桌面链路三套件共享同一功能面） |
| 生产代码修改 | 1 处（本轮新修，由实测反例驱动）：`executor.py` 失败路径残留副本清理 |
| 退出码 | L2（supervisor 直接子进程真实 OS 退出码）=0；L3（包装器准备返回）=0；L4（调用者观察到的壳退出码）=0；无超时，`-999` 本轮出现 0 次 |
| 桌面链路 | 10 个文件 → 整理 7 项 → 撤销后与初始**逐文件（含 SHA-256）一致**；批次 #1 |
| 失败 | 0 |
| 阻塞 | 0 |
| 未测 | 1（`S3_2` 扫描中取消——产品未提供该入口，本轮**不收窄为已验收**） |

---

## 1. 证据归集：本轮与上轮

### 1.1 本轮（stage5）

`evidence_index.json` 是唯一入口，字段说明：

- `authoritative_cycle`：runtime 路径、时间窗、`run_dirs` 10 个、判定依据 5 条
- `excluded_cycle`：同一 runtime 下 19:20:08–19:21:46 的那一次完整周期，10 个 run 目录逐条列出，**不使用**，文件保留未删
- `desktop_run`：`run_id / root / batch_id / 三份清单 / 7 张截图 / stage_diffs / 移动项 7 个 / before==after_undo`
- `process_records`：supervisor、包装器、调用者退出码、stdout/stderr、11 个 `process.json` 的路径+大小+SHA-256
- `suites`：每个套件的脚本、`run_dirs`、起止时间、`exit_code_kind`、`os_exit_code`、自报退出码、结果统计、逐文件哈希

**为什么存在两轮周期**：同一 runtime 目录下跑了两次完整 supervisor。只有后一次被 `process.json`、`outer_powershell_exitcode.json`、`caller_observed_exit.txt` 记录；前一次的 supervisor stdout 已被覆盖（`outer_supervisor.stdout.log` 里 `===== ` 只有 12 次 = 11 套件 + 汇总，属单轮），**无法证明前一次的包装器退出码**，所以本轮所有结论只引用后一次。前一次文件保留，索引里明确标注 `use: 不使用（仅供追溯）`。

### 1.2 上轮（stage4 / 172431）

`evidence_index_20261110_172431.json` + `prev_round_172431\`：

- 旧交付的问题：`report`、截图、`desktop_state`、`stage_diffs` 取自 `runtime_20261110_172314`（run_id `20261110_172318_6f5054`），而 `process.json`、外层记录、stdout 取自 `runtime_20261110_172431`（run_id `20261110_172435_aab5e0`）
- 本轮做法：**在新目录**按 172431/aab5e0 复制截图（7 张 + 撤销后清单）、`01_before` / `02_after_move` 清单、`desktop_state.json`，重新计算 `stage_diffs.json`，并把 9 个套件的 `process.json / results.json / stdout / stderr / children` 复制到 `prev_round_172431\suite_records\`
- 两轮清单的 `items` 相同（只有 `meta.run_id` / `meta.root` 不同），所以旧结论的**数值**没被污染，但**溯源**是错的；现在全部指向 172431/aab5e0
- 旧目录 `windows_stage4_deliver_20261110_172431` 与旧日志**未做任何修改**

上轮桌面链路复核（与该轮原始资料一致）：三阶段各 10 个文件、7 项整理、撤销后逐文件一致，与顾问核对结果相同。

---

## 2. 退出码：四层语义与 `-999`

`exit_code_semantics.json` 记录全部数值（从实际记录生成，非手写）。

| 层 | 含义 | 是否采信 | 本轮值 | 上轮（172431） |
| --- | --- | --- | --- | --- |
| L1 | 套件自己写在 `results.json` 的 `EXIT_CODE` | **否** | 0（11/11） | 0 |
| L2 | supervisor 直接启动子进程后拿到的**真实 OS 退出码** | 是 | **0**（11/11，`exit_code_kind=os_exit_code`） | 0（无 `exit_code_kind` 字段） |
| L3 | PowerShell 包装器内部准备 `exit` 的值 | 否 | **0** | 0 |
| L4 | 调用者实际观察到的壳退出码 | 是 | **0**（`evidence/caller_observed_exit.txt`） | **未采集**（该轮只记了三级，如实标注，不回填） |

`-999` 的准确表述：

- 是**本测试框架的超时哨兵**，不是操作系统退出码；
- `exit_code_kind="timeout_sentinel"`，`os_exit_code="未采集（进程被强制终止）"`；
- 本轮 0 次出现；
- 任何「进程以 -999 退出」的说法都是错的。

**子进程退出码参与父套件判定**（不只检查子进程 JSON）：

| 方式 | 套件 | 位置 |
| --- | --- | --- |
| `Results.check_child_exits()` 聚合全部 `run_child` 记录 | w2_1（`C_EXIT`）、w2_3（`Q_EXIT`）、s5_plan_scope（`S_EXIT`）、s5_names_occupancy（`O_EXIT`） | `windows_harness.py` `CHILD_LOG` + `check_child_exits` |
| 同一聚合 + 唯一豁免 | w2_2（`F_EXIT`，豁免 `f5_interrupt`：受控中断故障注入，预期非零，豁免条件写进用例标题） | 同上 |
| 逐项显式断言 `exit == 0` | protect_paths（`P1_*`–`P2b`）、launch_exit_10x（`L0_1`：10 次启动的 OS 退出码 + 超时） | 各套件自身 |
| 按注入预期判定（不聚合） | harness_selftest：故意让子进程非零/超时，断言父进程能正确识别 | 该套件是框架自检，不是产品验收 |

`check_child_exits` 的两个硬约束：**没有任何非豁免子进程记录也判 FAIL**；**`timed_out` 与 `exit_code != 0` 都判 FAIL**。

---

## 3. 定向补验逐项结果（`s5_plan_scope`：27 PASS + 1 UNTESTED）

全部通过真实控件 + 产品入口驱动；只在后台线程入口注入一个**同步闸门**把「任务运行中」变成可观测点，真实 `scan_directory` / `generate_plan` 仍执行。没有「测试自己 deepcopy 造 PlanWorker 再直接调 generate_plan」，也没有用搜索源码字符串代替行为。

### 3.1 S1 来源范围变化使旧计划失效（6/6 PASS）

| 用例 | 断言 |
| --- | --- |
| S1_1 | 真实「添加文件夹…」控件把来源加入待整理清单（清单 1 项，`w.intake` 长度 1） |
| S1_2 | 旧计划**本来可执行**：扫描后 `rows=1`、`plan_items=1`、`_plan_valid=True`、执行按钮可用 |
| S1_3 | 再次通过同一入口加入第二个来源 → 旧计划立即不可执行：`rows=0`、`plan_items=0`、`plan_valid=False`、执行按钮禁用 |
| S1_4 | 按新范围重新生成：`plan_items=2`、来源 `图片素材/logo.png` + `大二上/数据结构/讲义.pdf`，与新范围一致，可执行 |
| S1_5 | `ExecuteConfirmDialog` 文本去 HTML 后断言：`根目录：…`、`已选文件：2 / 2`、`本次范围：待整理清单：2 项 → 纳入 2 个文件`（随后点取消） |
| S1_6 | 确认界面取消后磁盘**零移动**（清单 diff 为空） |

未使用切根、未改配置，完全走产品的来源范围入口。

### 3.2 S2 真实生产后台配置快照（6/6 PASS）

三个阶段，同一个界面实例，真实计划任务：

| 用例 | 断言 |
| --- | --- |
| S2_1 | 经界面启动的计划任务**确实在运行**（闸门被后台线程命中，`A_gate_entered=True`） |
| S2_2 | 暂停期间改的是**界面配置对象本身**：`w.classification_config` 的学期方向规则实测 `['课程'] → ['项目']` |
| S2_3 | 放行后结果仍按**启动快照**产出：目标为 `_已整理/课程/…`（不是「项目」）→ 证明 `PlanWorker` 启动时 `deepcopy` 生效 |
| S2_4 | 任务进行中经产品入口保存配置 → 任务标识 `seq 2 → 3`，旧结果按现有失效机制作废 |
| S2_5 | 放行后旧任务结果被丢弃：无计划、0 预览行、执行按钮禁用 |
| S2_6 | 重新生成后新配置生效：目标变 `_已整理/项目/…`，且可执行 |

S2_3 与 S2_5 同时成立，说明「快照」与「失效」两个语义**并存而不互相掩盖**。

### 3.3 S3 确定性迟到结果（5 PASS + 1 UNTESTED）

| 用例 | 断言 |
| --- | --- |
| S3_1 | 扫描进行中任务运行态为真；**产品没有提供扫描取消入口**（按钮 `visible=False, enabled=False`） |
| S3_2 | **UNTESTED**：扫描中用户主动取消——产品未提供该入口，本轮不验收；**不以求证式的「执行中取消」替代** |
| S3_3 | 顺序可证：`['A_scan_worker_blocked', 'switched_to_B', 'scan_gate_released', 'late_result_delivered']` —— A 结果确实在切到 B **之后**才送达 |
| S3_4 | A 的迟到结果未污染 B：界面仍是 B、无计划、0 行、来源里没有 A 的文件；状态栏给出「已忽略旧目录的扫描结果」 |
| S3_5 | 迟到结果未移动任何文件（A 目录清单 diff 为空） |
| S3_6 | 切到 B 后可正常扫描并生成有效可执行计划（含 B 的文件） |

**同根目录的配置/范围变化对应场景**：见 S2_4/S2_5/S2_6（保存配置 → `seq` 递增 → 旧结果丢弃 → 重新生成生效）。先复现、未改生产代码：现有 `_current_plan_seq` + `_on_plan_done(seq)` 已足以覆盖，**没有凭推测增加守卫**。

### 3.4 扫描及计划取消（4/4 PASS）

| 用例 | 断言 |
| --- | --- |
| S4_1 | 计划生成中取消按钮可见可用；点击后 `cancel_seq == cur_seq`、`requested=True`、状态「正在取消计划生成…」，按钮随后禁用 |
| S4_2 | 取消后**不发布可执行半成品**：无计划、0 行、执行按钮禁用、失效提示可见 |
| S4_3 | 取消**不移动文件、不写批次历史**：`batches=0`、`pending=None` |
| S4_4 | 取消后可重新生成有效计划（3 项）并恢复可执行 |

扫描取消单独记为 UNTESTED（S3_2），**未用执行中取消替代**。

### 3.5 生命周期证据（5/5 PASS）——不再把「实例隔离」说成「完整生命周期验收」

观测手段：patch `sqlite3.connect` 注入 `LoggedConn` 子类，记录 `id(conn)`、`threading.get_ident()`、线程名、connect/close 时间戳。

| 用例 | 实测 |
| --- | --- |
| S5_1 | 连接身份与创建线程：主线程 1 个连接（`MainThread`），后台 2 个连接（`Dummy-1` / `Dummy-2`），指向同一 `history.db` 但为不同实例 |
| S5_2 | 执行线程的连接在该线程内关闭：`conn_close` 发生于 `t=3375925.81`（`Dummy-1`），主线程观察到 `exec_thread_finished` 在 `t=3375926.48` → **关闭早于 finished 被观察** |
| S5_3 | `opened=3 closed=3 missing=[]`：所有打开过的连接都关闭，窗口关闭后主连接为 `None` 语义 |
| S5_4 | 关闭顺序：最后一次 `conn_close` 在 `t=3375927.245`，窗口 `closeEvent` 返回在 `t=3375928.062` → **工作线程连接全部关闭早于窗口真正关闭返回** |
| S5_5 | 生产界面闭环：扫描 → 确认执行（成功 2，批次 #1）→ 从界面撤销（恢复 2 项），状态栏均有结果 |

结论表述已收窄并升级为实测：**实例隔离**（已有）+ **连接身份/创建线程**（S5_1）+ **关闭与 finished 的先后**（S5_2）+ **关闭与窗口关闭返回的先后**（S5_4）+ **无遗留连接**（S5_3）。不再以「无异常」等同于「生命周期已验证」。

---

## 4. Windows 名称与路径边界（`s5_names_occupancy` 的 N 段：19 PASS）

独立合成目录，不触碰真实资料。

| 组 | 覆盖 | 关键断言 |
| --- | --- | --- |
| N1 | 中文 + 空格 | 目标 `_已整理/未分类课程/文档/我的 讲义.pdf` 保留原名；`moved=1`，磁盘命中、SHA 一致、源已不存在；不写出根目录 |
| N2 | 计划内同名目标碰撞 | 分配 `讲义.pdf` 与 `讲义 (1).pdf`；两份不同内容都在，未互相覆盖 |
| N3 | 磁盘已存在同名目标 | 先探针拿到真实目标路径并预置 `OLD-KEEP` → 计划改用 `(1)` 并标 `conflict_with_existing`；执行后旧文件 SHA 未变 |
| N4 | 大小写差异 | 计划给出 `report.pdf` 与 `RePort.pdf` 两个目标；Windows 大小写不敏感 → 实际只落一份，另一份跳过且 `skipped_error='目标路径已被占用'`，**不覆盖、不丢内容、不记成功** |
| N5 | Windows 保留名称 | N5_1 实测 `CON.txt` **在本机可以创建**（`created=True`），与 Microsoft 文档「保留设备名」不一致，已按本机实测记录并注明「不同版本可能不同」；N5_2 用**双分支**断言历史与磁盘一致（`failed⇒源在目标不在` 或 `moved⇒目标在源不在`），不允许「失败记成功」或源/目标双丢；N5_3 根目录条目仅 `.organizer / _已整理 / 大二上`，未在根外写出 |
| N6 | 非法字符 / 尾随点 / 尾随空白 / `..` | 课程名 `高数:实验?*"x\|` → 目标目录 `_已整理/高数_实验___x_/文档/…`，真实创建并移动成功（`moved=1`）；课程名 `高数.` → 目标目录 `_已整理/高数/文档/…`，尾随点被去掉且可创建；课程名 `..` 不会写出整理根目录（目标仍在 `_已整理/` 下，`commonpath` 校验通过） |

**输入验证层 vs 真实磁盘行为**（刻意区分）：

- N6_3 断言的是**配置层校验**：`学期标签` 尾随空白被拒（`首尾不能有空白（当前：'测试来源Z '）`）；而**尾随点与保留名在配置层未被拒绝**——这两类只能在计划/执行层清理，已记为**已知限制**，不是缺陷掩盖
- N6_1b / N6_2 才断言真实磁盘创建与移动
- N5_1 是真实磁盘行为实测，不是规则推断

### 平台规则来源（文档 vs 实测）

- Microsoft Learn, *Naming Files, Paths, and Namespaces*（本轮已取原文核对）：
  - 保留名 `CON, PRN, AUX, NUL, COM1–COM9, LPT1–LPT9`（含 `¹²³` 变体），且「这些名字后紧跟扩展名同样保留」（`NUL.txt`）
  - 「**不要**以空格或句点结尾」
  - 「不要假设大小写敏感（OSCAR/Oscar/oscar 视为同一）」
  - 非法字符 `< > : " / \ | ? *`
  - URL: https://learn.microsoft.com/en-us/windows/win32/fileio/naming-a-file
- **本机实测与文档的差异**：文档说保留名不可用，但本机 Windows 11 build 26200 上 `CON.txt` 可创建；`CON` 作为**目录名**时，本机执行结果为 `moved`（未报错）。结论只对本机成立，报告与用例里都写了这一限定。
- Windows 共享模式（`CreateFileW` 的 `dwShareMode` 不含 `FILE_SHARE_DELETE` ⇒ 改名/删除被拒）的行为**以本机探测为准**（O1_2 得到 `WinError 32`），未把文档条款当作验收依据。

---

## 5. 文件占用（O 段：10 PASS）

做法：测试专属子进程用 ctypes `CreateFileW` 以 `GENERIC_READ` + `FILE_SHARE_READ|FILE_SHARE_WRITE`（**不含** `FILE_SHARE_DELETE`）打开文件，并写 `occ_ready.json` 回执；父进程**先用改名探测（`.__probe`）证明占用已建立**，再执行整理。

| 用例 | 断言 |
| --- | --- |
| O1_1 | 持有进程回报 `handle_ok=true`、`share_mode=FILE_SHARE_READ\|FILE_SHARE_WRITE (无 FILE_SHARE_DELETE)`、`get_last_error=0` |
| O1_2 | 父进程改名探测 **失败**（`WinError 32 另一个程序正在使用此文件`）→ 占用客观成立，不是「声称已占用」 |
| O2_1 | 占用中执行：未占用项成功 1、占用项失败 1；失败**未记成成功** |
| O2_2 | 失败项历史错误串给出原因，并带「已清理本次失败留下的目标副本」 |
| O2_3 | 失败项：**源仍在原位、目标路径不存在**（失败 = 源在、目标不在） |
| O3_1 | 释放信号后持有进程正常退出 `exit=0`（无超时） |
| O4_1 | 释放后按产品流程撤销该批次：恢复 1 项，清单与初始一致（`diff={}`） |
| O5_1 | 释放后完整流程：两项都移动成功 |
| O5_2 | 撤销后**完整文件清单（含大小与 SHA-256）**与初始完全一致 |
| O6_1 | 只读属性单独记录：`moved=1, failed=0`（Windows 同卷 `os.rename` 不受只读属性限制）——**不把只读属性当作写权限/ACL 测试** |

---

## 6. 生产代码修改

### 6.1 本轮唯一新修改：`executor.py` 失败路径残留副本清理

**实测反例（修复前）**：源文件被占用时，`os.rename` 抛 `OSError` → 进入 `shutil.move` 兜底 → `copy2` **成功**、`unlink` **失败** → 历史记为 `failed`，但磁盘上多出一份目标副本；撤销只处理 `moved/conflict`，这份副本永远留在 `_已整理` 里。修复前日志（`prefix_logs/s5ab_prefix_fail_191251/results.json`）：

- `O2_3` FAIL：失败项目标路径存在（残留副本）
- `O4_1` FAIL：撤销后清单与初始不一致
- `O5_2` FAIL：最终完整清单不一致
- 另有 `N1_2 / N4_2 / N5_2` 的断言表述问题（测试侧，非产品）

**修复**（`归档盒源码/executor.py`，第二个 `except OSError as e2` 分支）：

```python
except OSError as e2:
    stray_removed = False
    try:
        if (os.path.isfile(src_path) and os.path.isfile(target_path)
                and sha256_file(src_path) == sha256_file(target_path)):
            os.remove(target_path)
            stray_removed = True
    except OSError:
        pass
    note = "（已清理本次失败留下的目标副本）" if stray_removed else ""
    storage.update_action(result.batch_id, idx, STATUS_FAILED,
                          error=f"移动失败：{e2}{note}")
```

约束：只在「源仍存在 + 目标存在 + 两者 SHA-256 相同」时删除，保证「失败 = 源在、目标不在」，不会误删用户既有文件；`failed` 语义、错误串、撤销逻辑都不变。

**修复后验证**：`prefix_logs/s5ab_after_fix_191341/results.json` 29/29 PASS（同一批用例），随后全量 supervisor 复跑仍 PASS。

### 6.2 其他生产文件（上轮引入，本轮未改，仅纳入补丁与哈希）

| 文件 | 变化 |
| --- | --- |
| `main.py` | 历史按钮刷新（选目录后刷新历史可用态）；迟到扫描结果守卫（`_on_scan_done` 比对 `current_root` 与 `result.root`，不一致则「已忽略旧目录的扫描结果」） |
| `protect_config.py` | 相对路径与 `~/` 路径规范化 |
| `_windows_paths.py` | 新增（路径/名称辅助，测试与产品共用） |

---

## 7. 状态清单（明确区分）

### 已验收（本轮实测通过）

- 证据归集：本轮单轮溯源、上轮 172431 重新归集
- 四层退出码与 `-999` 语义；子进程退出码参与父套件判定
- S1 范围变化使旧计划失效；S2 启动快照 + 失效机制；S3 确定性迟到结果（除 S3_2）；S4 计划取消；S5 连接身份/线程/关闭顺序
- N1–N6 名称与路径边界；O1–O6 文件占用与只读属性观察
- 桌面链路三阶段 10/10/10 文件、7 项整理、撤销后一致（本轮 192155_7ac9ee 与上轮 172435_aab5e0 各自独立成立）
- 历史与磁盘一致性（占用失败项、撤销后完整清单）

### 失败

- 无（本轮所有套件 `verdict=PASS`，`FAIL=0`）

### 阻塞

- 无

### 未测（如实标注，不算通过）

| 项 | 原因 |
| --- | --- |
| `S3_2` 扫描中用户主动取消 | 产品 `_update_button_states` 在扫描期不显示/不启用取消按钮，没有该入口；**未用执行中取消替代** |
| 配置层对 Windows 保留名 / 尾随点的拒绝 | 配置层 `_check_component` 只拒绝分隔符/首尾空白/`.`/`..`/`~`/绝对路径/盘符/`\x00`，不拒绝保留名与 `< > : " \| ? *`；只能在计划层 `_sanitize_component` 清理（N6_3 已记录为已知限制） |
| 跨盘移动 | 本轮不安排（见 §8） |
| ACL 完整恢复、链接、DPI、多显示器、十万文件压力、安装包 | 本轮不安排 |
| 真人试用 | 与程序化桌面检查分开，不在本报告结论内 |

---

## 8. 已知限制与平台差异

1. **大小写碰撞**：计划层会给出 `report.pdf` / `RePort.pdf` 两个目标名，Windows 上实际只能落一份；产品行为是「第二份跳过 + 如实提示目标被占用」，**不覆盖、不丢内容、不记成功**。计划预览仍显示两个不同目标名（已知显示层限制）。
2. **保留名平台差异**：本机 `CON.txt` 可创建、`CON` 目录可用；文档说不可用。测试用双分支断言保证两种平台上「历史与磁盘一致」，不把某一平台结论当通用结论。
3. **无扫描取消入口**：扫描期没有取消按钮，扫描是短任务；本轮只验收「计划取消」，扫描取消记 UNTESTED。
4. **只读属性 ≠ 权限**：同卷 `os.rename` 不受只读属性限制，O6 只记录属性观察，不作为 ACL/写权限证据。
5. **`supervisor.json` 顶层 `start_utc`**：写在汇总阶段，等于结束时刻；真实时间以套件级 `start_utc/end_utc` 与包装器记录为准（索引里已注明，未改旧文件）。
6. **`outer_powershell_exitcode.json` 带 UTF-8 BOM**（PowerShell 默认输出）；原始文件保持原样，读取方需 `utf-8-sig`。

---

## 9. 检查条目数 ≠ 独立功能覆盖数

- 200 PASS 里，`desktop_part1`（21）+ `desktop_part2`（18）+ `w2_1`（21）大量重复覆盖**同一条桌面链路**（扫描→计划→确认→执行→历史→撤销），只是观测点不同；
- `patch_verify`（10）、`harness_selftest`（8）是**框架/补丁自检**，不是产品功能；
- 独立的**功能面**大致为：扫描与保护、计划生成与快照、范围失效、迟到结果、计划取消、执行与占用、撤销、恢复、历史与导出、配置隔离、连接生命周期、名称与路径边界、启动/退出生命周期 —— 约 **13 个功能面**，由 11 个套件从不同角度覆盖。
- 因此不要把 200 当作「200 个独立功能已验证」；§7 的清单是按**功能面**列的。

已通过且本轮未受影响的套件（`patch_verify`、`protect_paths`、`desktop_*`、`launch_exit_10x`、`w2_*`）**引用原证据**，未为归集问题重跑九套。

---

## 10. 交付目录结构与文件

```
windows_stage5_deliver_20261110_191543\
  evidence_index.json                     本轮单轮来源索引（含排除周期说明）
  evidence_index_20261110_172431.json     上轮 172431/aab5e0 重新归集索引
  exit_code_semantics.json                四层退出码 + -999 + 子进程聚合规则
  report.md                               本文件
  CHANGES_vs_previous.md                  相对上轮的修改与差异
  MAC_REVERIFY.md                         Mac 复验清单
  FILES.sha256.txt                        本目录完整文件清单与哈希
  evidence\                               11 套件原始记录 + supervisor.json + 双层退出码文件 + stdout/stderr
  screenshots\                            本轮 7 张 Windows 截图（*_20261110_192155_7ac9ee.png）
  manifests\                              本轮 01_before / 02_after_move / 05_after_undo / desktop_state / stage_diffs
  prefix_logs\                            修复前 FAIL 与修复后 PASS 的对照日志（4 组）
  patches\                                stage5_windows_source.patch + .stat.txt + apply_check.log
  source_snapshot\                        SHA256SUMS.txt + changed_files\ + changed_files.json
  prev_round_172431\                      上一轮按 172431/aab5e0 重新归集的截图/清单/套件记录
  runtime\                                本轮原始 runtime（含被排除周期的文件，保留未删）
```

补丁应用与校验：`patches/apply_check.log`

- `git apply --check -p1` exit=0
- `git apply -p1` exit=0
- 应用后与最终源码逐文件比对：72 个文件，**0 处不一致**
- 生成方式：冻结基线工作副本 → 提交 → 覆盖最终源码 → `git diff --cached --binary`（`core.autocrlf=false`），路径为相对 `ArchiveBox_V1.7_Windows_Handoff_20261110` 的 `a/归档盒源码/...`
- 补丁不含 `__pycache__`、`tests/_abx_selftest`（测试运行产物）与 `.abx_owned_*`

---

## 11. Mac 复验清单

见 `MAC_REVERIFY.md`（含 `protect_config` 相对路径与 `~/` 路径、`main.py` 历史按钮刷新、迟到扫描结果守卫、本轮 `executor.py` 副本清理修复）。

## 12. 程序化桌面检查 vs 真人试用

- 本报告所有桌面结论来自 `QTest` 驱动的真实控件 + 显式应答模态对话框（`arm_modal` 捕获 class/text），属**程序化桌面检查**；
- **真人试用**（真实鼠标操作、真实文件夹、真实心理预期）未在本轮进行，也不在本报告结论内；
- 两者不能互相替代，顾问审阅时请按此边界引用。
