# Mac 复验清单（stage5 后的必测项）

本文件只列**需要 Mac 再验**的项。Windows 专属套件（`tests/windows_*.py`、`run_stage5.ps1`）不能在 macOS 上运行，也不要求移植；它们证明的是 Windows 平台语义。

## 0. 准备

```bash
cd <handoff>/归档盒源码
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt      # 或按 版本与依赖.txt
```

补丁应用（如需从冻结基线重建）：

```bash
git apply -p1 --check ../patches/stage5_windows_source.patch   # 在 handoff 根目录执行
git apply -p1 ../patches/stage5_windows_source.patch
```

## 1. 既有回归（先跑，确认没有连带破坏）

```bash
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v17_daily_entry.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v17_combined.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v16_scheme_preview.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v15_long_term_rules.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v14_single_file.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v13_config.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v12_history_task.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v11_ui_state.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v11_e2e.py
QT_QPA_PLATFORM=offscreen .venv/bin/python tests/test_v10_regression.py
```

期望：全部退出码 0（每套件自身 `EXIT_CODE` 仅作参考，以进程退出码为准）。

## 2. 本轮新增生产修改：`executor.py` 失败路径残留副本清理

等价场景（macOS 上不必用 Windows 共享锁）：

1. 造 `A/讲义.pdf`，让 `os.rename` 失败（例如目标目录只读 / 目标被同名目录占位），使代码走 `shutil.move` 兜底；
2. 用 `chmod 000` 或只读挂载让 `unlink` 失败，制造「`copy2` 成功、`unlink` 失败」；
3. 期望：历史记为 `failed`，错误串含「已清理本次失败留下的目标副本」，**目标位置不残留副本**，源文件仍在；
4. 撤销后完整清单（含 SHA-256）与初始一致。

注意 macOS 与 Windows 的差异：POSIX `rename` 会**覆盖**已存在的目标，所以「目标已存在」在 macOS 上不会触发 `os.rename` 的 `FileExistsError`；本项只验「失败后不留副本」这一条不变量。

## 3. `protect_config`：相对路径与 `~/` 路径

1. 在配置里把保护路径写成相对路径（如 `../资料`）与 `~/Documents/资料`；
2. 期望：两者都被规范化为绝对路径后参与保护，扫描/计划里对应目录被排除；
3. 不存在的路径只标记、不创建；
4. 手工保护清单保存后重启仍在。

## 4. `main.py` 历史按钮刷新

1. 启动 → 选一个有历史批次的目录；
2. 期望：历史页「撤销」按钮在选目录后**立即刷新**为可用（不需要先切页或重启）；
3. 执行一次整理后再看历史页，撤销按钮仍可用；撤销完成后按钮变为不可用。

## 5. 迟到扫描结果守卫

1. 大目录 A 扫描启动后立即切到目录 B（可用挂载慢速网络盘或加一个临时 `time.sleep` 的 monkeypatch 放大时间窗）；
2. 期望：A 的扫描结果到达时被丢弃，状态栏提示「已忽略旧目录的扫描结果：…」；界面仍是 B、无预览行、执行按钮禁用；
3. 不能出现「B 的界面里出现 A 的文件」。

## 6. 迟到计划结果 / 配置快照（本轮在 Windows 已验，Mac 抽验）

1. 计划生成中点「取消」→ 无半成品计划、无批次历史、可重新生成；
2. 计划生成中修改配置并保存 → 旧任务结果被丢弃（`seq` 递增），重新生成后按新配置产出；
3. 计划生成过程中修改界面配置对象但不保存 → 结果仍按启动快照（旧配置）产出。

## 7. 平台差异（不要把 Windows 结论搬到 Mac）

| 项 | Windows（本轮已验） | macOS |
| --- | --- | --- |
| 目标已存在 | `os.rename` 抛 `FileExistsError` → 跳过并提示「目标路径已被占用」 | `rename` 会覆盖；产品的「目标已存在」判断依赖执行前的 `os.path.exists` 检查，需复验不覆盖 |
| 保留名 | `CON.txt` 本机可创建（与文档冲突） | 无此概念；不要复用该结论 |
| 大小写 | 不敏感（`report.pdf` / `RePort.pdf` 视为同一） | APFS 默认不敏感，但区分大小写的卷存在；需在两种卷上各抽验一次 |
| 文件占用 | 共享模式违规 → `WinError 32` | POSIX 无强制共享锁；`flock` 不阻止 `rename`，占用场景不成立 |
| 只读属性 | 同卷 `rename` 不受只读限制 | 目录写权限决定，`chmod` 语义不同 |

## 8. 记录要求

- 每项记录：命令、进程退出码、结果、截图（`QT_QPA_PLATFORM=offscreen` 时改用 `grab()` 保存 PNG）；
- 失败项保留修复前日志，修复后复跑原反例 + 直接相关回归；
- 真人试用与程序化检查分开记录，不互相替代。
