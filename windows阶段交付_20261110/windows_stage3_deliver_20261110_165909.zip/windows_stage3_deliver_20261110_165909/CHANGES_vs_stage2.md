# 相对上一轮（`windows_stage2_deliver_20261110_153858`）的修改说明

对照口径：本轮 `source_snapshot/` 与上一轮 `source_snapshot/` 逐文件 SHA-256 比对。

## 一、生产代码：2 个文件 / 3 处修复

| # | 文件 | 位置 | 修改 | 为什么 |
|---|---|---|---|---|
| P01 | `protect_config.py` | `normalize_manual_path` | 恢复 `os.path.expanduser`，并改为「先展开 `~` → 再判绝对/相对 → 相对路径相对整理 root 拼接」 | 上一轮为修 cwd≠root 的相对路径，把 `expanduser` 一起删了，导致基线接受的 `~/project/keep` 在新版失败（顾问问题 2）。两件事必须同时成立。 |
| P02-a | `main.py` | `_reset_for_new_dir` 末尾 | 补 `self._update_button_states()` | 打开已有根目录时历史库已就绪，但「操作历史」按钮此前要等扫描后才可用。PART2 Q4 真跑时失败暴露。 |
| P02-b | `main.py` | `_on_scan_done` 开头 | 增加根目录守卫：`path_edit` 的当前根与 `result.root` 不一致时丢弃结果并提示 | 扫描期间切换根目录后，旧目录的迟到扫描结果会覆盖新目录界面并据此生成计划。W2-3 Q6 真跑时复现，属本轮新发现的生产缺陷。 |

最终哈希：

```
e3831b751cece9601ea6ad01baefdfaa55f3e2caeb893b3459aa38dcecc8af46  protect_config.py
dffd2de72200a8d6899d7e4beb6858cad97917348bf35cc8237900dcdea816f4  main.py
```

上一轮为：

```
f20e5153d28c0230…  protect_config.py   （changed_lines=7）
b48a66db47e40c12…  main.py             （changed_lines=11）
```

其余生产文件（`executor.py` / `storage.py` / `scanner.py` / `planner.py` / `classification_config.py` 等）**逐字节未变**。

## 二、补丁

| 上一轮 | 本轮 |
|---|---|
| `P01_protect_config_relative_path.patch`，`git apply` 实测 `corrupt patch at line 5`（顾问问题 3） | `P01_protect_config_expanduser.patch`、`P02_main_interaction_fixes.patch`，均由「冻结基线 + 最终源码」经 `difflib.unified_diff` 重新生成，按目标文件 EOL 拼接，逐行合法性检查通过；在独立基线副本上 `apply --check` / `apply` 均 exit=0，应用结果 SHA-256 与最终源码一致 |

补丁生成与验证是**自动化套件**（`tests/windows_patch_verify.py`），不是手工操作：命令、cwd、stdout/stderr、退出码全部落 `patches/patch_verify.json`。

## 三、测试框架（新增 5 个、重写 6 个）

新增：

| 文件 | 作用 |
|---|---|
| `tests/windows_harness.py` | 公共框架：`RunDir`（唯一目录 + `.abx_owned_<run_id>` 所有权标记）、`safe_rmtree`（commonpath + 标记双校验）、`Results`（`rec/check/finalize`，按真实条目汇总退出码并打印 `EXIT_CODE=`）、逐文件清单与 diff、`run_child`（记录 cmd/cwd/env/起止/退出码/超时/stdout/stderr） |
| `tests/windows_supervisor.py` | 外层监督：9 个套件逐个子进程执行，统一 `judge()` 判定，机器生成 `supervisor.json` |
| `tests/windows_harness_selftest.py` | 8 项失败注入自检（H1–H8），证明判定器能识破假成功且不恒定失败 |
| `tests/windows_patch_verify.py` | 补丁生成 + 副本应用 + 逐字节比对 + 冻结基线哈希复检 |
| `tests/windows_protect_paths.py` | 16 项 `normalize_manual_path` 路径矩阵，同时只读导入冻结基线做对照（保留修复前反例 P6） |

重写：

| 文件 | 主要变化 |
|---|---|
| `windows_desktop_full.py` | 改为真实控件交互（`QTest.mouseClick`）+ 真实模态框应答；读取并断言确认框的根目录/模式/全部选择统计；独立逐项目标表；删除无条件 PASS 与宽泛关键词断言；写 `desktop_state.json` 交接 |
| `windows_desktop_full_part2.py` | 必须找到 PART1 同一 `batch_id`，找不到或已撤销即 FAIL（移除「重新扫描补造批次」路径）；从历史表格真实点击该批次并撤销；3 个核对器反例（多出/隐藏内容变化/缺失）；截图关联同一 `run_id` |
| `windows_launch_exit_10x.py` | 复刻生产入口序列 `QApplication → MainWindow → show → app.exec() → shutdown_widgets() → sys.exit()`，10 次独立子进程；先取状态再销毁，避免已删除 C++ 对象 |
| `windows_w2_1_cancel_close.py` | 用 `os.rename` patch + `threading.Event` 测试专属同步点替代 200 文件轮询；断言 `0<moved<total`；撤销要求 `restored>0`；关闭等待断言对象/连接存活、禁止新任务、线程独立 SQLite 连接、新进程无锁；加 trace 落盘 + 硬看门狗 |
| `windows_w2_2_recovery.py` | 覆盖 executing 的 4 种记账窗口（planned 源在 / 已移未落库 / 双份共存 / 双空），全部走新进程真实恢复入口；新增 F5 受控硬中断（`os._exit(7)`，故障注入单列） |
| `windows_w2_3_config_isolation.py` | A/B 同名同层级 + 明确可命中规则；手动保护真实生效（用「高等数学」全名）；临时修正 > 长期规则 > 推荐映射；配置变更/切根后旧计划失效（含对照项）；启动快照；迟到结果丢弃 |

## 四、快照范围说明

- 上一轮 `source_snapshot/tests/` 收录了整个 tests 目录（含 17 个历史遗留脚本）。
- 本轮 `source_snapshot/tests/` **只收录本轮跑到的 11 个脚本**（`windows_*.py`），并在 `reproduce/tests/` 同名提供一份，便于独立复现。历史遗留脚本仍在源码树中未删除、未修改。

## 五、明确没有改的东西

- 未新增任何产品功能、未扩大 W2 范围、未做安装包、未跑全量规模。
- 未修改 `executor.py` 的恢复/撤销业务语义（`recover_batch` A/B/C/D/E/F 分支保持原样）；W2-1/W2-2 的同步点只存在于测试子进程内的 patch，生产代码没有测试钩子。
- 未修改上一轮交付目录、旧的 `windows_stage2_evidence`、源码快照、顾问证据目录。
