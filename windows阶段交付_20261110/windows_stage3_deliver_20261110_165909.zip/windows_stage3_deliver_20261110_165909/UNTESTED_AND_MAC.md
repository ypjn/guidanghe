# 未测项 与 Mac 复验清单

## 一、本轮未测（不要据本报告推断其可用）

| 类别 | 项目 | 说明 |
|---|---|---|
| 规模 | 全量规模验收（`acceptance_v17_scale.py` 级） | 本轮按要求只复跑修正后的相关套件 |
| 打包 | 安装包（PyInstaller / Nuitka） | 未构建、未在干净机安装验证 |
| 路径 | 长路径 > 260 字符 | 未构造超长路径 |
| 路径 | 跨盘移动（如 D: → C:） | 未测（`os.rename` 跨盘会失败，属已知风险，未在 Windows 实测） |
| 文件系统 | NTFS 权限 / ACL 拒绝 | 未构造无权限目标 |
| 文件系统 | 符号链接 / 硬链接 / 目录联接 | 未测（链接保护逻辑本轮未改动，也未新增验证） |
| 界面 | DPI 缩放（125%/150%） | 未测 |
| 界面 | 多显示器坐标一致性 | 仅确认 `QScreen` 有 2 块屏，未测 UI 定位 |
| 界面 | 真人手工试用 | 本报告全部为程序化检查；主观体验、非常规操作路径未覆盖 |
| 并发 | 多进程同时操作同一根目录 | 未测（SQLite 单文件并发写） |
| 恢复 | `partial` / `recovered_partial` 批次的二次恢复 | 只覆盖一次进入恢复；重复进入恢复未测 |
| 网络/同步 | 云盘（OneDrive/坚果云）占用文件 | 未测 |

## 二、已识别但**未**推测性修改的问题

1. **`normalize_manual_path` 大小写边界**（Windows）
   现有实现用 `os.path.abspath` + `startswith(root_abs + os.sep)` 判定根边界，区分大小写。Windows/NTFS 路径不区分大小写，因此理论上 `Root\Sub` 与 `root\sub` 等价，但当前比较可能判为越界。
   本轮**保持原有行为不变**（未新增规范化、未改比较方式），以免在无证据情况下扩大改动。该项列为待评估，不是已修复项。
2. **跨盘移动**：执行端使用 `os.rename` 语义，跨卷会失败。本轮未改实现，也未验证失败后的批次状态与提示。

## 三、Mac 复验清单

在 macOS 上复跑以下项，并特别覆盖**相对路径**与 **`~/` 路径**两条线（不再写「理论无副作用」）：

### 3.1 路径解析（`protect_config.normalize_manual_path`）
- [ ] `~/project/keep`（HOME 在 root 内）→ 接受，且指向 `$HOME/project/keep`
- [ ] `~/project/keep`（HOME 在 root 外）→ 拒绝（根边界不放宽）
- [ ] cwd ≠ root 时的相对路径 `keep` → 解析到 `<root>/keep`（不依赖 cwd）
- [ ] 绝对路径 → 接受；根目录自身 → 拒绝；`../` 越界 → 拒绝；不存在目录 → 拒绝
- [ ] `.organizer` 等程序产物目录 → 拒绝
- [ ] 同一目录两种写法（`sub/x`、`sub/./x`）→ 去重为 1
- [ ] 大小写：macOS 默认 APFS 不区分大小写（除非区分大小写卷），记录 `startswith` 边界在 mac 的实际表现
- [ ] 中文与含空格路径

### 3.2 桌面闭环
- [ ] PART1/PART2 在 mac 原生平台（无 `QT_QPA_PLATFORM=offscreen`）下真实控件点击跑通
- [ ] 重启后从历史界面撤销同一 `batch_id`，逐文件清单（含隐藏文件）哈希一致
- [ ] `~/` 形式作为根目录来源时，最近空间与配置读写位置正确

### 3.3 取消 / 关闭 / 恢复
- [ ] 同步点在 mac 上同样命中 `0<moved<total`
- [ ] 关闭等待期间数据库对象存活、线程各自独立连接、关闭后新进程可读历史且无锁
- [ ] executing 的 4 种记账窗口 + 受控中断（`os._exit` 版本）在 mac 复跑

### 3.4 补丁
- [ ] `P01` / `P02` 在 mac 上 `git apply --check` 通过（注意 `core.autocrlf`；mac 侧文件为 LF，若基线为 CRLF 需先确认换行策略）
- [ ] 应用结果与最终源码逐字节一致

### 3.5 平台差异项
- [ ] 最近空间 / 配置目录的 mac 路径（`~/Library/Application Support/...`）与 Windows 的映射是否一致
- [ ] `ARCHIVEBOX_RECENT_FILE` / `ARCHIVEBOX_APP_DIR` / `ARCHIVEBOX_SCHEME_DIR` 三个隔离变量在 mac 上是否同样生效
