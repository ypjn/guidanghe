# 复现说明（脚本 / 解释器 / 命令）

## 一、环境

| 项 | 值 |
|---|---|
| OS | Windows 11 x64（本次实际环境） |
| Python | 3.14.7（venv） |
| PySide6 | 6.12.0（Qt 6.12） |
| PowerShell | 5.1.26100.7705 |
| git | 用于补丁验证（`apply --check` / `apply`） |

解释器绝对路径（本次实际使用）：

```
C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\.venv\Scripts\python.exe
```

> 所有子进程都通过 `sys.executable` 启动，不依赖源码目录的父层级；解释器可用 `--py` 方式替换，只需保证该解释器有 PySide6。

## 二、目录约定

测试脚本按「`tests/` 与源码同级」推导路径（`SRC = dirname(TESTS)`）。因此复现时：

```
<任意工作根>/
├── 归档盒源码/            # 用本交付 source_snapshot/ 的内容还原（*.py + requirements.txt）
│   └── tests/             # 放本交付 reproduce/tests/ 下的 11 个脚本
└── archivebox_v17_baseline_20261110/
    └── ArchiveBox_V1.7_Windows_Handoff_20261110/
        └── 归档盒源码/     # 冻结基线（仅 patch_verify / protect_paths 需要，只读）
```

`patch_verify` 与 `protect_paths` 通过环境变量定位冻结基线，默认值按上面的相对关系推导：

```
ARCHIVEBOX_BASELINE_SRC=<…>/archivebox_v17_baseline_20261110/ArchiveBox_V1.7_Windows_Handoff_20261110/归档盒源码
```

## 三、一键复跑全部套件（推荐）

```powershell
& <交付目录>\reproduce\run_stage3.ps1 -Deliver <新交付目录>
```

该脚本会：

1. 新建本轮唯一目录 `<工作根>\windows_stage3_deliver_<stamp>` 与 `<工作根>\windows_stage3_runtime_<stamp>`；
2. 用 `Start-Process -PassThru -Wait` 启动 `tests/windows_supervisor.py`（记录真实退出码）；
3. 把完整 stdout/stderr 分别写 `evidence/outer_supervisor.stdout.log` / `.stderr.log`；
4. 写 `evidence/outer_powershell_exitcode.json`（命令、argv、cwd、解释器版本、隔离变量、起止时间、三级退出码）；
5. `exit` 自己的退出码（0 仅当子进程 0 且 `supervisor.json` 的 `verdict == PASS`）。

`run_stage3.ps1` 内不使用任何非 ASCII 字面量，「未采集」用 `[char]0x672A/0x91C7` 构造，因此在 Windows PowerShell 5.1 下无需 BOM 也能正确执行。

## 四、分层复跑（排查用）

```powershell
$py  = "<venv>\Scripts\python.exe"
$src = "<…>\归档盒源码"
$env:ARCHIVEBOX_TEST_BASE = "<工作根>\windows_stage3_runtime_<stamp>"
Remove-Item Env:\QT_QPA_PLATFORM -ErrorAction SilentlyContinue

# 单套件
& $py "$src\tests\windows_w2_2_recovery.py"

# 指定若干套件（由监督进程统一判定）
& $py "$src\tests\windows_supervisor.py" --out "<证据目录>" --base "<runtime>" --only patch_verify,protect_paths
```

单套件的结构化结果写 `ARCHIVEBOX_RESULTS_DIR`（默认 `<BASE>/results`）下的 `results.json`；退出码由 `Results.finalize()` 按真实条目汇总。

## 五、套件与依赖关系

| 顺序 | 套件 | 时长参考 | 依赖 |
|---|---|---|---|
| 1 | `windows_patch_verify.py` | <1s | 冻结基线、git |
| 2 | `windows_protect_paths.py` | <1s | 冻结基线（只读对照） |
| 3 | `windows_harness_selftest.py` | ~3s | 无（自造故障子进程） |
| 4 | `windows_desktop_full.py` | ~3s | 真实 Windows 平台、PySide6 |
| 5 | `windows_desktop_full_part2.py` | ~3s | **必须在 4 之后**（读 `desktop_state.json`） |
| 6 | `windows_launch_exit_10x.py` | ~12s | PySide6（10 次独立进程） |
| 7 | `windows_w2_1_cancel_close.py` | ~7s | PySide6 |
| 8 | `windows_w2_2_recovery.py` | ~14s | PySide6（含受控中断子进程） |
| 9 | `windows_w2_3_config_isolation.py` | ~16s | PySide6 |

第 4、5 必须共用一个 `ARCHIVEBOX_TEST_BASE`——`windows_supervisor.py` 默认对全部套件传入同一个 `--base`，单跑时请自行保证一致。

## 六、关键环境变量

| 变量 | 作用 |
|---|---|
| `ARCHIVEBOX_TEST_BASE` | 本轮唯一运行根（所有隔离目录在其下） |
| `ARCHIVEBOX_RESULTS_DIR` | `results.json` 落盘位置 |
| `ARCHIVEBOX_EVIDENCE` | 监督进程传给套件的证据目录提示 |
| `ARCHIVEBOX_RECENT_FILE` | 覆盖最近空间文件，避免污染真实用户状态 |
| `ARCHIVEBOX_APP_DIR` / `ARCHIVEBOX_SCHEME_DIR` | 覆盖配置/方案目录 |
| `ARCHIVEBOX_BASELINE_SRC` | 冻结基线源码路径 |

## 七、本次实际命令（可逐字对照）

```
C:\…\.venv\Scripts\python.exe C:\…\归档盒源码\tests\windows_supervisor.py
    --out C:\…\windows_stage3_deliver_20261110_165909\evidence
    --base C:\…\windows_stage3_runtime_20261110_165909
```

- cwd：`C:\…\归档盒源码\tests`
- 开始/结束（UTC）：`2026-11-10T08:59:09.5038591Z` → `2026-11-10T09:00:06.1125648Z`
- 退出码：脚本自报 0 / 子进程 0 / PowerShell 包装器 0
- 原始记录：`evidence/outer_powershell_exitcode.json`、`evidence/supervisor.json`
