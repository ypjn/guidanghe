# 归档盒 V1.7 · Windows 第二轮修正验收报告

- 运行标识（本轮唯一）：`stage3_20261110_165750`
- 交付目录：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage3_deliver_20261110_165909`
- 原始运行目录（未删除，供证据指针解析）：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage3_runtime_20261110_165750`
- 解释器：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\.venv\Scripts\python.exe`（Python 3.14.7，PySide6 6.12.0 / Qt 6.12）
- 外壳进程：Windows PowerShell 5.1.26100.7705
- 被审阅的上一轮交付（保留未动）：`windows_stage2_deliver_20261110_153858`
- 顾问证据（保留未动）：`C:\Users\Lenovo\Documents\ChatGPT\trae\stage2_review_20261110_154517\`

---

## 0. 结论摘要（按实际证据）

| 结论项 | 判定 | 依据 |
|---|---|---|
| 验收结果可信度（假成功）是否修复 | **通过** | 9 套件全部由真实 `RESULTS` 汇总退出；8 项失败注入自检全部识别；三级退出码均为 0，且有原始外层记录 |
| `normalize_manual_path` 生产回归是否修复 | **通过** | 16 项路径矩阵，`~/project/keep` 与基线行为一致，相对路径相对 root，边界未放宽 |
| 旧 P01 补丁损坏是否修复 | **通过** | 重新生成 P01/P02，`git apply --check`/`apply` 在独立基线副本上 exit=0，应用结果与最终源码 SHA-256 一致 |
| 原生桌面闭环 | **通过（程序化）**，真人试用未做 | PART1 21 项 + PART2 18 项，真实控件点击 + 原生事件循环 + 7 张带 run_id 截图 + 3 份文件清单 |
| 取消与关闭等待 | **通过** | 20 项；用测试专属同步点精确命中 `moved=3 / total=12` |
| 中断恢复（记账窗口） | **通过** | 22 项；4 种 executing 夹具 + 1 次受控硬中断（子进程 exit=7，单列故障注入） |
| 配置隔离实际行为 | **通过** | 20 项；A/B 同名同层级不同目标，重启复现，保护/优先级/失效/快照/迟到结果均以磁盘或数据库断言 |
| 是否阻断下一阶段 | **不阻断**（就本轮范围） | 本轮范围内 0 FAIL / 0 BLOCK；剩余为未测项，见第 9 节 |
| 是否需要用户设备操作 | **需要**：真人试用 + Mac 复验 | 见 `UNTESTED_AND_MAC.md` |

**计数口径（分开报，不混算）：**
- 产品/生产回归验收：**132 项，PASS 132 / FAIL 0 / BLOCK 0 / UNTESTED 0**
- 测试框架失败注入自检（`harness_selftest`，H1–H8）：**8 项，8/8 识别正确，单列，不计入产品通过率**
- 另有两处故障注入单列文件：`evidence/fault_injection/selftest_fault_injection.json`（7 个注入子进程）、`evidence/fault_injection/w2_2_controlled_interruption.json`（受控硬中断，子进程 exit=7）

---

## 1. 运行方式与三级退出码原始记录

外层命令（PowerShell，实际执行的那一条）：

```
& ...\run_stage3.ps1 -Deliver ...\windows_stage3_deliver_20261110_165909
  └─ Start-Process -FilePath <venv python> -WorkingDirectory <…\tests> -PassThru -Wait -NoNewWindow
       -ArgumentList "…\tests\windows_supervisor.py --out <deliver>\evidence --base <runtime>"
```

| 层级 | 含义 | 实取值 | 原始记录 |
|---|---|---|---|
| level 1 | 套件/监督脚本自报（stdout 里的 `EXIT_CODE=`） | 0 | `evidence/outer_supervisor.stdout.log` 末行 |
| level 2 | 直接子进程真实退出码（`Start-Process ... .ExitCode`） | 0 | `evidence/outer_powershell_exitcode.json` → `exit_codes.level2_direct_child_process` |
| level 3 | PowerShell 包装器退出码（`exit $WRAPPER_EXIT`） | 0 | 同上 → `exit_codes.level3_powershell_wrapper`；并由调用方进程返回值独立观测到 0 |

同文件另记录了：实际命令与 argv、cwd、解释器版本、PowerShell 版本、隔离环境（`ARCHIVEBOX_TEST_BASE`、`QT_QPA_PLATFORM` 已移除 → 记为「未采集」并注明原因、`PYTHONIOENCODING`、`PYTHONUTF8`）、`start_utc`/`end_utc`/`elapsed_ms`=56606、stdout/stderr 路径与字节数（1809 / 0）、`timed_out=false`。

`evidence/supervisor.json` 由监督进程按 9 个子进程的实际结果生成：`verdict=PASS`，每套件均含 `cmd` / `cwd` / `env_isolated` / `start_utc` / `end_utc` / `elapsed_ms` / `exit_code` / `timed_out` / `self_reported_exit_code` / `results_summary` / `verdict` / `problems`；每套件的完整 `stdout.log`、`stderr.log`、`results.json`、`process.json` 在 `evidence/<suite>/`。

---

## 2. 逐套件逐项结果（由 `results.json` 直接汇总，无手填）

| 套件 | 脚本 | 项数 | PASS | FAIL | BLOCK | 退出码 | 耗时 |
|---|---|---:|---:|---:|---:|---:|---:|
| patch_verify | `windows_patch_verify.py` | 10 | 10 | 0 | 0 | 0 | 0.3s |
| protect_paths | `windows_protect_paths.py` | 16 | 16 | 0 | 0 | 0 | 0.3s |
| harness_selftest | `windows_harness_selftest.py` | 8 | 8 | 0 | 0 | 0 | 2.6s | ← **故障注入自检，单列** |
| desktop_part1 | `windows_desktop_full.py` | 21 | 21 | 0 | 0 | 0 | 2.1s | |
| desktop_part2 | `windows_desktop_full_part2.py` | 18 | 18 | 0 | 0 | 0 | 2.5s | |
| launch_exit_10x | `windows_launch_exit_10x.py` | 5 | 5 | 0 | 0 | 0 | 12.2s | |
| w2_1_cancel_close | `windows_w2_1_cancel_close.py` | 20 | 20 | 0 | 0 | 0 | 7.0s | |
| w2_2_recovery | `windows_w2_2_recovery.py` | 22 | 22 | 0 | 0 | 0 | 13.4s | |
| w2_3_config_isolation | `windows_w2_3_config_isolation.py` | 20 | 20 | 0 | 0 | 0 | 15.8s | |
| **产品验收小计** | | **132** | **132** | **0** | **0** | 全 0 | 54.4s |
| **另：失败注入自检** | | **8** | **8** | **0** | **0** | 0 | 2.6s |

逐项 id / 标题 / 状态 / detail 见各 `evidence/<suite>/results.json`（machine-readable）。以下按顾问发现逐条对应。

---

## 3. 一、验收结果可信度（对应顾问问题 1、证据缺口）

**根因**：`windows_harness.Results.finalize()` 由内存中的真实条目汇总；`required_ids` 缺失、`FAIL`、`BLOCK` 任一存在即返回 1，绝不固定 `exit 0`。所有套件末尾统一 `sys.exit(R.finalize(...))`。

**子进程退出码上抛**：`Results.finalize` 之前，各套件用 `run_child()` 取真实 `returncode`，非零即记 FAIL；监督进程 `judge()` 把「子进程退出码非 0」「超时」「缺少 results.json」「results 里有 FAIL/BLOCK」「必测项缺失」「脚本自报 0 但真实退出非 0」全部判 FAIL。

**失败注入自检**（`harness_selftest`，8/8 PASS，证据 `evidence/harness_selftest/fault_injection.json`）：

| id | 注入内容 | 期望 | 实测 |
|---|---|---|---|
| H1 | 子套件记 FAIL 后 finalize | 退出码非 0 | exit=1 ✔ |
| H2 | 子进程未捕获异常 | 判 FAIL | exit=1 ✔ |
| H3 | 子进程超时（2s 强制终止） | `timed_out=True` 且判 FAIL | exit=-999 ✔ |
| H4 | 脚本自报 0 但结果含 FAIL | 判 FAIL（假成功被识破） | ✔ |
| H5 | 完全不产出 `results.json` | 判 FAIL | ✔ |
| H6 | 全 PASS 且 exit 0 | 判 PASS（判定器不恒定失败） | ✔ |
| H7 | 必测项缺失 | 判 FAIL | ✔ |
| H8 | 尝试递归删除固定 BASE | 抛错拒绝（所有权校验） | ✔ |

**唯一目录与删除安全**：`RunDir` 生成本轮唯一 `run_id` 并写 `.abx_owned_<run_id>` 标记；`safe_rmtree()` 先用 `os.path.commonpath` 校验落在 BASE 内、再要求标记存在，否则抛 `RuntimeError`；本轮所有清理只针对 `<BASE>/runs/<tag>_<run_id>`，未删过固定 BASE，也未删上一轮任何目录。

**解释器**：所有子进程统一 `sys.executable`（`run_child` / supervisor 不依赖源码目录的父层级推算解释器）；`tests` 与 `src` 路径由 `__file__` 推导，`ARCHIVEBOX_*` 环境变量注入隔离目录。

> 说明：上一轮 `windows_stage2_exit_codes.json` 的 `items/pass/exit_code` 是手填的；本轮同一位置的 `evidence/supervisor.json` 与各 `results.json` 全部由运行时结构直接 `json.dump`。

---

## 4. 二、生产回归与补丁交付（对应顾问问题 2、3）

### 4.1 `protect_config.normalize_manual_path`（P01）

当前实现（`source_snapshot/protect_config.py`）：

```python
raw = os.path.expanduser(str(path).strip())
if not raw:
    raise ProtectConfigError("目录为空")
if os.path.isabs(raw):
    p = os.path.abspath(raw)
else:
    p = os.path.abspath(os.path.join(root_abs, raw))
```

- 先 `expanduser`（恢复基线语义）→ 再判绝对/相对 → 相对路径相对整理 root（不依赖 cwd）。
- 原有边界未削弱：根目录自身拒绝、根外拒绝、`.organizer` 等程序产物目录拒绝、去重逻辑不变。

`protect_paths` 16 项矩阵（全部 PASS，隔离目录，未改用户真实配置）：

| id | 场景 | 结果 |
|---|---|---|
| P3 | `~/project/keep`（HOME 落在 root 内） | 修复后 accept，且与**冻结基线**结果逐字一致（expanduser 已恢复） |
| P4 | `~/path` 展开到 HOME 下真实目录 | accept |
| P5 | cwd≠root 时的相对路径 `keep` | accept，解析到 `<root>\keep` |
| P6 | **修复前反例**：基线在 cwd≠root 时同一输入 | 基线 reject：`目录不在当前根目录内：…\elsewhere\keep`（缺陷证据保留） |
| P7 | 中文相对路径 `大二上/高等数学` | accept → `<root>\大二上\高等数学` |
| P8 | 含空格相对路径 | accept |
| P9 | 绝对路径 | accept |
| P10 | 根目录自身 | reject |
| P11 | `../` 越界 | reject |
| P12 | 不存在目录 | reject |
| P13 | `.organizer` | reject（`程序自身目录不能作为保护目录`） |
| P14/P15 | 同目录两种写法 / 带 `./` 重复 | 去重为 1 |
| P16 | `~` 展开后落在 root 外 | reject（root 边界未放宽） |

大小写边界：**未做推测性改动**。现有代码在 Windows 上依赖 `os.path.abspath` + `startswith(root_abs + os.sep)` 的原有语义；本轮未触碰该逻辑，因此行为与基线一致。已将其列为「未测/已识别问题」而非「已修复」，见 `UNTESTED_AND_MAC.md`。

### 4.2 两处交互缺陷（P02，本轮新发现并修复）

1. `_reset_for_new_dir()` 末尾补 `self._update_button_states()`：打开已有根目录时历史库已打开，但「操作历史」按钮此前要等扫描后才可用（PART2 Q4 曾因按钮禁用失败）。
2. `_on_scan_done()` 增加根目录守卫（**本轮由 Q6 真跑出来的生产缺陷**）：扫描期间用户切换根目录时，旧目录的迟到结果不得落到新目录界面，也不得据此为新目录生成计划。

### 4.3 补丁生成与副本验证（对应顾问问题 3：旧 P01 第 5 行损坏）

`patch_verify` 10/10 PASS（证据 `patches/patch_verify.json`，含每条 `git` 命令、cwd、stdout/stderr、退出码）：

流程与结果（两个补丁各 5 项）：

1. `_diff`：补丁非空、块头 ≥1、**逐行合法性检查通过**（只允许上下文/增删/块头/文件头，`bad_lines` 为空）——旧 P01 的 `corrupt patch at line 5` 由此被机械拦住。
2. `_check`：把冻结基线文件 `copy2` 到本轮唯一副本目录，`git -c core.autocrlf=false -c core.safecrlf=false apply --check --verbose` → exit=0。
3. `_apply`：实际 `apply --verbose` → exit=0。
4. `_equal`：应用结果 SHA-256 == 最终源码 SHA-256，且残余 diff 为空（P01：`e3831b75…`；P02：`dffd2de7…`）。
5. `_frozen`：冻结基线原文 SHA-256 前后一致，未被修改。

补丁文件：`patches/P01_protect_config_expanduser.patch`、`patches/P02_main_interaction_fixes.patch`。

---

## 5. 三、原生桌面闭环（对应顾问「证据与覆盖缺口」第 2、3 条）

**PART1（21 项）** `run_id=20261110_165754_626de0`，`root=<runtime>/runs/desktop1_20261110_165754_626de0/root`，`batch_id=1`，预期移动 7 个文件。

- `D1` 真实 Windows 平台（`QT_QPA_PLATFORM` 已从环境移除，非 offscreen）；`D2` 窗口在事件循环中可见。
- `D5` **真实点击**「扫描」按钮（不是直调槽方法）；`D6` 扫描集合与独立预期集合完全一致（无多无少）。
- `D8` 预览计划与**独立逐项目标表**完全一致，例如：
  - `大二上/数据结构/讲义.pdf` → `_已整理/课程/大二上/数据结构/文档/讲义.pdf`
  - `大二上/高等数学/期末复习.pdf` → `_已整理/课程/大二上/高等数学/文档/期末复习.pdf`
  - `图片素材/logo.png` → `_已整理/待定/图片素材/logo.png`
  - `讲义.pdf` → `_已整理/待定/讲义.pdf`
- `D12` 确认对话框实际内容被读取并断言：根目录、分类模式、**全部选择统计**（不是统一点 Yes 跳过）；`D13` 经确认控件继续。
- `D15/D16` 每个预期目标文件存在、源已消失、SHA-256 一致；`_已整理` 内文件数 = 预期移动数（无多余副本）。
- `D17/D18` 数据库批次 `done`，逐项动作 `moved`，数量一致。
- `D19` 写出交接文件 `evidence/manifests/desktop_state.json`（`run_id` / `root` / `batch_id` / `expected_targets`）。
- `D20` 走正常关闭路径退出：窗口不可见、`_closing` 置位、无遗留 `QThread`。

**PART2（18 项）**：由外层在 PART1 正常退出后启动独立进程。

- `Q1/Q2/Q3` 读交接状态 → 打开**同一根目录**、载入持久化历史库、`batch_id=1` 处于可撤销状态。**无「重新扫描补造批次」路径**：状态文件缺失直接 FAIL。
- `Q2b` 启动时「检测到被中断批次」对话框真实出现、正文含同一 `batch_id`，被应答为**否**（走历史界面撤销，而不是就地撤销）。
- `Q4` 真实点击「操作历史」；`Q5` 在历史表格里按 `batch_id` 找到同一批次；`Q6` 选中后明细行数 = 预期动作数；`Q7` 撤销按钮可用；`Q8` 撤销确认框由真实点击 **Yes** 应答。
- `Q10` 撤销后逐文件清单（路径/大小/SHA-256，含隐藏文件与 `myproj/.git/config`）与整理前**完全一致**；`Q11` 批次与每条动作均为 `undone`；`Q12` 之后不再可撤销。
- 核对器反例：`R1` 多出文件能检出、`R2` 隐藏文件内容变化能检出、`R3` 文件缺失能检出、`R4` 反例在独立副本进行，正式根目录清单未被污染。

**截图（文件名含同一 `run_id`，`evidence/screenshots/`）**：

| 文件 | 时点 |
|---|---|
| `01_preview_20261110_165754_626de0.png` | 预览（确认前） |
| `02_confirm_20261110_165754_626de0.png` | 执行确认对话框（含根目录/模式/选择统计） |
| `03_after_execute_…png` | 执行完成后 |
| `03b_pending_prompt_…png` | 重启后「被中断批次」询问 |
| `04_history_before_undo_…png` | 重启后、撤销前（历史界面选中同一批次） |
| `04b_undo_confirm_…png` | 撤销确认框 |
| `06_after_undo_…png` | 撤销后 |

**文件清单**：`evidence/manifests/01_before.json`、`02_after_move.json`、`05_after_undo_manifest_<run_id>.json`（`01` 与 `05` 逐文件一致即为撤销完整恢复的直接证据）。

**事件循环说明**：PART1/PART2 是 Qt 程序化检查——被测逻辑运行在真实 `QApplication` 事件循环内，点击用 `QTest.mouseClick` 投递原生鼠标事件，模态框通过 `QApplication.activeModalWidget()` + 定时器应答真实 `QMessageBox` 按钮；**不是**自动化真人在场试用。生产入口的 `app.exec()` → `shutdown_widgets()` → `sys.exit()` 退出序列由 `launch_exit_10x` 单独覆盖（5 项：10 次独立进程退出码全 0、每次窗口真实可见且被正常关闭、无遗留 QThread、单次 <20s、各自隔离目录）。

---

## 6. 四、取消与关闭等待（对应顾问「证据与覆盖缺口」第 4 条）

`w2_1_cancel_close` 20/20 PASS。**不再依赖 200 文件轮询或 sleep 制造时序**：

- 测试专属同步点：子进程 patch `os.rename`，第 3 次成功后写观察文件并阻塞在 `threading.Event` 上，父进程读到 `renames=3` 后通过按钮请求取消，再放行 gate。
- `C1_1` 同步点精确命中「已移动 3 个且未全部完成」（`total=12`，断言 `0 < moved < total`）。
- `C1_2` 取消按钮在任务进行中可见可用，且由**真实点击**触发。
- `C1_3/C1_4` 批次 `cancelled`；动作 `moved=3`，其余 `cancelled`（逐项与磁盘一致，非"无异常"）。
- `C1_5` 磁盘与记录一致：目标 3 个、源剩 9 个；`C1_6` 无半成品可执行计划残留。
- `C1_7/C1_8` 从持久化历史撤销：`restored=3`（**不允许 restored=0**），撤销后完整文件清单与整理前逐文件一致。
- 关闭等待：`C2_1` 执行中关闭进入关闭等待相位而非立即关闭；`C2_2` 等待期间数据库对象存活且连接可用；`C2_3` 等待期间禁止启动新任务（扫描结果未被覆盖）；`C2_4` 后台线程使用自己的 SQLite 连接（非主线程、实例互不相同）；`C2_5` 线程真正结束后窗口才关闭；`C2_7` 关闭后**新进程**能打开历史库（无锁）；`C2_8` 被中断批次未被误记为成功（状态非 `done`）；`C2_9/C2_10` 撤销后源文件数量与清单完整恢复。
- 线程阶段 / 取消请求 / 线程结束 / 连接关闭的观察值写在 `children/c2_obs.json`、`c1_obs.json` 与子进程 `process.json`。
- 生产业务语义未改动（未加测试钩子到生产代码，同步点只在测试子进程内 patch）。

---

## 7. 五、中断恢复（对应顾问「证据与覆盖缺口」第 5 条）

`w2_2_recovery` 22/22 PASS。覆盖 **executing 批次**的四种记账窗口，预期均先按 `executor.recover_batch` 的 A/B/C/D 分支从源码确定，再通过**新进程真实恢复入口**（打开根目录时的「检测到被中断批次」对话框选「是」）核对磁盘与记录：

| 夹具 | 断点状态 | 预期 | 实测断言 |
|---|---|---|---|
| F1 | `executing` + `planned`，源在、目标不在 | 保持 `planned`；批次 `cancelled_clean` | F1_3/F1_4/F1_5：磁盘未动、归档 0 文件、清单不变 |
| F2 | 状态 `planned`，文件**已移到目标**但 moved 未落库 | 补记 `moved`；批次 `done` | F2_2/F2_3/F2_4：不二次移动，目标哈希 == 原始内容 |
| F3 | 源与目标**同时存在** | `paused` + 人工确认说明；批次 `recovered_partial` | F3_2/F3_3/F3_4：两份都未覆盖/删除，哈希均为原始内容 |
| F4 | 源与目标**都不存在** | `paused` 且错误信息明确写「都不存在」；批次 `recovered_partial` 且汇总 `paused=1` | F4_2/F4_3/F4_4：不因不抛异常算通过；磁盘仍双空 |
| F5 | **受控硬中断**：第 2 个 `os.rename` 成功后、`Storage.update_action(moved)` 前 `os._exit(7)` | 子进程非零退出；恢复后该项补记为 `moved`，未执行项保持 `planned` | F5_2 断言**恢复前**（`executing`、`moved=1`、`planned=2`）；F5_3/F5_4 断言恢复后（`moved=2`、`planned=1`）；F5_5 批次 `recovered_partial`，磁盘 2 在目标 / 1 在源 |

F5 的受控中断是一个**测试专属子进程**（不改生产代码），其 `exit=7` 作为故障注入单列在 `evidence/fault_injection/w2_2_controlled_interruption.json`，**不计入正常通过率**。

---

## 8. 六、配置隔离实际行为（对应顾问「证据与覆盖缺口」第 6 条）

`w2_3_config_isolation` 20/20 PASS。夹具：ROOT_A 有自定义 `SemesterDirRule(大二上/数据结构 → 方向=项目)` 与 `save_manual_protect(ROOT_A, ["大二上/高等数学"])`；ROOT_B 全默认、无保护；两端放**同名同层级**文件，A 另有 `A_ONLY_标记.txt`。`Q0_1` 先校验夹具落盘（`source_a=="custom"`、`source_b=="default"`）。

- **同名同层级、不同规则 → 不同目标**：`Q1_1` A → `_已整理/项目/…`；`Q1_2` B → `_已整理/课程/大二上/数据结构/…`；`Q1_3` 两端目标确实不同。`Q1_4/Q1_5` 新进程重启后各自恢复完全相同的目标。
- **手动保护真正生效**：`Q2_1` A 的「大二上/高等数学」完全不进入计划；`Q2_2` B 同路径文件正常进入计划（保护未误套到 B）；`Q2_3` A 计划 2 项 / B 计划 3 项，且演练未移动任何文件。**使用真实名称「高等数学」**，不再用「高数」模糊匹配。
- **优先级**：`Q3_1` 推荐映射 → 课程；`Q3_2` 长期规则（`MATCH_DIR_SCOPE`）→ 项目；`Q3_3` 临时修正（`apply_override_to_plan` + `OverrideParams`）→ 竞赛，且记录说明。即 **临时修正 > 长期规则 > 推荐映射**。
- **旧计划失效**：`Q4_1` 改配置后旧计划被标记失效、失效提示可见、执行按钮禁用；`Q4_2` **对照项**：失效前该计划本来可执行且 `plan_items==2`（排除"永远禁用"的假通过）；`Q4_3` 切换根目录后旧计划清空、界面换根。
- **启动时快照**：`Q5_1` 产品在启动计划任务前对配置做 `copy.deepcopy`（断言产品源码，不是 PlanWorker 内部引用）；`Q5_2` 改坏界面配置对象后，已提交任务生成的目标不变。
- **迟到结果不覆盖新界面**：`Q6_1` A 扫描中切到 B，`plan_items==0`；`Q6_2` 界面无 A 独有条目；`Q6_3` A 的迟到计划被丢弃（B 界面没有被替换成 A 的计划）。此项最初**真实失败**，由此新增生产修复 P02-b（`_on_scan_done` 根目录守卫）。

---

## 9. 未测项与阻塞

完整清单见 `UNTESTED_AND_MAC.md`。要点：

- 未做：全量规模（`acceptance_v17_scale.py` 级）、安装包（PyInstaller/Nuitka）、长路径 >260、跨盘移动、NTFS ACL、符号链接/硬链接、DPI 缩放、多显示器坐标一致性、真人手工试用。
- 未验证但已识别的风险：`normalize_manual_path` 的大小写边界（Windows 不区分大小写，现有 `startswith` 逻辑未改，可能与 NTFS 大小写不敏感语义有细微差异）——本轮**未推测性修改**，列为待评估项。
- 阻塞项：无。本轮范围内 0 FAIL / 0 BLOCK。

---

## 10. 证据索引

```
windows_stage3_deliver_20261110_165909/
├── report.md                                    # 本文件
├── CHANGES_vs_stage2.md                         # 相对上一轮的修改说明
├── UNTESTED_AND_MAC.md                          # 未测项 + Mac 复验清单
├── REPRODUCE.md                                 # 解释器 / 命令 / 脚本清单
├── evidence/
│   ├── outer_powershell_exitcode.json           # 外层记录（命令/cwd/隔离/起止/退出码三级）
│   ├── outer_supervisor.stdout.log / .stderr.log# 外层完整原始输出
│   ├── supervisor.json                          # 监督汇总（机器生成）
│   ├── <suite>/results.json                     # 逐项结构化结果
│   ├── <suite>/process.json                     # 该套件进程记录
│   ├── <suite>/stdout.log / stderr.log          # 完整原始日志
│   ├── harness_selftest/fault_injection.json    # 8 项失败注入（单列）
│   ├── patch_verify/patch_verify.json           # 补丁命令/输出/退出码
│   ├── launch_exit_10x/launch_exit_10x.json     # 10 次启动退出的逐次记录
│   ├── fault_injection/                         # 故障注入单列（复制汇总）
│   ├── screenshots/                             # 7 张 PNG，文件名含 run_id
│   ├── manifests/                               # 3 份逐文件清单 + 交接状态 + W2 基线清单
│   └── children/                                # 各子进程 process.json / 观察 json / 日志
├── patches/                                     # P01/P02 + patch_verify.json
├── reproduce/                                   # run_stage3.ps1 + 11 个测试脚本（可复现）
└── source_snapshot/                             # 最终源码（22 个 .py + requirements.txt + tests/11）
    └── SHA256SUMS.txt                           # 33 条 SHA-256
```

关键哈希（完整见 `source_snapshot/SHA256SUMS.txt`）：

| 文件 | SHA-256 |
|---|---|
| `protect_config.py` | `e3831b751cece9601ea6ad01baefdfaa55f3e2caeb893b3459aa38dcecc8af46` |
| `main.py` | `dffd2de72200a8d6899d7e4beb6858cad97917348bf35cc8237900dcdea816f4` |
| `executor.py` | `eb2dc7b4eb85ea764d0b650fdec13ee829b6c1c0bdfdf8e54945b795a6e4677a` |
| `storage.py` | `7dfddfe0fc565f8a104d8cc2d61e3a2aa76b3c8e0e982efc8693ae5a4ace55cf` |

---

## 11. 局限说明

1. **程序化桌面检查 ≠ 真人试用**。本报告的桌面闭环由 QtTest 控件交互 + 真实事件循环驱动，属于程序化验收；真人手工流程（含主观视觉/手感/非预期操作）仍需用户在实际设备上完成。
2. 未做全量规模与打包验证，不得据本报告推断安装包或大规模性能可用。
3. 证据中的绝对路径指向 `windows_stage3_runtime_20261110_165750`（本轮原始运行目录，已保留未删除）；交付中的副本在 `evidence/` 下同名文件。
4. 上一轮交付、日志、源码快照与顾问证据均未修改。
