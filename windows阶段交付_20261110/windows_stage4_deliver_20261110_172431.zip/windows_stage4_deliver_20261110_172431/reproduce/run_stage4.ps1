#requires -version 5.1
<#
  Stage 4 outer wrapper (PowerShell supervisor layer).

  Purpose: provide a real *outer* process record around
  tests/windows_supervisor.py, so the three exit-code levels can be
  recorded independently:
      level 1: suite script self-reported  (EXIT_CODE=... printed by suite)
      level 2: direct child process exit   (supervisor.py returncode)
      level 3: this PowerShell wrapper     (its own exit code)

  Every level is stored with the real value; levels that do not exist are
  written as the literal placeholder built from [char] escapes (see $NA) so
  this file stays pure ASCII and is safe for Windows PowerShell 5.1 reading
  it without a BOM.

  Raw records only - no hand-written pass/items/exit_code.
#>
param(
    [string]$Deliver = "",
    [string]$Only = ""
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
$HANDOFF = Join-Path $ROOT "archivebox_v17_windows_adapt_20261110\ArchiveBox_V1.7_Windows_Handoff_20261110"
# Discover the source dir without embedding non-ASCII literals.
$SRC = (Get-ChildItem -LiteralPath $HANDOFF -Directory |
        Where-Object { Test-Path (Join-Path $_.FullName "main.py") } |
        Select-Object -First 1).FullName
if (-not $SRC) { throw "source dir not found under $HANDOFF" }
$TESTS = Join-Path $SRC "tests"
$PY = Join-Path $ROOT "archivebox_v17_windows_adapt_20261110\.venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $PY)) { throw "venv python not found: $PY" }

$STAMP = Get-Date -Format "yyyyMMdd_HHmmss"
if (-not $Deliver) { $Deliver = Join-Path $ROOT "windows_stage4_deliver_$STAMP" }
$Deliver = [System.IO.Path]::GetFullPath($Deliver)
$EVID = Join-Path $Deliver "evidence"
$RUNTIME = Join-Path $ROOT "windows_stage4_runtime_$STAMP"
New-Item -ItemType Directory -Force -Path $EVID | Out-Null
New-Item -ItemType Directory -Force -Path $RUNTIME | Out-Null

$NA = [string]([char]0x672A + [char]0x91C7 + [char]0x96C6)   # placeholder

$OUT_STDOUT = Join-Path $EVID "outer_supervisor.stdout.log"
$OUT_STDERR = Join-Path $EVID "outer_supervisor.stderr.log"
$SUP_JSON = Join-Path $EVID "supervisor.json"

$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"
$env:ARCHIVEBOX_TEST_BASE = $RUNTIME
Remove-Item Env:\QT_QPA_PLATFORM -ErrorAction SilentlyContinue

$argv = @("$TESTS\windows_supervisor.py", "--out", $EVID, "--base", $RUNTIME)
if ($Only) { $argv += @("--only", $Only) }

$START = (Get-Date).ToUniversalTime().ToString("o")
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$p = Start-Process -FilePath $PY -ArgumentList $argv -WorkingDirectory $TESTS `
    -RedirectStandardOutput $OUT_STDOUT -RedirectStandardError $OUT_STDERR `
    -PassThru -Wait -NoNewWindow
$sw.Stop()
$END = (Get-Date).ToUniversalTime().ToString("o")
$CHILD_EXIT = $p.ExitCode

# level 1: what the supervisor script itself printed (informational only)
$SELF = $NA
if (Test-Path -LiteralPath $OUT_STDOUT) {
    $lines = @(Get-Content -LiteralPath $OUT_STDOUT -Encoding UTF8 -ErrorAction SilentlyContinue)
    for ($i = $lines.Count - 1; $i -ge 0; $i--) {
        if ($lines[$i] -match '^EXIT_CODE=(-?\d+)\s*$') {
            $SELF = [int]$Matches[1]
            break
        }
    }
}

# verdict cross-check from the actual structured results produced by the supervisor
$SUP_VERDICT = $NA
$SUP_SUITES = $NA
if (Test-Path -LiteralPath $SUP_JSON) {
    try {
        $sj = Get-Content -LiteralPath $SUP_JSON -Encoding UTF8 -Raw | ConvertFrom-Json
        $SUP_VERDICT = [string]$sj.verdict
        $SUP_SUITES = @($sj.suites | ForEach-Object { [pscustomobject]@{
            suite = $_.suite; verdict = $_.verdict; exit_code = $_.exit_code
            self_reported_exit_code = $_.self_reported_exit_code
            timed_out = $_.timed_out; elapsed_ms = $_.elapsed_ms
        } })
    } catch {
        $SUP_VERDICT = "PARSE_ERROR: " + $_.Exception.Message
    }
}

# level 3: this wrapper's own exit code. Consistent with the child it supervises.
$WRAPPER_EXIT = if ($CHILD_EXIT -eq 0 -and $SUP_VERDICT -eq "PASS") { 0 } else { 1 }

$record = [ordered]@{
    timestamp_local      = $STAMP
    purpose              = "outer PowerShell wrapper around tests/windows_supervisor.py"
    command              = ($PY + " " + ($argv -join " "))
    argv                 = $argv
    cwd                  = $TESTS
    python               = $PY
    python_version       = (& $PY -c "import sys;print(sys.version.split()[0])")
    powershell_version   = $PSVersionTable.PSVersion.ToString()
    isolation = [ordered]@{
        ARCHIVEBOX_TEST_BASE = $RUNTIME
        QT_QPA_PLATFORM      = $NA
        PYTHONIOENCODING     = $env:PYTHONIOENCODING
        PYTHONUTF8           = $env:PYTHONUTF8
        note                 = "QT_QPA_PLATFORM removed before launch: native windows platform required"
    }
    start_utc            = $START
    end_utc              = $END
    elapsed_ms           = [int]$sw.ElapsedMilliseconds
    stdout_log           = $OUT_STDOUT
    stderr_log           = $OUT_STDERR
    stdout_bytes         = if (Test-Path -LiteralPath $OUT_STDOUT) { (Get-Item -LiteralPath $OUT_STDOUT).Length } else { $NA }
    stderr_bytes         = if (Test-Path -LiteralPath $OUT_STDERR) { (Get-Item -LiteralPath $OUT_STDERR).Length } else { $NA }
    timed_out            = $false
    exit_codes = [ordered]@{
        level1_suite_self_reported  = $SELF
        level2_direct_child_process = $CHILD_EXIT
        level3_powershell_wrapper   = $WRAPPER_EXIT
    }
    supervisor = [ordered]@{
        json_path = $SUP_JSON
        verdict   = $SUP_VERDICT
        suites    = $SUP_SUITES
    }
    parent_of_wrapper_note = "level3 is enforced via 'exit' at the end of this script; the process exit code observed by the caller is the authoritative level3 value"
}

$JSON_PATH = Join-Path $EVID "outer_powershell_exitcode.json"
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $JSON_PATH -Encoding UTF8
Write-Output ("outer record: " + $JSON_PATH)
Write-Output ("level1(suite self)=" + $SELF + " level2(child)=" + $CHILD_EXIT + " level3(wrapper)=" + $WRAPPER_EXIT + " supervisor=" + $SUP_VERDICT)

exit $WRAPPER_EXIT
