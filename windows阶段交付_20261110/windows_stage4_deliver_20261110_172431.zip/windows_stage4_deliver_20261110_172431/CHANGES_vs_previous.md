# 相对上一轮的修改说明

本文件同时对照两个基线：
- **A. 被审阅的 `windows_stage2_deliver_20261110_153858`**（顾问复现三个问题的那一版）
- **B. `windows_stage3_deliver_20261110_165909`**（上一轮中间修正交付）

## 一、相对 B（stage3）：生产代码零改动

`source_snapshot/*.py` 与本轮逐字节一致（已用 SHA-256 逐文件比对，结果 `ALL SAME`），测试脚本亦未改动。本轮差异只在**交付物**：

| 新增 | 说明 |
|---|---|
| `evidence/manifests/stage_diffs.json` | 三阶段（整理前 / 移动后 / 撤销后）逐文件清单差异；证明 `before_vs_after_undo` 的 missing/extra/changed 全空 |
| 全新运行证据 | 新 `run_id=20261110_172318_6f5054`、新唯一目录、新截图与清单、新三级退出码记录 |
| `report.md` / `CHANGES_vs_previous.md` / `UNTESTED_AND_MAC.md` / `REPRODUCE.md` | 按本轮证据重写 |

## 二、相对 A（被审阅的 stage2）：2 个生产文件 / 3 处修复 + 补丁重做

| # | 文件 | 位置 | 修改 | 原因 |
|---|---|---|---|---|
| P01 | `protect_config.py` | `normalize_manual_path` | 恢复 `expanduser`，改为「先展开 `~` → 判绝对/相对 → 相对路径相对整理 root」 | stage2 为修 cwd≠root 的相对路径把 `expanduser` 一起删了，导致 `~/project/keep` 回归失败 |
| P02-a | `main.py` | `_reset_for_new_dir` 末尾 | 补 `_update_button_states()` | 打开已有根目录时「操作历史」按钮被禁用（PART2 Q4 真跑暴露） |
| P02-b | `main.py` | `_on_scan_done` 开头 | 增加根目录守卫，旧目录迟到扫描结果丢弃并提示 | 扫描期间切根后旧结果污染新界面（W2-3 Q6 真跑暴露） |

哈希对照：

```
stage2:  protect_config.py f20e5153d28c0230…   main.py b48a66db47e40c12…
本轮:    protect_config.py e3831b751cece9601ea6ad01baefdfaa55f3e2caeb893b3459aa38dcecc8af46
         main.py           dffd2de72200a8d6899d7e4beb6858cad97917348bf35cc8237900dcdea816f4
```

其余生产文件（`executor.py` / `storage.py` / `scanner.py` / `planner.py` / `classification_config.py` 等）相对 stage2 **逐字节未变**。

### 补丁

| stage2 | 本轮 |
|---|---|
| `P01_protect_config_relative_path.patch`，顾问实测 `corrupt patch at line 5` | `patches/P01_protect_config_expanduser.patch`、`patches/P02_main_interaction_fixes.patch`；由冻结基线 + 最终源码重新生成，逐行合法性检查通过；独立基线副本上 `apply --check` / `apply` 均 exit=0；应用结果与最终源码 SHA-256 一致；冻结基线未改 |

## 三、测试框架（相对 stage2）

新增 5 个、重写 6 个（相对 stage2 快照逐文件比对）：

**新增**：`windows_harness.py`（唯一目录 + 所有权标记 + `Results.finalize` + 清单 diff + `run_child`）、`windows_supervisor.py`（外层监督与统一判定）、`windows_harness_selftest.py`（8 项失败注入）、`windows_patch_verify.py`（补丁生成与副本验证）、`windows_protect_paths.py`（16 项路径矩阵，含只读基线对照）。

**重写**：`windows_desktop_full.py`、`windows_desktop_full_part2.py`、`windows_launch_exit_10x.py`、`windows_w2_1_cancel_close.py`、`windows_w2_2_recovery.py`、`windows_w2_3_config_isolation.py`。

## 四、明确未做的事

- 未新增产品功能、未扩大 W2 范围、未做安装包、未跑全量规模。
- 未改 `executor.py` 的恢复/撤销业务语义；测试同步点只存在于测试子进程内的 patch，生产代码无测试钩子。
- 未修改任何旧目录（stage2 交付/证据/快照、stage3 交付、冻结基线、顾问证据）。
- 未把「58 项全通过」的旧口径带入本轮；本轮所有数字取自本轮 `results.json`。
