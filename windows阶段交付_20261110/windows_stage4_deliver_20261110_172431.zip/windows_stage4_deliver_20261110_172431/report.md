# 归档盒 V1.7 · Windows 第三轮（第二轮交付问题修正与补验）验收报告

- 本轮唯一运行标识：`stage4_20261110_172314`
- 交付目录（绝对路径）：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage4_deliver_20261110_172431`
- 本轮原始运行目录（保留未删）：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\windows_stage4_runtime_20261110_172314`
- 解释器：`C:\Users\Lenovo\Documents\Trae-CN\temp_20261110_01\archivebox_v17_windows_adapt_20261110\.venv\Scripts\python.exe`（Python 3.14.7，PySide6 6.12.0 / Qt 6.12）
- 外层壳：Windows PowerShell 5.1.26100.7705
- 被测源码：`...\ArchiveBox_V1.7_Windows_Handoff_20261110\归档盒源码`

## 0. 动态确认的当前项目位置与保留资产

| 资产 | 路径 | 状态 |
|---|---|---|
| 冻结基线（只读） | `...\temp_20261110_01\archivebox_v17_baseline_20261110` | 保留，79 个文件 |
| 源码工作树 | `...\temp_20261110_01\archivebox_v17_windows_adapt_20261110` | 保留 |
| 被审阅的上一轮交付 | `...\windows_stage2_deliver_20261110_153858` | 保留，78 个文件，未改动 |
| 上一轮证据 | `...\windows_stage2_evidence` | 保留，9 个文件，未改动 |
| 上一轮源码快照 | `...\windows_stage2_snapshot_20261110` | 保留 |
| 上一轮中间修正交付 | `...\windows_stage3_deliver_20261110_165909` | 保留，260 个文件，未改动 |
| 顾问审阅证据 | `C:\Users\Lenovo\Documents\ChatGPT\trae\stage2_review_20261110_154517` | 保留，`review.md` / `probes.json` 未改动 |

本轮全部新产出写入 `windows_stage4_*`，未覆盖、未删除上述任何目录。

---

## 1. 三个已独立复现问题的修复状态

### 1.1 测试失败却返回成功 —— 已修复

**证据（本轮实跑）**：9 个套件全部 `exit_code=0` 且 `self_reported_exit_code=0`，`supervisor.json` 的 `verdict=PASS`；关键在于**失败时确实会失败**，由 8 项失败注入自检证明：

| id | 注入 | 期望 | 实测 |
|---|---|---|---|
| H1 | 子套件记一条 FAIL 后 finalize | 退出码非 0 | exit=1 ✔ |
| H2 | 子进程未捕获异常 | 外层判 FAIL | exit=1 ✔ |
| H3 | 子进程挂死 2s 被强制终止 | `timed_out=true` 且判 FAIL | exit=-999 ✔ |
| H4 | 脚本自报 0 但 `results.json` 含 FAIL | 判 FAIL（假成功被识破） | ✔ |
| H5 | 完全不产出 `results.json` | 判 FAIL | ✔ |
| H6 | 全 PASS 且 exit 0 | 判 PASS（判定器不恒定失败） | ✔ |
| H7 | 必测项缺失 | 判 FAIL | ✔ |
| H8 | 尝试递归删除固定 BASE | 拒绝删除 | ✔ |

机制：`Results.finalize()` 只由内存真实条目汇总（`required_ids` 缺失、FAIL、BLOCK 任一存在即返回 1）；`judge()` 额外校验「子进程真实退出码」「超时」「缺少 results.json」「自报 0 但结果含 FAIL」。**不解析 stdout 中的成功文字作为通过依据**。`fault_injection.json` 与正常验收结果分文件记录，故障注入 8 项**不计入**产品通过率。

### 1.2 手动保护路径 expanduser 回归 —— 已修复

当前实现：

```python
raw = os.path.expanduser(str(path).strip())
if not raw:
    raise ProtectConfigError("目录为空")
if os.path.isabs(raw):
    p = os.path.abspath(raw)
else:
    p = os.path.abspath(os.path.join(root_abs, raw))   # 相对整理根，不依赖 cwd
```

16 项矩阵（隔离临时目录，未触碰用户真实配置）：

| id | 场景 | 结果 |
|---|---|---|
| P3 | `~/project/keep` | 修复后接受，且与**冻结基线**逐字一致（回归已消除） |
| P4 | `~/path` | 展开到 HOME 下真实目录 |
| P5 | cwd≠root 的相对路径 | 解析到 `<root>\keep` |
| P6 | **修复前反例**：基线在 cwd≠root 时同一输入 | 基线拒绝 `目录不在当前根目录内：…\elsewhere\keep`（证据保留） |
| P7 | 中文相对路径 `大二上/高等数学` | 接受，指向 root 内 |
| P8 | 含空格相对路径 | 接受 |
| P9 | 绝对路径 | 接受 |
| P10 | 根目录自身 | 拒绝 |
| P11 | `../` 越界 | 拒绝 |
| P12 | 不存在目录 | 拒绝 |
| P13 | `.organizer` 程序产物目录 | 拒绝 |
| P14/P15 | 同目录两种写法 / `./` 重复 | 去重为 1 |
| P16 | `~` 展开后落在 root 外 | 拒绝（**根边界未放宽**） |

链接保护：本轮未改动该逻辑，也未新增验证，如实列为未测（见 `UNTESTED_AND_MAC.md`）。

### 1.3 旧 P01 补丁第 5 行损坏 —— 已修复

`patch_verify` 10/10 PASS，补丁由「冻结基线 + 最终源码」经 `difflib.unified_diff` 重新生成，按目标文件 EOL 拼接，并做**逐行合法性检查**（只允许上下文/增删/块头/文件头），旧 `corrupt patch at line 5` 会在生成阶段被机械拦住。

在**独立基线副本**（`copy2` 到本轮唯一目录）上执行：

| 步骤 | P01 | P02 |
|---|---|---|
| `git apply --check --verbose` | exit=0 | exit=0 |
| `git apply --verbose` | exit=0 | exit=0 |
| 应用结果 SHA-256 == 最终源码 | ✔ `e3831b75…` | ✔ `dffd2de7…` |
| 残余 diff 为空 | ✔ | ✔ |
| 冻结基线哈希前后一致 | ✔ | ✔ |

命令、cwd、原始 stdout/stderr、退出码全在 `patches/patch_verify.json`；补丁本体在 `patches/`。

> 注：`git` 调用显式加 `-c core.autocrlf=false -c core.safecrlf=false`，否则本机自动换行会把应用结果改写成 CRLF 造成假不一致。

---

## 2. 原始证据链（对应第二节）

外层包装脚本 `reproduce/run_stage4.ps1` 用 `Start-Process -PassThru -Wait` 启动监督进程，`evidence/outer_powershell_exitcode.json` 记录：

| 字段 | 实取值 |
|---|---|
| 解释器 | `...\.venv\Scripts\python.exe`（3.14.7） |
| 实际命令 / argv | `python ...\tests\windows_supervisor.py --out ...\evidence --base ...\windows_stage4_runtime_20261110_172314` |
| 工作目录 | `...\归档盒源码\tests` |
| 隔离设置 | `ARCHIVEBOX_TEST_BASE=...runtime_20261110_172314`；`QT_QPA_PLATFORM` 已被移除 → 记「未采集」并注明「native windows platform required」；`PYTHONIOENCODING=utf-8`、`PYTHONUTF8=1` |
| 起止时间 | `2026-11-10T09:24:31.7537848Z` → `2026-11-10T09:25:28.3501591Z`（56592 ms） |
| 完整 stdout / stderr | `evidence/outer_supervisor.stdout.log`（1809 B）/ `.stderr.log`（0 B） |
| 超时 / 强制终止 | `timed_out=false` |

三级分开记录（不合并、不补写）：

| 层级 | 含义 | 本轮实取 |
|---|---|---|
| level 1 | 断言统计（`results.json` 的 PASS/FAIL/BLOCK/missing） | 各套件见 `evidence/<suite>/results.json` |
| level 1' | 脚本自报退出码（stdout `EXIT_CODE=`） | 0（**仅记录，不采信**） |
| level 2 | 直接子进程真实退出码 | 0 |
| level 3 | 包装器自身退出码 | 0 |

`evidence/supervisor.json` 由运行结果机器生成，逐套件含 `cmd/cwd/env_isolated/start_utc/end_utc/elapsed_ms/exit_code/timed_out/self_reported_exit_code/results_summary/verdict/problems`。

解释器与目录：所有子进程用 `sys.executable`；路径由 `__file__` 推导，不依赖固定父目录层级；每次运行由 `RunDir` 生成唯一 `run_id` 与 `.abx_owned_<run_id>` 标记，`safe_rmtree()` 先用 `os.path.commonpath` 校验落在 BASE 内、再要求标记存在，否则抛错——**从不递归清理固定 BASE**（H8 已验证）。

---

## 3. 逐套件结果（全部由 `results.json` 汇总）

| 套件 | 项数 | PASS | FAIL | BLOCK | 退出码 | 耗时 |
|---|---:|---:|---:|---:|---:|---:|
| patch_verify | 10 | 10 | 0 | 0 | 0 | 0.17s |
| protect_paths | 16 | 16 | 0 | 0 | 0 | 0.21s |
| **harness_selftest（失败注入，单列）** | 8 | 8 | 0 | 0 | 0 | 2.54s |
| desktop_part1 | 21 | 21 | 0 | 0 | 0 | 1.94s |
| desktop_part2 | 18 | 18 | 0 | 0 | 0 | 2.37s |
| launch_exit_10x | 5 | 5 | 0 | 0 | 0 | 12.11s |
| w2_1_cancel_close | 20 | 20 | 0 | 0 | 0 | 6.89s |
| w2_2_recovery | 22 | 22 | 0 | 0 | 0 | 13.25s |
| w2_3_config_isolation | 20 | 20 | 0 | 0 | 0 | 15.69s |
| **产品验收小计** | **132** | **132** | **0** | **0** | 全 0 | 54.4s |

计数口径：产品验收 132 项；失败注入自检 8 项单列。**不使用上一轮「58 项全通过」的口径。**

---

## 4. 原生桌面闭环（第三节）

本轮 `run_id = 20261110_172318_6f5054`，`batch_id = 1`，`root = <runtime>\runs\desktop1_20261110_172318_6f5054\root`，预期移动 7 个文件。

- **真实控件交互**：`QT_QPA_PLATFORM` 已移除 → Windows 原生平台；扫描、执行、历史、撤销均由 `QTest.mouseClick` 投递鼠标事件到真实按钮/表格视口，不是直调槽方法。
- **确认界面统计被实际读取并断言**：根目录、分类模式、全部选择数量（D12），随后经确认控件继续（D13）。删除了「统一把 `QMessageBox.question` 替换为 Yes」的做法：PART2 的「被中断批次」询问框被应答为 **否**（Q2b），确认框才应答 Yes（Q8）。
- **独立预期集合与逐项目标表**：D6 扫描集合与预期完全一致；D8 逐项目标逐一比对，例如
  `大二上/数据结构/讲义.pdf → _已整理/课程/大二上/数据结构/文档/讲义.pdf`、
  `图片素材/logo.png → _已整理/待定/图片素材/logo.png`、`讲义.pdf → _已整理/待定/讲义.pdf`。
- **无条件 PASS 与宽泛关键词断言已删除**；表格非空不再作为通过条件（D9 断言 行数 = 计划项数 = 预期文件数）。
- **PART1 → PART2 交接**：`evidence/manifests/desktop_state.json` 存 `run_id/root/batch_id/expected_targets/清单路径`，PART1 正常关闭后由外层启动 PART2。
- **PART2 严格**：找不到同一 `batch_id` 或已撤销即 FAIL，**无「重新扫描补造批次」路径**；从历史表格真实点击该批次（Q5/Q6），点撤销并确认（Q7/Q8），撤销后批次与每条动作均 `undone`（Q11），完整清单回到整理前（Q10），之后不可再撤销（Q12）。
- **核对器反例**：R1 归档/根目录多出文件、R2 隐藏文件内容变化、R3 文件缺失，均在独立副本执行（R4 证明正式根目录未被污染）。

### 三阶段文件清单与差异

| 文件 | 内容 |
|---|---|
| `evidence/manifests/01_before.json` | 整理前 10 个文件（含 `.hidden_note.txt`、`myproj/.git/config`、`myproj/main.py`） |
| `evidence/manifests/02_after_move.json` | 移动后 10 个文件 |
| `evidence/manifests/05_after_undo_manifest_20261110_172318_6f5054.json` | 撤销后 10 个文件 |
| `evidence/manifests/stage_diffs.json` | 三阶段差异（本轮新增） |

差异摘要（`stage_diffs.json`）：

- `before → after_move`：7 个源路径消失、7 个 `_已整理/...` 目标出现、`changed=0`；
- `after_move → after_undo`：7 个 `_已整理/...` 消失、7 个原路径回归、`changed=0`；
- `before_vs_after_undo`：`missing=[] extra=[] changed=[]` → **`before_equals_after_undo = true`**。

### 截图（`evidence/screenshots/`，文件名含同一 run_id 与 batch_id=1）

`01_preview_…png`（确认前）、`02_confirm_…png`（执行确认界面）、`03_after_execute_…png`、`03b_pending_prompt_…png`（重启后）、`04_history_before_undo_…png`（撤销前）、`04b_undo_confirm_…png`、`06_after_undo_…png`（撤销后）。

### 事件循环说明（不混写）

- `launch_exit_10x` 走**生产入口真实序列**：`QApplication → MainWindow → show → app.exec() → shutdown_widgets() → sys.exit(code)`，10 次独立子进程，退出码全 0、窗口真实可见后被正常关闭、无遗留 `QThread`、单次 < 20s、各自隔离目录。
- `desktop_part1/part2`、`w2_1`、`w2_3` 的界面部分为 **QtTest 控件交互 + 真实模态框应答**，运行在真实事件循环内（不是裸 `processEvents` 空转，也不是真人试用）。

---

## 5. 取消与关闭等待（第四节）

`w2_1_cancel_close` 20/20 PASS。**不再靠 200 文件轮询或固定 sleep**：在测试子进程内 patch `os.rename`，第 3 次成功后阻塞在 `threading.Event`，父进程读到 `renames=3` 后点取消再放行——这是测试专属同步点，生产业务语义未改。

| 断言 | 证据 |
|---|---|
| `0 < moved < total` 精确命中（moved=3 / total=12） | C1_1 |
| 取消按钮真实可见可用并被点击 | C1_2 |
| 批次 `cancelled`；动作 `moved=3`、其余 `cancelled` | C1_3 / C1_4 |
| 磁盘与记录一致：目标 3 / 源剩 9 | C1_5 |
| 无半成品可执行计划残留 | C1_6 |
| 从持久化历史撤销 `restored=3`（**不允许 0**） | C1_7 |
| 撤销后完整清单（路径/大小/SHA-256）恢复 | C1_8 |
| 执行中关闭 → 进入关闭等待相位 | C2_1 |
| 等待期间数据库对象存活、连接可用 | C2_2 |
| 等待期间禁止启动新任务 | C2_3 |
| 各后台线程使用自己的 SQLite 连接（非主线程、实例互异） | C2_4 |
| 线程真正结束后窗口才关闭 | C2_5 |
| 新进程可读历史、无遗留锁 | C2_7 |
| 被中断批次未被误记成功（非 `done`） | C2_8 |
| 撤销后源文件数量与清单完整恢复 | C2_9 / C2_10 |

子进程 `returncode` 参与判定，不以「无异常」「`isRunning=False`」「`_closing=True`」单独记通过。

---

## 6. 中断恢复（第五节）

`w2_2_recovery` 22/22 PASS。先按 `executor.recover_batch` 的 A/B/C/D 分支从源码确定预期，再让**新进程**走真实恢复入口（打开根目录时「检测到被中断批次」对话框选「是」）：

| 夹具 | 记账窗口 | 预期 | 实测 |
|---|---|---|---|
| F1 | `executing` + `planned`，源在、目标不在 | 保持 `planned`；批次 `cancelled_clean` | 磁盘未动、归档 0 文件、清单不变 |
| F2 | 状态 `planned`，**文件已移到目标但 moved 未落库** | 补记 `moved`；批次 `done` | 不二次移动，目标哈希 == 原始内容 |
| F3 | **源与目标同时存在** | `paused` + 人工确认说明；批次 `recovered_partial` | 两份均未覆盖/删除，哈希均为原始内容 |
| F4 | **源与目标都不存在** | `paused` 且明确写「都不存在」；批次 `recovered_partial` 且汇总 `paused=1` | 不以不抛异常通过；磁盘仍双空 |
| F5 | **受控硬中断**：第 2 个 `os.rename` 成功后、`update_action(moved)` 前 `os._exit(7)` | 恢复后该项补记 `moved`，未执行项保持 `planned` | 恢复前断言 `executing/moved=1/planned=2`，恢复后 `moved=2/planned=1`，批次 `recovered_partial`，磁盘 2 在目标 / 1 在源 |

F5 中断子进程 `exit=7`、`timed_out=false`，作为**预期故障注入**单列在 `evidence/fault_injection/w2_2_controlled_interruption.json`，不计入正常通过率。

---

## 7. 配置隔离与计划失效（第六节）

`w2_3_config_isolation` 20/20 PASS。夹具：ROOT_A 自定义 `SemesterDirRule(大二上/数据结构 → 项目)` + `save_manual_protect(ROOT_A, ["大二上/高等数学"])`；ROOT_B 全默认无保护；两端**同名同层级**文件，A 另有 `A_ONLY_标记.txt`。

| 要求 | 断言方式 | 结果 |
|---|---|---|
| A/B 实际预览目标不同 | 读预览表逐行实际目标 | A → `_已整理/项目/…`；B → `_已整理/课程/大二上/数据结构/…` |
| 重启后分别恢复 | 两个新进程重新扫描比对 | 目标完全一致 |
| A 手动保护不进计划、B 同路径正常进入 | 实际计划项数与磁盘 | A=2 项（高等数学被排除）、B=3 项 |
| 临时修正 > 长期规则 > 推荐映射 | 三档实际目标 | 课程 → 项目（`MATCH_DIR_SCOPE`）→ 竞赛（`apply_override_to_plan`） |
| 切根/改配置/改范围后旧计划不可执行 | 控件状态 + 计划内容 | 改配置后失效提示可见、执行按钮禁用；**含对照项**证明失效前可执行且 `plan_items==2`；切根后计划清空、界面换根 |
| 后台任务用启动时快照 | 产品源码断言 + 行为 | `plan_config = copy.deepcopy(self.classification_config)`；改坏界面配置后目标不变 |
| 迟到结果不覆盖新界面 | 界面行内容 | A 扫描中切到 B：`plan_items==0`、无 A 独有条目、无 A 计划 |

保护配置确实传到了底层扫描（否则 Q2_1 不可能成立）；关键词使用真实名称「高等数学」，不再用「高数」。

---

## 8. 本轮修改说明（相对上一轮交付）

**生产代码本轮无新增修改**：`source_snapshot` 与 `windows_stage3_deliver_20261110_165909` 的 22 个 `.py` 逐字节一致（已比对，`ALL SAME`）。

相对**被审阅的 stage2 交付**，生产代码共 3 处修复（P01 为 `protect_config.normalize_manual_path`；P02-a 为 `_reset_for_new_dir` 补刷按钮；P02-b 为 `_on_scan_done` 根目录守卫），详见 `CHANGES_vs_previous.md`。

测试侧本轮相对 stage3：无代码改动；新增交付物为 `evidence/manifests/stage_diffs.json`（三阶段差异）与本轮独立证据集。

---

## 9. 未测项与剩余阻断

详见 `UNTESTED_AND_MAC.md`。摘要：

- 未测：全量规模、安装包、长路径 > 260、跨盘移动、NTFS ACL、符号链接/硬链接、DPI 缩放、多显示器坐标、云盘占用文件、多进程并发同根目录、`partial/recovered_partial` 二次恢复、**真人手工试用**。
- 已识别未修改：`normalize_manual_path` 在 Windows 上的**大小写边界**（`startswith` 区分大小写 vs NTFS 不区分）——按要求不推测性扩大改动，列为待评估。
- 阻断：本轮范围内 **0 FAIL / 0 BLOCK**，无技术阻断；仅真人试用与 Mac 复验需用户侧完成。

---

## 10. 证据索引

```
windows_stage4_deliver_20261110_172431/
├── report.md
├── CHANGES_vs_previous.md
├── UNTESTED_AND_MAC.md
├── REPRODUCE.md
├── evidence/
│   ├── outer_powershell_exitcode.json        # 外层：命令/cwd/隔离/起止/三级退出码
│   ├── outer_supervisor.stdout.log / .stderr.log
│   ├── supervisor.json                       # 机器生成的汇总
│   ├── <suite>/results.json|process.json|stdout.log|stderr.log
│   ├── harness_selftest/fault_injection.json
│   ├── patch_verify/patch_verify.json
│   ├── launch_exit_10x/launch_exit_10x.json
│   ├── fault_injection/                      # 故障注入单列（2 份）
│   ├── screenshots/                          # 7 张 PNG，含 run_id
│   ├── manifests/                            # 三阶段清单 + stage_diffs.json + 交接状态 + W2 基线
│   └── children/                             # 各子进程 process.json / 观察 json / 日志
├── patches/                                  # P01 / P02 + patch_verify.json
├── reproduce/                                # run_stage4.ps1 + 11 个测试脚本
└── source_snapshot/                          # 22 个 .py + requirements.txt + tests/11 + SHA256SUMS.txt
```

关键哈希：

| 文件 | SHA-256 |
|---|---|
| `protect_config.py` | `e3831b751cece9601ea6ad01baefdfaa55f3e2caeb893b3459aa38dcecc8af46` |
| `main.py` | `dffd2de72200a8d6899d7e4beb6858cad97917348bf35cc8237900dcdea816f4` |
| `executor.py` | `eb2dc7b4eb85ea764d0b650fdec13ee829b6c1c0bdfdf8e54945b795a6e4677a` |

## 11. 局限

1. 桌面闭环为**程序化**验收（QtTest + 真实事件循环），不等于真人试用；两者分开陈述。
2. 未做全量规模与打包验证，不能据此推断安装包或大规模性能。
3. 证据中的绝对路径指向 `windows_stage4_runtime_20261110_172314`（保留未删），交付内为同名副本。
4. 本轮未重复无关的大规模回归，只跑了与三个问题及相关补验直接相关的 9 个套件。
